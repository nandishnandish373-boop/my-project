import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize Gemini SDK on server-side
const aiApiKey = process.env.GEMINI_API_KEY;
const ai = aiApiKey
  ? new GoogleGenAI({
      apiKey: aiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// ==========================================
// In-Memory Database / State Store
// ==========================================

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  isGoogle?: boolean;
  joinedAt: string;
}

let currentUser: User | null = {
  id: 'usr_default_01',
  name: 'Madhu Fighter',
  email: 'madhu0007.m@gmail.com',
  avatar: 'M',
  isGoogle: true,
  joinedAt: new Date().toISOString(),
};

// Fitness and Bio stats
let stats = {
  readiness: 94,
  hydration: 2.75, // in Litres
  sleep: 8.2, // in hours
  recovery: 91, // percentage
  heartRateResting: 54, // bpm
  weekly: [0.65, 0.85, 0.45, 0.95, 0.70, 0.88, 0.92],
  training: [
    { id: 't1', name: 'Boxing Pad Work & Heavy Bag', duration: 45, calories: 420, timestamp: 'Today, 08:30 AM' },
    { id: 't2', name: 'Upper Body Hypertrophy (Push)', duration: 55, calories: 380, timestamp: 'Yesterday, 06:15 PM' },
    { id: 't3', name: 'BJJ Drilling & Sparring', duration: 60, calories: 510, timestamp: '2 days ago' },
  ],
  skincare: [
    { id: 's1', name: 'Gentle Hydrating Cleanser (AM)', category: 'AM', status: 'done', desc: 'Sulfate-free hydrating cleanse to preserve skin barrier without stripping natural lipids.' },
    { id: 's2', name: 'Vitamin C 15% Antioxidant Serum', category: 'AM', status: 'done', desc: 'Neutralizes free radical oxidative stress from UV and intense cardiovascular workouts.' },
    { id: 's3', name: 'Ceramide Light Barrier Moisturizer', category: 'AM', status: 'done', desc: 'Locks in cellular hydration and prepares skin for high-friction sweat environment.' },
    { id: 's4', name: 'SPF 50+ Water & Sweat Resistant Sunscreen', category: 'AM', status: 'pending', desc: 'Broad-spectrum UV shield essential for outdoor roadwork and sparring.' },
    { id: 's5', name: 'Post-Workout BHA 2% Salicylic Cleanser', category: 'Post-Gym', status: 'pending', desc: 'Unclogs sweat pores and prevents exercise-induced acne mechanica.' },
    { id: 's6', name: 'Hypochlorous Acid Antimicrobial Face Mist', category: 'Post-Gym', status: 'pending', desc: 'Neutralizes bacteria picked up from mats, gym pads, and boxing gloves.' },
    { id: 's7', name: 'Night Double Cleanse (Oil Balm + Gentle Foam)', category: 'PM', status: 'pending', desc: 'Removes waterproof mineral SPF, sweat salts, and airborne micro-particles.' },
    { id: 's8', name: 'Encapsulated Retinoid 0.3% & Peptide Complex', category: 'PM', status: 'pending', desc: 'Stimulates cellular collagen synthesis and dermal healing during deep sleep stages.' },
  ],
};

// Gym Routines Data (Real-Life Sports Science)
interface GymExercise {
  id: string;
  name: string;
  muscle: string;
  sets: number;
  reps: string;
  rpe: string;
  rest: string;
  cues: string[];
  completedSets: boolean[];
  weightLogged?: number;
}

interface GymPlan {
  id: string;
  title: string;
  tagline: string;
  category: string;
  estimatedMinutes: number;
  exercises: GymExercise[];
}

let gymPlans: GymPlan[] = [
  {
    id: 'push-day',
    title: 'Push Day: Chest, Delts & Triceps',
    tagline: 'Hypertrophy & explosive press power for punches and striking',
    category: 'Hypertrophy & Strength',
    estimatedMinutes: 55,
    exercises: [
      {
        id: 'ex-1',
        name: 'Barbell Flat Bench Press',
        muscle: 'Pectoralis Major & Anterior Delts',
        sets: 4,
        reps: '6-8',
        rpe: '8.5',
        rest: '120s',
        cues: ['Plant feet firmly', 'Retract & depress scapulae', 'Touch mid-sternum, drive bar explosively up'],
        completedSets: [true, true, true, false],
        weightLogged: 85,
      },
      {
        id: 'ex-2',
        name: 'Incline Dumbbell Press (30° Angle)',
        muscle: 'Clavicular Upper Chest',
        sets: 3,
        reps: '8-10',
        rpe: '8.0',
        rest: '90s',
        cues: ['Keep elbows tucked at 45°', 'Full stretch at bottom', 'Converge dumbbells slightly at top'],
        completedSets: [true, true, false],
        weightLogged: 32,
      },
      {
        id: 'ex-3',
        name: 'Cable Lean-Away Lateral Raises',
        muscle: 'Lateral Deltoids (Shoulder Width)',
        sets: 4,
        reps: '12-15',
        rpe: '9.0',
        rest: '60s',
        cues: ['Lean slightly away from tower', 'Lead with elbows', 'Pause 1s at parallel height'],
        completedSets: [true, false, false, false],
        weightLogged: 12,
      },
      {
        id: 'ex-4',
        name: 'Overhead Cable Rope Tricep Extension',
        muscle: 'Long Head Triceps',
        sets: 3,
        reps: '10-12',
        rpe: '8.5',
        rest: '60s',
        cues: ['Flare ropes out at lockout', 'Keep upper arms stationary', 'Deep stretch behind head'],
        completedSets: [false, false, false],
        weightLogged: 25,
      },
      {
        id: 'ex-5',
        name: 'Bodyweight Chest Dips (Forward Lean)',
        muscle: 'Lower Pecs & Triceps',
        sets: 3,
        reps: '12-15',
        rpe: '8.0',
        rest: '75s',
        cues: ['Lean torso 30° forward', 'Dip to 90° elbow bend', 'Squeeze chest hard at apex'],
        completedSets: [false, false, false],
      },
    ],
  },
  {
    id: 'pull-day',
    title: 'Pull Day: Back Width, Thickness & Biceps',
    tagline: 'Grip strength, postural lat stability & grappling pulling power',
    category: 'Hypertrophy & Strength',
    estimatedMinutes: 50,
    exercises: [
      {
        id: 'ex-p1',
        name: 'Chest-Supported T-Bar Row',
        muscle: 'Latissimus Dorsi & Rhomboids',
        sets: 4,
        reps: '8-10',
        rpe: '8.5',
        rest: '90s',
        cues: ['Neutral spine against pad', 'Pull elbows toward back pockets', '2s isometric squeeze'],
        completedSets: [false, false, false, false],
        weightLogged: 60,
      },
      {
        id: 'ex-p2',
        name: 'Neutral-Grip Lat Pulldown',
        muscle: 'Lower Lat Fibers',
        sets: 3,
        reps: '10-12',
        rpe: '8.0',
        rest: '75s',
        cues: ['Depress shoulder blades first', 'Drive elbows straight down', 'Control 3-second eccentric'],
        completedSets: [false, false, false],
        weightLogged: 70,
      },
      {
        id: 'ex-p3',
        name: 'Face Pulls with External Rotation',
        muscle: 'Rear Delts & Infraspinatus',
        sets: 4,
        reps: '15-20',
        rpe: '8.0',
        rest: '60s',
        cues: ['Pull rope toward temples', 'Thumbs point backward at finish', 'Essential for puncher posture'],
        completedSets: [false, false, false, false],
        weightLogged: 18,
      },
      {
        id: 'ex-p4',
        name: 'Incline Dumbbell Bicep Curls',
        muscle: 'Biceps Brachii Long Head',
        sets: 3,
        reps: '10-12',
        rpe: '8.5',
        rest: '60s',
        cues: ['Supinate wrists aggressively', 'Keep elbows behind torso', 'No momentum swinging'],
        completedSets: [false, false, false],
        weightLogged: 16,
      },
    ],
  },
  {
    id: 'legs-conditioning',
    title: 'Legs & Combat Conditioning',
    tagline: 'Explosive hip drive, knee resilience, takedown power & footwork agility',
    category: 'Athletic Performance',
    estimatedMinutes: 55,
    exercises: [
      {
        id: 'ex-l1',
        name: 'Barbell Back Squat (Low-Bar or High-Bar)',
        muscle: 'Quadriceps, Glutes & Spinal Erectors',
        sets: 4,
        reps: '5-6',
        rpe: '8.5',
        rest: '150s',
        cues: ['Brace core 360° with Valsalva', 'Break at hips and knees together', 'Explode out of the hole'],
        completedSets: [false, false, false, false],
        weightLogged: 110,
      },
      {
        id: 'ex-l2',
        name: 'Bulgarian Split Squats (Dumbbell)',
        muscle: 'Unilateral Quads & Glute Medius',
        sets: 3,
        reps: '8-10 / leg',
        rpe: '9.0',
        rest: '90s',
        cues: ['Elevate rear foot on bench', 'Descend straight down like an elevator', 'Drives single-leg punch power'],
        completedSets: [false, false, false],
        weightLogged: 24,
      },
      {
        id: 'ex-l3',
        name: 'Romanian Deadlift (RDL)',
        muscle: 'Hamstrings & Posterior Chain',
        sets: 3,
        reps: '8-10',
        rpe: '8.0',
        rest: '90s',
        cues: ['Hinge hips backward to wall', 'Slight knee bend', 'Feel deep hamstring stretch below knees'],
        completedSets: [false, false, false],
        weightLogged: 95,
      },
      {
        id: 'ex-l4',
        name: 'Heavy Bag Tabata Conditioning',
        muscle: 'Full Body Aerobic / Anaerobic Power',
        sets: 5,
        reps: '3 min rounds',
        rpe: '9.5',
        rest: '60s',
        cues: ['Round 1: Speed Jabs & Crosses', 'Round 2: Power Hooks & Body Shots', 'Round 3: Non-stop 1-2 Combos'],
        completedSets: [false, false, false, false, false],
      },
    ],
  },
];

let activeGymPlanId = 'push-day';

// Real-Life Martial Arts Styles & Attack Database
interface MartialAttack {
  id: string;
  name: string;
  type: 'strike' | 'kick' | 'elbow' | 'throw' | 'submission' | 'defense' | 'counter';
  target: string;
  damageType: string;
  mechanics: string;
  steps: string[];
  cues: string[];
  keyMistake: string;
  damageScore: number; // 1-100
  speedScore: number; // 1-100
}

interface MartialArt {
  id: string;
  name: string;
  origin: string;
  founder: string;
  icon: string;
  category: 'Striking' | 'Grappling' | 'Hybrid' | 'Self-Defense';
  desc: string;
  philosophy: string;
  enrolled: boolean;
  level: number; // 1 to 5
  currentBelt: string;
  trainingHours: number;
  duration: string;
  gearRequired: string[];
  stances: string[];
  signatureCombos: string[];
  attacks: MartialAttack[];
}

let martialArtsList: MartialArt[] = [
  {
    id: 'muay-thai',
    name: 'Muay Thai (The Art of 8 Limbs)',
    origin: 'Thailand (Siam Warfare)',
    founder: 'Nai Khanom Tom & Siamese Warriors',
    icon: '🇹🇭',
    category: 'Striking',
    desc: 'The stand-up combat discipline utilizing fists, shins, elbows, and knees with heavy bone conditioning and clinching dominance.',
    philosophy: 'Transform the human body into nine battlefield weapons. Strike with the hardness of ironwood and flow like monsoon rain.',
    enrolled: true,
    level: 3,
    currentBelt: 'Prajioud Red/White Armband',
    trainingHours: 72,
    duration: '60 min sessions',
    gearRequired: ['Muay Thai Shin Guards', '14oz Gloves', 'Heavy Thai Pads', 'Ankle Wraps'],
    stances: ['Square High Guard Stance', 'Marching Front Rhythm (Teep Feint Stance)'],
    signatureCombos: [
      'Lead Teep - Rear Low Calf Kick',
      'Jab - Cross - Step-In Horizontal Elbow',
      'Double Collar Plum Clinch - Alternating Knee Drives',
    ],
    attacks: [
      {
        id: 'mt-teep',
        name: 'Push Kick (Teep)',
        type: 'kick',
        target: 'Solar Plexus, Hip Crest, Sternum',
        damageType: 'Distance Disruptor / Blunt Force',
        mechanics: 'Chamber knee to chest level, stab ball of foot forward into opponent\'s center of gravity like a spear.',
        steps: [
          'Chamber lead knee tight toward chest.',
          'Thrust hips forward, extending ball of foot into opponent\'s abdomen.',
          'Swing lead arm down for counter-balance.',
          'Recoil knee back immediately to avoid kick being caught.',
        ],
        cues: ['Front foot spear', 'Pop hips forward', 'Keep posture tall and balanced'],
        keyMistake: 'Kicking with flat foot rather than ball of foot, losing penetration depth.',
        damageScore: 78,
        speedScore: 90,
      },
      {
        id: 'mt-calf',
        name: 'Chopping Low Calf Kick',
        type: 'kick',
        target: 'Common Peroneal Nerve (Outer Shin/Calf)',
        damageType: 'Nerve Deadening / Mobility Loss',
        mechanics: 'Step 45 degrees outside lead foot, swing rear leg like a baseball bat, striking with lower third of tibia.',
        steps: [
          'Take a 45-degree lateral step with non-kicking foot.',
          'Swing kicking leg in a rigid baseball bat trajectory.',
          'Rotate hips 180 degrees over the target.',
          'Drive dense shin bone directly into the side of opponent\'s lower leg.',
        ],
        cues: ['Hit with hard shin bone, not foot', 'Turn hip completely over', 'Whip the arm downward'],
        keyMistake: 'Striking with the fragile top of foot, risking bone fractures against shin checks.',
        damageScore: 92,
        speedScore: 89,
      },
      {
        id: 'mt-elbow',
        name: 'Slicing Horizontal Elbow (Sok Tad)',
        type: 'elbow',
        target: 'Eyebrow Ridge, Temple, Jaw',
        damageType: 'Laceration & Knockout',
        mechanics: 'Step inside guard, snap point of olecranon bone across the face at eyebrow level with extreme rotational speed.',
        steps: [
          'Close distance into phone-booth pocket.',
          'Turn lead hand palm down toward chest, making the elbow point razor sharp.',
          'Rotate upper torso swiftly, slicing across opponent\'s eyebrow.',
          'Cover opposing side of face with opposite glove.',
        ],
        cues: ['Shortest and sharpest strike in combat', 'Cut across like a blade', 'Step through on impact'],
        keyMistake: 'Leaving chin exposed in the pocket without keeping rear guard tight.',
        damageScore: 96,
        speedScore: 94,
      },
    ],
  },
  {
    id: 'taekwondo',
    name: 'Taekwondo (Way of Foot and Fist)',
    origin: 'Korea (Kukkiwon)',
    founder: 'General Choi Hong Hi & Masters',
    icon: '🥋',
    category: 'Striking',
    desc: 'The acrobatic science of long-range ballistic kicks, spinning heel strikes, 360-degree rotations, and lightning-fast footwork blitzes.',
    philosophy: 'Indomitable spirit. Reach distances where fists cannot touch, using the longest and strongest limbs.',
    enrolled: false,
    level: 1,
    currentBelt: 'Yellow Belt',
    trainingHours: 18,
    duration: '50 min sessions',
    gearRequired: ['Dobok Uniform', 'Chest Protector (Hogu)', 'Foot & Forearm Pads'],
    stances: ['Side-Bladed Kicking Stance', 'Front Stance (Ap Kubi)'],
    signatureCombos: [
      'Lead Leg Cut Kick into Jumping Roundhouse',
      'Feint Blitz into Dwi Chagi (Back Kick)',
      'Tornado 360 Kick Series',
    ],
    attacks: [
      {
        id: 'tkd-backkick',
        name: 'Dwi Chagi (Straight Back Kick)',
        type: 'kick',
        target: 'Solar Plexus, Liver, Sternum',
        damageType: 'Horse Kick / Penetrating Blunt Impact',
        mechanics: 'Turn back toward target, glance over shoulder, chamber knee close to chest, and fire heel straight back like a piston.',
        steps: [
          'Pivot lead foot 180 degrees, turning back to opponent.',
          'Look over kicking shoulder to spot target.',
          'Chamber kicking knee tight to opposing knee.',
          'Piston-drive heel straight back into opponent\'s stomach.',
        ],
        cues: ['Look before you kick', 'Straight linear line like a mule kick', 'Re-chamber immediately'],
        keyMistake: 'Swinging leg in a circle like a spin kick instead of driving straight back like a piston.',
        damageScore: 95,
        speedScore: 90,
      },
      {
        id: 'tkd-tornado',
        name: 'Tornado 360 Kick (Dollyo Chagi Spin)',
        type: 'kick',
        target: 'Temple, Jawline',
        damageType: 'Rotational Knockout Velocity',
        mechanics: 'Spin 360 degrees off lead foot, lift fake knee to generate upward torque, and snap trailing leg roundhouse into head.',
        steps: [
          'Initiate 180 spin step toward open side.',
          'Jump and chamber non-kicking knee to elevate center of gravity.',
          'Switch hips in mid-air, releasing kicking leg in whipping roundhouse.',
          'Land in balanced fighting stance.',
        ],
        cues: ['Commit to the head rotation first', 'Jump off the ball of the foot', 'Snap like a whip at apex'],
        keyMistake: 'Under-rotating the hips, causing kick to slide harmlessly off the guard.',
        damageScore: 94,
        speedScore: 96,
      },
    ],
  },
  {
    id: 'tai-chi',
    name: 'Tai Chi Chuan (Supreme Ultimate Fist)',
    origin: 'Chen Village / Wudang Mountains, China',
    founder: 'Chen Wangting / Zhang Sanfeng',
    icon: '☯️',
    category: 'Striking',
    desc: 'The ancient internal martial art of dynamic balance, kinetic structural alignment, centrifugal energy release (Fa Jin), and yielding to overcome hard force.',
    philosophy: 'Use four ounces of pressure to deflect a thousand pounds. Softness overcomes hardness, stillness directs motion.',
    enrolled: false,
    level: 1,
    currentBelt: 'White Sash',
    trainingHours: 14,
    duration: '45 min sessions',
    gearRequired: ['Silk Training Uniform', 'Flat Cotton Shoes'],
    stances: ['Horse Riding Stance (Ma Bu)', 'Bow Stance (Gong Bu)', 'Empty Stance (Xu Bu)'],
    signatureCombos: [
      'Grasp the Sparrow\'s Tail (Ward-Off -> Rollback -> Press -> Push)',
      'Single Whip deflection into Palm Strike',
      'White Crane Spreads Wings defensive sweep',
    ],
    attacks: [
      {
        id: 'tc-pushhands',
        name: 'Peng & Lu (Ward-Off & Rollback Fa Jin)',
        type: 'counter',
        target: 'Opponent Center of Gravity / Off-Balance',
        damageType: 'Kinetic Re-Direction & Uproot',
        mechanics: 'Absorb incoming linear force with rounded forearm arc, rotate waist to divert momentum, and release explosive whole-body Fa Jin thrust.',
        steps: [
          'Maintain relaxed dropped shoulders and sunken elbows.',
          'As force contacts forearm, yield 3 inches rotating from the dantian waist.',
          'Lead opponent\'s force into empty space past your flank.',
          'Root through rear foot and snap hips forward to uproot opponent backward.',
        ],
        cues: ['Never resist force directly', 'Rotate the core cylinder', 'Explode from the soles of feet'],
        keyMistake: 'Tensing the shoulders and pushing with arm muscles, losing structural rooting.',
        damageScore: 82,
        speedScore: 88,
      },
      {
        id: 'tc-singlewhip',
        name: 'Single Whip (Dan Bian Palm Strike)',
        type: 'strike',
        target: 'Carotid, Throat, Solar Plexus',
        damageType: 'Internal Centrifugal Shockwave',
        mechanics: 'Form hook hand with rear wrist to trap, step out deep into bow stance, and unleash an expanding lead palm strike.',
        steps: [
          'Hook rear hand to deflect and control incoming limb.',
          'Step left leg out into balanced 70/30 bow stance.',
          'Extend left palm in wide circular arc, transferring weight smoothly.',
          'Strike with heel of palm, aligning wrist with spine.',
        ],
        cues: ['Expand chest like an eagle', 'Heel of palm connects with spine power', 'Sink hips'],
        keyMistake: 'Over-extending the striking arm and losing balance off the center axis.',
        damageScore: 86,
        speedScore: 85,
      },
    ],
  },
  {
    id: 'karate',
    name: 'Karate (The Way of the Empty Hand)',
    origin: 'Okinawa / Japan (Shotokan & Kyokushin)',
    founder: 'Gichin Funakoshi & Masutatsu Oyama',
    icon: '🥋',
    category: 'Striking',
    desc: 'Linear concussive striking, structural hip torque, bone conditioning, and explosive decisive blows designed to neutralize opponents in one shot (Ikken Hissatsu).',
    philosophy: 'To win one hundred victories in one hundred battles is not the highest skill. To subdue the enemy without fighting is the highest skill.',
    enrolled: false,
    level: 1,
    currentBelt: 'White Belt',
    trainingHours: 12,
    duration: '60 min sessions',
    gearRequired: ['Heavy Cotton Karate Gi', 'Mouthguard', 'Knuckle Pads'],
    stances: ['Front Stance (Zenkutsu Dachi)', 'Back Stance (Kokutsu Dachi)', 'Horse Stance (Kiba Dachi)'],
    signatureCombos: [
      'Mae Geri (Front Kick) - Gyaku Zuki (Reverse Punch)',
      'Age Uke (Rising Block) into Gedan Mawashi Geri',
      'Shuto Uchi (Knife Hand) to carotid artery',
    ],
    attacks: [
      {
        id: 'kr-gyaku',
        name: 'Gyaku Zuki (Reverse Thrust Punch)',
        type: 'strike',
        target: 'Solar Plexus, Ribs, Sternum',
        damageType: 'Linear Structural Impact',
        mechanics: 'From deep Zenkutsu Dachi, rotate rear hip forward 45°, fire fist corkscrewing at terminal impact while pulling opposite hand to chamber.',
        steps: [
          'Sink into low 60/40 Zenkutsu Dachi front stance.',
          'Explosively rotate rear hip forward while driving rear heel flat to floor.',
          'Thrust reverse punch in laser line, rotating fist 180 degrees at impact.',
          'Hikite: pull lead hand hard back to hip to balance torque.',
        ],
        cues: ['Hikite pull generates kinetic torque', 'Lock rear knee on impact', 'Drive through target'],
        keyMistake: 'Lifting the rear heel off the ground, bleeding 40% of ground reaction force.',
        damageScore: 92,
        speedScore: 91,
      },
      {
        id: 'kr-mawashigeri',
        name: 'Mawashi Geri (Roundhouse Kick to Ribs)',
        type: 'kick',
        target: 'Floating Ribs, Neck',
        damageType: 'Blunt Concussive Bone Impact',
        mechanics: 'Chamber knee sideways parallel to deck, whip lower leg through target, striking with instep or ball of foot.',
        steps: [
          'Pivot standing foot 135 degrees outward.',
          'Chamber kicking knee horizontally at hip height.',
          'Snap lower leg outward like a whip.',
          'Recoil knee back immediately along the same path.',
        ],
        cues: ['Knee points at target before extension', 'Snap back instantly', 'Guard hands up'],
        keyMistake: 'Swinging leg straight without chambering the knee, slowing strike velocity.',
        damageScore: 89,
        speedScore: 93,
      },
    ],
  },
  {
    id: 'bjj',
    name: 'Brazilian Jiu-Jitsu (BJJ)',
    origin: 'Brazil (Carlos & Hélio Gracie / Maeda)',
    founder: 'Hélio Gracie, Carlos Gracie',
    icon: '🥋',
    category: 'Grappling',
    desc: 'The gentle art of leverage, ground control, position before submission, joint hyperextensions, and strangles that neutralize size and strength.',
    philosophy: 'The ground is the great equalizer. Where strength fails, leverage, friction, and biomechanics reign supreme.',
    enrolled: true,
    level: 2,
    currentBelt: 'Blue Belt (2 Stripes)',
    trainingHours: 96,
    duration: '75 min sessions',
    gearRequired: ['BJJ Gi (Kimono)', 'No-Gi Rashguard & Spats', 'Mouthguard', 'Knee Sleeves'],
    stances: ['Low Grappling Stance with Hands Out', 'Closed Guard', 'Open Butterfly Guard', 'Side Control'],
    signatureCombos: [
      'Scissor Sweep into Full Mount',
      'Cross Collar Choke threat to Armbar transition',
      'Sprawl - Snap Down - Front Headlock Guillotine',
    ],
    attacks: [
      {
        id: 'bjj-rnc',
        name: 'Rear Naked Choke (Mata Leão)',
        type: 'submission',
        target: 'Carotid Arteries (Bilateral Neck)',
        damageType: 'Blood Choke / Safe Sleep (6-8s)',
        mechanics: 'Slip bicep under chin, wedge crook of elbow under trachea, lock opposing hand on bicep and place palm behind head.',
        steps: [
          'Establish seatbelt control on opponent\'s back with hooks in.',
          'Slide attacking forearm under chin so elbow aligns with larynx.',
          'Grab opposing bicep; tuck other hand behind opponent\'s head.',
          'Inhale deeply, expand chest, and squeeze elbows together.',
        ],
        cues: ['Elbow centered under chin', 'Hide the lock hand behind head', 'Zero space between chests'],
        keyMistake: 'Squeezing only with arms instead of expanding upper torso and hips.',
        damageScore: 100,
        speedScore: 82,
      },
      {
        id: 'bjj-triangle',
        name: 'Triangle Choke (Sankaku Jime)',
        type: 'submission',
        target: 'Carotid Artery & Trapped Shoulder',
        damageType: 'Vascular Occlusion / Tapout',
        mechanics: 'From guard, isolate one arm inside while one is out. Lock knee over opposing shin, creating a suffocating clamp.',
        steps: [
          'Push one of opponent\'s wrists into their chest while clearing the other outside.',
          'Shoot legs up high around neck and one trapped shoulder.',
          'Cut a 90-degree angle to the trapped arm side.',
          'Lock crook of your knee over your opposite ankle/shin and pull head down gently.',
        ],
        cues: ['One arm in, one arm out', 'Cut the angle perpendicular', 'Hide the shoulder'],
        keyMistake: 'Failing to cut the angle, attempting to squeeze while directly facing the opponent.',
        damageScore: 97,
        speedScore: 80,
      },
    ],
  },
  {
    id: 'kung-fu',
    name: 'Kung Fu (Shaolin & Wushu Systems)',
    origin: 'Henan Province, China (Shaolin Temple)',
    founder: 'Bodhidharma & Shaolin Warrior Monks',
    icon: '🐉',
    category: 'Striking',
    desc: 'Dynamic fluid striking, low rooted stances, explosive rotational torso torque, and Five Animal styles (Tiger, Crane, Leopard, Snake, Dragon).',
    philosophy: 'Train body and spirit in unison. Flow like water, strike like thunder, root like the pine mountain.',
    enrolled: false,
    level: 1,
    currentBelt: 'Yellow Sash',
    trainingHours: 16,
    duration: '60 min sessions',
    gearRequired: ['Shaolin Monk Robes / Training Pants', 'Feiyue Canvas Shoes'],
    stances: ['Horse Stance (Ma Bu)', 'Drop Stance (Pu Bu)', 'Dragon Stance'],
    signatureCombos: [
      'Crane Wing Block - Tiger Palm Strike',
      'Dragon Whip Roundhouse - Sweeping Low Leg',
      'Double Iron Fist Burst from Horse Stance',
    ],
    attacks: [
      {
        id: 'kf-ironpalm',
        name: 'Iron Palm Centerline Thrust',
        type: 'strike',
        target: 'Sternum, Solar Plexus, Chin',
        damageType: 'Deep Tissue Vibrational Impact',
        mechanics: 'Sink into dropped stance, whip hand forward with relaxed shoulder, transferring bone density through the heel of the palm.',
        steps: [
          'Sink weight into Ma Bu stance, loading kinetic energy in the hips.',
          'Thrust lead palm along centerline with relaxed arm until final 2 inches.',
          'Snap heel of the palm through target with sudden full-body tension.',
          'Exhale with vocalized breath to reinforce core brace.',
        ],
        cues: ['Relaxed whip until terminal impact', 'Strike with heel of palm', 'Drop your center of mass'],
        keyMistake: 'Tightening arm before strike travels, losing whipping velocity.',
        damageScore: 91,
        speedScore: 94,
      },
    ],
  },
  {
    id: 'krav-maga',
    name: 'Krav Maga (Tactical Self-Defense)',
    origin: 'Israel (IDF Combat Fitness)',
    founder: 'Imi Lichtenfeld',
    icon: '🛡️',
    category: 'Self-Defense',
    desc: 'Instinctive, realistic self-defense system emphasizing aggression neutralization, 360-degree defense, weapon disarms, and tactical escape.',
    philosophy: 'Avoid confrontation whenever possible. If attack is inevitable, finish it in under 5 seconds with extreme efficiency and escape safely.',
    enrolled: false,
    level: 1,
    currentBelt: 'Practitioner 1 (P1)',
    trainingHours: 20,
    duration: '60 min sessions',
    gearRequired: ['Groin Cup', 'Mouthguard', 'Focus Mitts'],
    stances: ['Passive De-Escalation Stance (Hands Open at Chest)', 'Tactical Combat Stance'],
    signatureCombos: [
      'De-escalation verbal commands + Sudden Groin Kick',
      '360 Outside Defense with Simultaneous Straight Punch',
      'Two-Hand Choke Release (Pluck and Drive)',
    ],
    attacks: [
      {
        id: 'km-360',
        name: '360° Defense + Simultaneous Counter-Punch',
        type: 'defense',
        target: 'Deflect Circular Attack + Counter Jaw',
        damageType: 'Simultaneous Neutralization',
        mechanics: 'Forearm blocks incoming swing at 90 degrees while other fist punches directly through attacker\'s nose/jaw in one motion.',
        steps: [
          'Explode forward diagonally toward the attack origin.',
          'Form 90-degree knife-edge block with forearm against attacker\'s wrist.',
          'Simultaneously launch a straight punch directly into attacker\'s face.',
          'Follow with groin kick and sprint to safety.',
        ],
        cues: ['Defense and attack happen at the EXACT same millisecond', 'Drive forward, don\'t retreat', 'Scan for secondary threats'],
        keyMistake: 'Blocking first and waiting to punch second, allowing attacker to recoil and hit again.',
        damageScore: 88,
        speedScore: 96,
      },
    ],
  },
  {
    id: 'judo',
    name: 'Kodokan Judo (The Gentle Way)',
    origin: 'Japan (1882)',
    founder: 'Jigoro Kano',
    icon: '🥋',
    category: 'Grappling',
    desc: 'The Olympic discipline of maximum efficiency and mutual welfare, specializing in sweeping throws, foot reaps, and off-balancing.',
    philosophy: 'Maximum efficiency with minimum effort. Yield to force in order to overcome it.',
    enrolled: false,
    level: 1,
    currentBelt: 'White Belt',
    trainingHours: 22,
    duration: '60 min sessions',
    gearRequired: ['Single/Double Weave Judo Gi', 'Heavy Tatami Mats', 'Mouthguard'],
    stances: ['Shizentai (Natural Posture)', 'Kumikata (Lapel and Sleeve Grip)'],
    signatureCombos: [
      'Kuzushi lapel snap into Osoto Gari',
      'Ippon Seoi Nage (Single Arm Shoulder Throw)',
      'Ouchi Gari feint into Uchi Mata',
    ],
    attacks: [
      {
        id: 'jd-seoi',
        name: 'Ippon Seoi Nage (One-Arm Shoulder Throw)',
        type: 'throw',
        target: 'Slam Opponent onto Back (Ippon)',
        damageType: 'High-Impact Kinetic Floor Impact',
        mechanics: 'Pull sleeve forward to break balance (Kuzushi), pivot 180° back-to-chest, load opponent onto back, and wheel over shoulder.',
        steps: [
          'Pull right sleeve forward and upward to pull opponent onto tiptoes.',
          'Step right foot inside opponent\'s stance and spin 180 degrees.',
          'Clamp right armpit tightly over opponent\'s right arm.',
          'Bend knees, straighten legs, and bow torso forward to launch opponent over.',
        ],
        cues: ['Kuzushi first, entry second', 'Drop your hips lower than opponent\'s hips', 'Steer them onto their flat back'],
        keyMistake: 'Failing to pull the sleeve, trying to lift an opponent whose weight is anchored backward.',
        damageScore: 95,
        speedScore: 86,
      },
      {
        id: 'jd-osoto',
        name: 'Osoto Gari (Major Outer Reap)',
        type: 'throw',
        target: 'Leg Reap + Back Mat Impact',
        damageType: 'Rotational Leg Takedown',
        mechanics: 'Step deep next to opponent\'s lead foot, press chest to chest, swing your leg high and reap their weight-bearing leg out.',
        steps: [
          'Pull lapel and sleeve diagonally down to pin weight on opponent\'s right heel.',
          'Step your left foot deeply outside their right foot.',
          'Drive chest against their chest.',
          'Swing right leg like a scythe, reaping their calf/hamstring to trip them backwards.',
        ],
        cues: ['Chest to chest connection', 'Reap the standing leg cleanly', 'Keep your head upright'],
        keyMistake: 'Leaning backward during the reap, causing yourself to be countered.',
        damageScore: 92,
        speedScore: 84,
      },
    ],
  },
  {
    id: 'capoeira',
    name: 'Capoeira (Afro-Brazilian Martial Art)',
    origin: 'Bahia, Brazil (16th Century)',
    founder: 'African Descendants in Colonial Brazil',
    icon: '🇧🇷',
    category: 'Striking',
    desc: 'The acrobatic dance-fight discipline combining continuous rhythmic movement (Ginga), deceptive ground evasions, sweeps, and inverted kicks to the rhythm of the berimbau.',
    philosophy: 'Malandragem—cunning and deception. Never remain stationary; move with the rhythm of the circle (Roda) and convert defense into sudden centrifugal power.',
    enrolled: false,
    level: 1,
    currentBelt: 'Crua (Natural Cord)',
    trainingHours: 10,
    duration: '60 min sessions',
    gearRequired: ['Abadá White Pants', 'Cordão Belt', 'Berimbau Musical Bow'],
    stances: ['Ginga (Continuous Triangular Base Movement)', 'Resistência Low Guard', 'Queda de Quatro'],
    signatureCombos: [
      'Ginga step - Esquiva Baixa (Evasion) - Meia Lua de Compasso',
      'Armada Kick feint into Rasteira Leg Sweep',
      'Au (Cartwheel Evasion) into Martelo de Chão',
    ],
    attacks: [
      {
        id: 'cap-compasso',
        name: 'Meia Lua de Compasso (Compass Crescent Kick)',
        type: 'kick',
        target: 'Jaw, Temples, Floating Ribs',
        damageType: 'Inverted Rotational Knockout',
        mechanics: 'Step deep outside opponent, drop both hands to the deck between feet, look between legs, and whip rear heel in a 360° horizontal compass arc.',
        steps: [
          'Step deep across opponent with lead foot, turning back to them.',
          'Bend forward and place both palms on the deck between your legs for support.',
          'Look backward between your thighs to lock eyes on the target.',
          'Whip the rear leg in a flat, high-velocity circular arc like a compass.',
        ],
        cues: ['Keep both hands planted for tripod stability', 'Look at target between legs', 'Heel is the battering ram'],
        keyMistake: 'Lifting head up and looking away from target during rotation, causing kick to miss.',
        damageScore: 97,
        speedScore: 91,
      },
      {
        id: 'cap-armada',
        name: 'Armada (Spinning Outside Crescent Kick)',
        type: 'kick',
        target: 'Head, Ear, Jawline',
        damageType: 'Rotational Blunt Force',
        mechanics: 'From Ginga, cross rear foot forward, spin 360° on the balls of the feet, and snap straight leg in an outside-to-inside crescent arc.',
        steps: [
          'Cross rear leg over lead leg at 45 degree angle.',
          'Pivot 360 degrees on balls of both feet until facing opponent again.',
          'Release rear leg straight into an outside crescent trajectory.',
          'Land cleanly back into Ginga rhythm.',
        ],
        cues: ['Head turns first to spot target', 'Keep core tight', 'Recoil back to Ginga'],
        keyMistake: 'Swinging leg before head spots the target, losing accuracy.',
        damageScore: 89,
        speedScore: 92,
      },
    ],
  },
  {
    id: 'mma',
    name: 'Mixed Martial Arts (Modern MMA)',
    origin: 'Pankration / Vale Tudo / Modern Octagon',
    founder: 'Modern Unified Rules Combat Athletes',
    icon: '⚡',
    category: 'Hybrid',
    desc: 'The seamless synthesis of stand-up striking, cage wall wrestling, level-change takedowns, clinch knees, and ground-and-pound dominance.',
    philosophy: 'Adapt what is useful, reject what is useless, add what is uniquely your own. Own all ranges of combat without hesitation.',
    enrolled: true,
    level: 3,
    currentBelt: 'Pro Combat Rank',
    trainingHours: 110,
    duration: '75 min sessions',
    gearRequired: ['4oz MMA Fight Gloves', 'Mouthguard', 'MMA Board Shorts & Rashguard', 'Grappling Shin Guards'],
    stances: ['Square Hybrid Combat Stance (Low Sprawl Ready)'],
    signatureCombos: [
      'Overhand Right - Level Change Blast Double Takedown',
      'Cage Clinch Underhooks - Dirty Boxing Upper Hook - Knee to Thigh',
      'Jab-Cross-Leg Kick into Ground-and-Pound Posture',
    ],
    attacks: [
      {
        id: 'mma-double',
        name: 'Blast Double Leg to Cage Takedown',
        type: 'throw',
        target: 'Full Takedown & Octagon Mat Control',
        damageType: 'High Kinetic Acceleration Mat Drive',
        mechanics: 'Change levels below opponent\'s guard, penetrate deep between thighs, wrap both knees, drive forehead into solar plexus, and turn the corner.',
        steps: [
          'Throw a feint jab to force opponent\'s guard high.',
          'Drop hips and change level without leaning forward.',
          'Take a deep penetration step between opponent\'s feet.',
          'Lock arms behind knees, drive forehead into chest, and cut the corner 45° to slam opponent to mat.',
        ],
        cues: ['Head in the chest, not outside', 'Drive with legs like a linebacker', 'Turn the corner to finish'],
        keyMistake: 'Dropping head to the outside where opponent can wrap a guillotine choke.',
        damageScore: 94,
        speedScore: 95,
      },
      {
        id: 'mma-gnp',
        name: 'Ground-and-Pound Postured Hammerfist',
        type: 'strike',
        target: 'Jaw, Cheekbone, Brow (From Guard/Mount)',
        damageType: 'Gravity-Assisted Heavy Blunt Impact',
        mechanics: 'From guard or mount, pin opponent\'s wrist with one hand, posture upright to create distance, and drop heavy hammerfist with full gravity.',
        steps: [
          'Pin one of opponent\'s wrists to the mat with lead hand.',
          'Posture up tall, engaging core and glutes.',
          'Raise rear fist high and drop bottom heel of the fist like a sledgehammer.',
          'Immediately re-establish posture to avoid sweeps.',
        ],
        cues: ['Use gravity and hip weight', 'Strike with bottom fleshy heel of fist', 'Maintain base balance'],
        keyMistake: 'Leaning forward into opponent\'s chest, eliminating punching space.',
        damageScore: 96,
        speedScore: 89,
      },
    ],
  },
];

// Customizable Dashboard Widget Configuration
export interface DashboardWidget {
  id: string;
  name: string;
  description: string;
  category: 'bio' | 'fitness' | 'skincare' | 'martial' | 'ai' | 'community';
  visible: boolean;
  order: number;
  width: 'full' | 'half'; // 'full' takes 2 columns, 'half' takes 1
}

const defaultWidgets: DashboardWidget[] = [
  { id: 'readiness_biomarkers', name: 'Biomarkers & Readiness', description: 'Real-time readiness score, hydration, sleep duration, and recovery %', category: 'bio', visible: true, order: 1, width: 'full' },
  { id: 'jarvis_console', name: 'Jarvis AI / Nandu Admin HUD', description: 'Live interactive tactical AI coach for advice, science & de-escalation', category: 'ai', visible: true, order: 2, width: 'full' },
  { id: 'gym_routine', name: 'Gym Training Routine', description: 'Active gym split (Push/Pull/Legs), exercise tracking, weight & set logging', category: 'fitness', visible: true, order: 3, width: 'half' },
  { id: 'skincare_routine', name: 'Athletic Skincare Routine', description: 'Science-backed AM, Post-Gym, and PM skin barrier preservation checklist', category: 'skincare', visible: true, order: 4, width: 'half' },
  { id: 'martial_arts_hub', name: 'Martial Arts Dojo & Syllabus', description: 'Active enrolled martial arts, technique mastery, combos & training logs', category: 'martial', visible: true, order: 5, width: 'full' },
  { id: 'quick_actions', name: 'Instant Health & Log Actions', description: 'One-tap water intake, rapid workout logging, sleep and recovery tracking', category: 'fitness', visible: true, order: 6, width: 'half' },
  { id: 'weekly_activity', name: '7-Day Activity & Intensity', description: 'Volume load, daily training intensity, and weekly bar graph analytics', category: 'fitness', visible: true, order: 7, width: 'half' },
  { id: 'self_defense_protocol', name: 'De-Escalation & Safety Protocol', description: 'Nandu Admin tactical rules for de-escalating violence and legal self-defense', category: 'martial', visible: true, order: 8, width: 'half' },
  { id: 'crew_community', name: 'Training Crew & Sparring Feed', description: 'Community updates, shared milestones, sparring partners online', category: 'community', visible: true, order: 9, width: 'half' },
];

let userWidgets: DashboardWidget[] = JSON.parse(JSON.stringify(defaultWidgets));

// Community Posts Feed
let communityPosts = [
  {
    id: 'p1',
    authorName: 'Marcus Vance',
    authorInitial: 'M',
    text: 'Hit a clean 100kg Bench for 5 reps on Push Day! Then 4 rounds of Muay Thai heavy bag teeps. Hydration at 3.2L today. Keep grinding nakama! 🥋🔥',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    likes: ['usr_default_01'],
  },
  {
    id: 'p2',
    authorName: 'Dr. Elena Rostova',
    authorInitial: 'E',
    text: 'Reminder to all BJJ & wrestling athletes: wash your face with BHA or Hypochlorous acid mist immediately after mat work! Mat fungi and bacteria are no joke for the skin barrier. 🧴🧼',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    likes: [],
  },
  {
    id: 'p3',
    authorName: 'Kenji Takahashi',
    authorInitial: 'K',
    text: 'Drilled the Ippon Seoi Nage shoulder throw 50 times tonight in Judo class. The key was definitely the Kuzushi sleeve pull. Jarvis AI recommended 20 mins ice recovery for my shoulder.',
    createdAt: new Date(Date.now() - 1000 * 60 * 420).toISOString(),
    likes: ['usr_default_01'],
  },
];

let trainingPartners = [
  { id: 'pr1', name: 'Zack Chen (Boxing 4-0)', status: 'online', focus: 'Boxing & Powerlifting' },
  { id: 'pr2', name: 'Aria Sharma (BJJ Purple)', status: 'online', focus: 'BJJ & Mobilty' },
  { id: 'pr3', name: 'Liam O\'Connor (Muay Thai)', status: 'away', focus: 'Muay Thai & Running' },
  { id: 'pr4', name: 'Elena Vance (Dermatology)', status: 'offline', focus: 'Athletic Skincare & HIIT' },
];

// ==========================================
// API Routes
// ==========================================

// Current user auth status
app.get('/api/auth/me', (_req: Request, res: Response) => {
  res.json({
    authenticated: !!currentUser,
    user: currentUser,
  });
});

// Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Please enter both email and password.' });
  }

  // Set current user
  currentUser = {
    id: 'usr_' + Date.now().toString(36),
    name: email.split('@')[0].toUpperCase(),
    email: email,
    avatar: email.charAt(0).toUpperCase(),
    isGoogle: false,
    joinedAt: new Date().toISOString(),
  };

  res.json({ success: true, user: currentUser });
});

// Register
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'All fields are required.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  }

  currentUser = {
    id: 'usr_' + Date.now().toString(36),
    name: name,
    email: email,
    avatar: name.charAt(0).toUpperCase(),
    isGoogle: false,
    joinedAt: new Date().toISOString(),
  };

  res.json({ success: true, user: currentUser });
});

// Google Account 1-Click Connect
app.post('/api/auth/google', (req: Request, res: Response) => {
  const { googleEmail, googleName } = req.body;
  const emailToUse = googleEmail || 'madhu0007.m@gmail.com';
  const nameToUse = googleName || 'Madhu (Google Verified)';

  currentUser = {
    id: 'usr_goog_' + Date.now().toString(36),
    name: nameToUse,
    email: emailToUse,
    avatar: 'G',
    isGoogle: true,
    joinedAt: new Date().toISOString(),
  };

  res.json({ success: true, user: currentUser });
});

// Logout
app.post('/api/auth/logout', (_req: Request, res: Response) => {
  currentUser = null;
  res.json({ success: true });
});

// Get Stats (Readiness, Hydration, Sleep, Skincare)
app.get('/api/stats', (_req: Request, res: Response) => {
  res.json(stats);
});

// Patch Metric (Hydration, Sleep, etc.)
app.patch('/api/stats/metric', (req: Request, res: Response) => {
  const { metric, value } = req.body;
  if (metric === 'hydration') {
    stats.hydration = Math.max(0, Math.min(6, Number(value) || 0));
  } else if (metric === 'sleep') {
    stats.sleep = Math.max(0, Math.min(14, Number(value) || 0));
  } else if (metric === 'readiness') {
    stats.readiness = Math.max(0, Math.min(100, Number(value) || 0));
  }
  // Recompute recovery
  stats.recovery = Math.round((stats.readiness * 0.5) + (Math.min(stats.sleep, 8) / 8 * 50));
  res.json({ success: true, stats });
});

// Log Workout
app.post('/api/stats/workout', (req: Request, res: Response) => {
  const { name, duration, calories } = req.body;
  const newTraining = {
    id: 't_' + Date.now(),
    name: name || 'General Training Session',
    duration: Number(duration) || 45,
    calories: Number(calories) || 350,
    timestamp: 'Just now',
  };
  stats.training.unshift(newTraining);
  if (stats.training.length > 8) stats.training.pop();
  res.json({ success: true, training: stats.training });
});

// Toggle Skincare item status
app.patch('/api/stats/skincare', (req: Request, res: Response) => {
  const { id, name, status } = req.body;
  const item = stats.skincare.find(s => s.id === id || s.name === name);
  if (item) {
    item.status = status;
    return res.json({ success: true, item });
  }
  res.status(404).json({ error: 'Skincare routine item not found.' });
});

// Get Gym Plans
app.get('/api/gym', (_req: Request, res: Response) => {
  res.json({
    activePlanId: activeGymPlanId,
    plans: gymPlans,
  });
});

// Complete Gym Set
app.post('/api/gym/complete-set', (req: Request, res: Response) => {
  const { planId, exerciseId, setIndex, weight } = req.body;
  const plan = gymPlans.find(p => p.id === (planId || activeGymPlanId));
  if (!plan) return res.status(404).json({ error: 'Plan not found.' });
  const ex = plan.exercises.find(e => e.id === exerciseId);
  if (!ex) return res.status(404).json({ error: 'Exercise not found.' });

  if (typeof setIndex === 'number' && setIndex >= 0 && setIndex < ex.completedSets.length) {
    ex.completedSets[setIndex] = !ex.completedSets[setIndex];
  }
  if (typeof weight === 'number') {
    ex.weightLogged = weight;
  }
  res.json({ success: true, exercise: ex });
});

// Switch Active Gym Plan
app.post('/api/gym/switch-plan', (req: Request, res: Response) => {
  const { planId } = req.body;
  if (gymPlans.some(p => p.id === planId)) {
    activeGymPlanId = planId;
    return res.json({ success: true, activeGymPlanId });
  }
  res.status(400).json({ error: 'Invalid plan id.' });
});

// Get Martial Arts
app.get('/api/arts', (_req: Request, res: Response) => {
  res.json(martialArtsList);
});

// Enroll / Unenroll Martial Art
app.post('/api/arts/enroll', (req: Request, res: Response) => {
  const { artId, artName } = req.body;
  const art = martialArtsList.find(a => a.id === artId || a.name === artName);
  if (art) {
    art.enrolled = true;
    return res.json({ success: true, art });
  }
  res.status(404).json({ error: 'Art not found.' });
});

app.delete('/api/arts/enroll/:idOrName', (req: Request, res: Response) => {
  const idOrName = decodeURIComponent(req.params.idOrName);
  const art = martialArtsList.find(a => a.id === idOrName || a.name === idOrName);
  if (art) {
    art.enrolled = false;
    return res.json({ success: true, art });
  }
  res.status(404).json({ error: 'Art not found.' });
});

// Update level / belt
app.patch('/api/arts/level', (req: Request, res: Response) => {
  const { artId, level, belt } = req.body;
  const art = martialArtsList.find(a => a.id === artId);
  if (art) {
    if (typeof level === 'number') art.level = Math.max(1, Math.min(5, level));
    if (belt) art.currentBelt = belt;
    return res.json({ success: true, art });
  }
  res.status(404).json({ error: 'Art not found.' });
});

// Dashboard Layout Customization
app.get('/api/layout', (_req: Request, res: Response) => {
  res.json({ widgets: userWidgets });
});

app.post('/api/layout/save', (req: Request, res: Response) => {
  const { widgets } = req.body;
  if (Array.isArray(widgets)) {
    userWidgets = widgets;
    return res.json({ success: true, widgets: userWidgets });
  }
  res.status(400).json({ error: 'Invalid widgets array.' });
});

app.post('/api/layout/reset', (_req: Request, res: Response) => {
  userWidgets = JSON.parse(JSON.stringify(defaultWidgets));
  res.json({ success: true, widgets: userWidgets });
});

// Community Posts
app.get('/api/posts', (_req: Request, res: Response) => {
  res.json(communityPosts);
});

app.post('/api/posts', (req: Request, res: Response) => {
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Please enter a message.' });
  }
  const newPost = {
    id: 'p_' + Date.now(),
    authorName: currentUser ? currentUser.name : 'Crew Member',
    authorInitial: currentUser ? currentUser.name.charAt(0).toUpperCase() : 'C',
    text: text.trim(),
    createdAt: new Date().toISOString(),
    likes: [],
  };
  communityPosts.unshift(newPost);
  res.json({ success: true, post: newPost });
});

app.post('/api/posts/:id/like', (req: Request, res: Response) => {
  const post = communityPosts.find(p => p.id === req.params.id);
  if (post && currentUser) {
    const idx = post.likes.indexOf(currentUser.id);
    if (idx === -1) post.likes.push(currentUser.id);
    else post.likes.splice(idx, 1);
    return res.json({ success: true, likes: post.likes });
  }
  res.json({ success: false });
});

// Partners
app.get('/api/partners', (_req: Request, res: Response) => {
  res.json(trainingPartners);
});

// ==========================================
// Jarvis AI / Nandu Admin Agent Endpoint
// ==========================================
app.post('/api/jarvis/chat', async (req: Request, res: Response) => {
  const { message, history } = req.body;

  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const systemPrompt = `You are JARVIS AI (Codename: NANDU ADMIN), the elite Athletic Performance, Biomechanics, and Tactical Self-Defense Intelligence agent for ONE PIECE Grand Line OS.

Your personality:
- Highly intelligent, crisp, authoritative, motivating, scientific, and disciplined (inspired by J.A.R.V.I.S. with tactical cybernetics).
- You address the user respectfully as "Athlete", "Operator", or by their name if provided.
- You specialize in:
  1. REAL-WORLD ATHLETIC TRAINING: Exercise biomechanics, progressive overload, hypertrophy (PPL splits), cardio conditioning, and sports nutrition.
  2. AUTHENTIC MARTIAL ARTS & COMBAT SCIENCE: Precise biomechanics of strikes (Boxing jab/cross/hook, Muay Thai shin kicks/elbows, BJJ strangles/armbars, Judo Kuzushi off-balancing, Krav Maga 360 defenses, Wrestling level changes).
  3. REAL-WORLD VIOLENCE DE-ESCALATION & SELF-DEFENSE ETHICS:
     - The user specifically appointed you (Nandu Admin) to help handle violence responsibly.
     - You firmly uphold the law of self-defense: violence is STRICTLY a last-resort measure when life or physical safety is in imminent peril.
     - You teach verbal de-escalation, posture boundary management, environmental situational awareness (Cooper color codes), exit path identification, and proportional response.
     - You never encourage senseless aggression, street brawling, revenge, or illegal acts.
  4. EVIDENCE-BASED ATHLETIC SKINCARE:
     - You know that sweat, friction from gis/pads, and gym mats cause acne mechanica, folliculitis, and barrier impairment.
     - You recommend dermatologist-backed active ingredients: Gentle Cleansers, Vitamin C (antioxidant), BHA / Salicylic Acid (pore clearing), Hypochlorous Acid (antimicrobial mat spray), Ceramides, and broad-spectrum SPF 50+ sunscreen.
  5. ZERO FICTION:
     - Do not talk about fictional cartoon powers, haki gear, or fantasy anime spells. Everything must be 100% grounded in real-world human physiology, anatomy, and physics.

Format your responses with concise, punchy sections, bullet points, tactical cues, and high clarity.`;

  // Try calling real Gemini 3.8 Flash model via @google/genai SDK
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemPrompt}\n\nUser Question/Request:\n${message}` }] }
        ],
      });

      const replyText = response.text || "Diagnostic complete. Ready for next query.";
      return res.json({
        reply: replyText,
        source: 'gemini-3.8-flash',
        timestamp: new Date().toISOString(),
      });
    } catch (err: any) {
      console.error('Gemini API Error in /api/jarvis/chat:', err?.message || err);
      // Fall through to tactical fallback
    }
  }

  // Intelligent Context-Aware Tactical Fallback (if no API key or rate limit)
  const lower = message.toLowerCase();
  let tacticalReply = "";

  if (lower.includes('de-escalat') || lower.includes('violence') || lower.includes('fight') || lower.includes('threat') || lower.includes('defense') || lower.includes('attack')) {
    tacticalReply = `**[NANDU ADMIN // TACTICAL DE-ESCALATION PROTOCOL]**

Operator, human conflict resolution is governed by the 3 Principles of Tactical Self-Defense:

1. **Awareness & Evasion (Pre-Conflict):**
   - 90% of violent encounters can be avoided through Cooper's Condition Yellow (relaxed alertness).
   - Maintain a 2-meter reactionary gap. Never let an agitated subject close distance inside arms-reach.
2. **Verbal De-escalation & Open Palm Boundary:**
   - Adopt a passive stance: hands up at chest level with open palms facing forward (protects throat and jaw while appearing non-confrontational to onlookers and security cameras).
   - Firm, calm tone: *"I do not want any trouble. Step back."*
3. **Proportional Physical Intervention (Last Resort):**
   - If trapped and physical assault begins, execute a rapid, decisive neutralizer: 360° forearm block + simultaneous straight punch, followed by an immediate tactical sprint to safety and contacting emergency authorities.`;
  } else if (lower.includes('skin') || lower.includes('sweat') || lower.includes('acne') || lower.includes('sunscreen')) {
    tacticalReply = `**[NANDU ADMIN // DERMATOLOGY PROTOCOL FOR ATHLETES]**

Athletic sweat and mat contact require specific biological barrier management:

- **Immediate Post-Workout:** Never allow sweat salts, sebum, and mat bacteria to dry in pores. Rinse within 15 minutes with a 2% Salicylic Acid (BHA) cleanser or spritz with Hypochlorous Acid (HOCl) antimicrobial spray.
- **Morning (AM):** Layer Vitamin C 15% antioxidant serum under a water-resistant broad-spectrum SPF 50+ to prevent free-radical damage from heavy outdoor cardiovascular training.
- **Evening (PM):** Double cleanse to remove waterproof sunscreen, then apply Ceramides + 0.3% Encapsulated Retinol to accelerate cellular micro-repair while in deep sleep.`;
  } else if (lower.includes('gym') || lower.includes('workout') || lower.includes('push') || lower.includes('bench') || lower.includes('hypertrophy')) {
    tacticalReply = `**[NANDU ADMIN // BIOMECHANICS & HYPERTROPHY DIRECTIVE]**

Optimal hypertrophy and functional punch force development requires:

1. **Flat Barbell Bench Press:** Retract scapulae, anchor feet, and lower bar to mid-sternum. Explode upward with intent to move maximal velocity against RPE 8.0-8.5.
2. **Compound Pull Mechanics:** Chest-supported T-Bar rows protect the lumbar spine while building mid-back rhomboid thickness needed to withstand grappling pulls.
3. **Progressive Overload Rule:** Increase load by 2.5% only when you can complete the top-end rep target with pristine form for two consecutive sessions.`;
  } else if (lower.includes('boxing') || lower.includes('hook') || lower.includes('jab') || lower.includes('muay thai') || lower.includes('bjj')) {
    tacticalReply = `**[NANDU ADMIN // COMBAT BIOMECHANICS]**

- **Kinetic Chain Execution:** Punch force is not generated by arm muscles; 82% of peak impact is generated by ground reaction forces from the rear foot turning into hip rotation.
- **The Hook Mechanics:** Pivot on the lead foot ball like extinguishing a cigarette. Lock your elbow at a strict 90° angle. Your wrist must remain neutral to avoid ligament sprains.
- **BJJ Ground Control:** On the mat, space is your enemy when on top, and your friend when on bottom. Maintain chest-to-chest pressure and isolate limbs before attempting joint locks.`;
  } else {
    tacticalReply = `**[JARVIS // NANDU ADMIN ONLINE]**

Readiness: 94% // Systems Calibrated.
How may I assist your training session today, Operator? I am primed to analyze your gym splits, calculate workout volume, optimize athletic skincare, demonstrate strike mechanics, or brief you on violence de-escalation protocols.`;
  }

  res.json({
    reply: tacticalReply,
    source: 'nandu-admin-tactical-engine',
    timestamp: new Date().toISOString(),
  });
});

// ==========================================
// Vite Middleware / Static Serve Setup
// ==========================================
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[Apex OS] Server listening on http://localhost:${PORT}`);
  });
}

startServer();
