/* ============================================================
   ONE PIECE FITNESS — Frontend Logic
   ============================================================ */
const API_BASE = 'http://localhost:3000/api';
let currentUser = null;
let currentPage = 'login';

/* ---------- OCEAN AMBIENCE ---------- */
(function initSky() {
  const sky = document.getElementById('sky');
  // Stars
  for (let i = 0; i < 90; i++) {
    const s = document.createElement('div');
    s.className = 'star';
    const size = Math.random() * 2 + 1;
    s.style.width = s.style.height = size + 'px';
    s.style.left = Math.random() * 100 + '%';
    s.style.top = Math.random() * 55 + '%';
    s.style.animationDelay = Math.random() * 3 + 's';
    sky.appendChild(s);
  }
  // Clouds
  for (let i = 0; i < 5; i++) {
    const c = document.createElement('div');
    c.className = 'cloud';
    const w = Math.random() * 240 + 120;
    c.style.width = w + 'px';
    c.style.height = (w * 0.35) + 'px';
    c.style.top = (10 + Math.random() * 30) + '%';
    c.style.animationDuration = (60 + Math.random() * 60) + 's';
    c.style.animationDelay = -Math.random() * 60 + 's';
    sky.appendChild(c);
  }
  // Bubbles
  for (let i = 0; i < 16; i++) {
    const b = document.createElement('div');
    b.className = 'bubble';
    const size = Math.random() * 26 + 8;
    b.style.width = b.style.height = size + 'px';
    b.style.left = Math.random() * 100 + '%';
    b.style.animationDuration = (14 + Math.random() * 18) + 's';
    b.style.animationDelay = -Math.random() * 20 + 's';
    sky.appendChild(b);
  }
  // Fish
  const fishes = ['🐟', '🐠', '🐡', '🦈', '🐬'];
  for (let i = 0; i < 5; i++) {
    const f = document.createElement('div');
    f.className = 'fish';
    f.textContent = fishes[i % fishes.length];
    f.style.top = (55 + Math.random() * 30) + '%';
    f.style.animationDuration = (40 + Math.random() * 40) + 's';
    f.style.animationDelay = -Math.random() * 40 + 's';
    f.style.fontSize = (1 + Math.random() * 1.2) + 'rem';
    sky.appendChild(f);
  }
})();

/* ---------- HELPERS ---------- */
function togglePassword(id, btn) {
  const el = document.getElementById(id);
  const isPw = el.type === 'password';
  el.type = isPw ? 'text' : 'password';
  btn.textContent = isPw ? '🙈' : '👁️';
}

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

async function api(path, opts = {}) {
  const res = await fetch(API_BASE + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

/* ---------- PAGE NAVIGATION ---------- */
function showPage(page) {
  const protectedPages = ['dashboard', 'arts', 'community'];
  if (protectedPages.includes(page) && !currentUser) {
    page = 'login';
    toast('Please sign in to access the crew area.');
  }
  if ((page === 'login' || page === 'register') && currentUser) page = 'dashboard';

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const t = document.getElementById('page-' + page);
  if (t) t.classList.add('active');

  document.querySelectorAll('.nav-link[data-page]').forEach(l =>
    l.classList.toggle('active', l.dataset.page === page)
  );

  document.getElementById('navLinks').style.display = currentUser ? 'flex' : 'none';
  document.getElementById('navUser').style.display = currentUser ? 'flex' : 'none';
  if (currentUser) {
    document.getElementById('navAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
    document.getElementById('welcomeTitle').textContent = `Welcome back, ${currentUser.name.split(' ')[0]}`;
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
  currentPage = page;

  if (page === 'dashboard') loadDashboard();
  if (page === 'arts') loadArts();
  if (page === 'community') loadCommunity();
}

/* ---------- AUTH ---------- */
async function handleLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  const err = document.getElementById('loginError');
  err.classList.remove('show');

  if (!email || !password) {
    err.textContent = 'Enter both email and password.';
    err.classList.add('show');
    return;
  }
  const btn = document.getElementById('loginBtn');
  btn.disabled = true; btn.textContent = 'Signing in…';
  try {
    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    currentUser = data.user;
    toast(`Welcome back, ${currentUser.name.split(' ')[0]}! ⚓`);
    showPage('dashboard');
  } catch (e) {
    err.textContent = e.message;
    err.classList.add('show');
  } finally {
    btn.disabled = false; btn.textContent = 'Sign In';
  }
}

async function handleRegister() {
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const confirm = document.getElementById('regConfirm').value;
  const err = document.getElementById('registerError');
  const ok = document.getElementById('registerSuccess');
  err.classList.remove('show'); ok.classList.remove('show');

  if (!name || !email || !password || !confirm) {
    err.textContent = 'All fields are required.';
    err.classList.add('show'); return;
  }
  if (password.length < 6) {
    err.textContent = 'Password must be 6+ characters.';
    err.classList.add('show'); return;
  }
  if (password !== confirm) {
    err.textContent = 'Passwords do not match.';
    err.classList.add('show'); return;
  }

  const btn = document.getElementById('registerBtn');
  btn.disabled = true; btn.textContent = 'Creating…';
  try {
    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    currentUser = data.user;
    ok.textContent = 'Account created! Welcome aboard ⚓';
    ok.classList.add('show');
    setTimeout(() => showPage('dashboard'), 800);
  } catch (e) {
    err.textContent = e.message;
    err.classList.add('show');
  } finally {
    btn.disabled = false; btn.textContent = 'Create Account';
  }
}

function loginWithGoogle() { window.location.href = `${API_BASE}/auth/google`; }
function loginWithGitHub() { window.location.href = `${API_BASE}/auth/github`; }

async function logout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch {}
  currentUser = null;
  toast('Signed out. See you on the seas! ⛵');
  showPage('login');
}

async function checkAuth() {
  try {
    const data = await api('/auth/me');
    if (data.authenticated) currentUser = data.user;
  } catch {}
}

/* ---------- DASHBOARD ---------- */
async function loadDashboard() {
  try {
    const s = await api('/stats');
    document.getElementById('statReadiness').innerHTML = `${Math.round(s.readiness)}<span class="stat-unit">%</span>`;
    document.getElementById('statHydration').innerHTML = `${s.hydration.toFixed(1)}<span class="stat-unit">L</span>`;
    document.getElementById('statSleep').innerHTML = `${s.sleep.toFixed(1)}<span class="stat-unit">h</span>`;
    document.getElementById('statRecovery').innerHTML = `${Math.round(s.recovery)}<span class="stat-unit">%</span>`;

    document.getElementById('todayTraining').innerHTML =
      (s.training || []).slice(-4).map(t =>
        `<div class="list-item"><span>${t.name}</span><span class="list-item-meta">${t.duration} min</span></div>`
      ).join('') || '<div class="list-item">No training logged yet.</div>';

    const w = s.weekly || [];
    document.getElementById('weeklyChart').innerHTML = w.map((h, i) =>
      `<div class="bar" style="--height:${h};" onclick="toast('Day ${i+1}: ${Math.round(h*100)}%')"></div>`
    ).join('');

    document.getElementById('skincareList').innerHTML =
      (s.skincare || []).map(item =>
        `<div class="list-item">
          <span>${item.name}</span>
          <span class="list-item-meta" style="cursor:pointer;"
            onclick="toggleSkincare('${item.name.replace(/'/g,"\\'")}','${item.status === 'done' ? 'pending' : 'done'}')">
            ${item.status === 'done' ? '✓ Done' : 'Mark done'}
          </span>
        </div>`
      ).join('');

    // Martial arts progress
    const arts = await api('/arts');
    const enrolled = arts.filter(a => a.enrolled);
    document.getElementById('martialProgress').innerHTML = enrolled.length
      ? enrolled.slice(0, 5).map(a => `
        <div style="margin-bottom:0.8rem;">
          <div style="display:flex;justify-content:space-between;font-size:0.82rem;margin-bottom:0.3rem;">
            <span>${a.icon} ${a.name}</span>
            <span style="color:var(--teal-neon);">Lv ${a.level}/5</span>
          </div>
          <div class="progress-track"><div class="progress-fill" style="width:${a.level*20}%"></div></div>
        </div>`).join('')
      : '<div class="list-item">Enroll in a martial art to track progress.</div>';

    refreshAI();
    loadDashboardPosts();
    loadPartners();
  } catch (e) { console.error(e); }
}

async function toggleSkincare(name, status) {
  try {
    await api('/stats/skincare', {
      method: 'PATCH',
      body: JSON.stringify({ name, status }),
    });
    toast(`Skincare "${name}" marked ${status}.`);
    loadDashboard();
  } catch { toast('Update failed.'); }
}

function refreshAI() {
  const options = [
    'Your readiness is excellent. Push intensity today by 10%. Prioritize protein + hydration.',
    'Sleep quality trending up. Add 20-minute sauna post-workout for recovery.',
    'Hydration below target. Aim for 3.5L today with electrolytes during training.',
    'Slight soreness detected. Focus on mobility + active recovery today.',
    'Primed for a PR attempt — warm up thoroughly and go for it!',
  ];
  document.getElementById('aiSuggestion').textContent =
    options[Math.floor(Math.random() * options.length)];
}

async function quickAction(type) {
  try {
    if (type === 'water') {
      const s = await api('/stats');
      const next = Math.min(s.hydration + 0.25, 6);
      await api('/stats/metric', {
        method: 'PATCH',
        body: JSON.stringify({ metric: 'hydration', value: next }),
      });
      toast(`💧 +250ml — ${next.toFixed(2)}L total`);
    } else if (type === 'workout') {
      await api('/stats/workout', {
        method: 'POST',
        body: JSON.stringify({ name: 'Freestyle Session', duration: 45 }),
      });
      toast('🏋️ Workout logged!');
    } else if (type === 'sleep') {
      await api('/stats/metric', {
        method: 'PATCH',
        body: JSON.stringify({ metric: 'sleep', value: 8 }),
      });
      toast('😴 Sleep logged: 8h');
    } else if (type === 'skincare') {
      toast('🧴 Tap a routine item to toggle it.');
    }
    loadDashboard();
  } catch { toast('Action failed.'); }
}

async function loadDashboardPosts() {
  try {
    const posts = await api('/posts');
    document.getElementById('communityPosts').innerHTML =
      posts.slice(0, 3).map(postHTML).join('') ||
      '<div class="post">No posts yet — be the first!</div>';
  } catch {}
}

async function loadPartners() {
  try {
    const list = await api('/partners');
    document.getElementById('partnersList').innerHTML =
      list.map(p => `<div class="partner-badge" onclick="toast('${p.name} is ${p.status}')">
        <span class="partner-status ${p.status}"></span> ${p.name}</div>`).join('');
  } catch {}
}

function postHTML(p) {
  const liked = currentUser && p.likes && p.likes.includes(currentUser.id);
  const time = new Date(p.createdAt || Date.now()).toLocaleString();
  return `
    <div class="post">
      <div class="post-header">
        <div class="post-avatar">${p.authorInitial}</div>
        <div>
          <div class="post-name">${p.authorName}</div>
          <div class="post-time">${time}</div>
        </div>
      </div>
      <div class="post-text">${escapeHTML(p.text)}</div>
      <div class="post-actions">
        <button class="post-action ${liked ? 'liked' : ''}" onclick="likePost('${p._id}')">
          ${liked ? '❤️' : '🤍'} ${(p.likes || []).length}
        </button>
      </div>
    </div>`;
}

function escapeHTML(str) {
  return String(str).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

async function likePost(id) {
  try {
    await api(`/posts/${id}/like`, { method: 'POST' });
    if (currentPage === 'community') loadCommunity(); else loadDashboardPosts();
  } catch {}
}

/* ---------- ARTS ---------- */
async function loadArts() {
  try {
    const list = await api('/arts');
    document.getElementById('artsGrid').innerHTML = list.map(a => `
      <div class="art-card">
        <span class="art-icon">${a.icon}</span>
        <div class="art-name">${a.name}</div>
        <div class="art-origin">${a.origin}</div>
        <div class="art-desc">${a.desc}</div>
        <div class="art-meta">
          <div class="art-level">${[1,2,3,4,5].map(n =>
            `<span class="dot ${n <= a.level ? 'filled' : ''}"></span>`).join('')}</div>
          <span>⏱ ${a.duration}</span>
        </div>
        <button class="art-enroll ${a.enrolled ? 'enrolled' : ''}"
          onclick="toggleEnroll('${a.name.replace(/'/g,"\\'")}', ${a.enrolled})">
          ${a.enrolled ? '✓ Enrolled' : 'Enroll Now'}
        </button>
      </div>`).join('');
  } catch {}
}

async function toggleEnroll(name, isEnrolled) {
  try {
    if (isEnrolled) {
      await api(`/arts/enroll/${encodeURIComponent(name)}`, { method: 'DELETE' });
      toast(`Left ${name} class.`);
    } else {
      await api('/arts/enroll', {
        method: 'POST',
        body: JSON.stringify({ artName: name }),
      });
      toast(`Enrolled in ${name}! 🥋`);
    }
    loadArts();
  } catch { toast('Action failed.'); }
}

/* ---------- COMMUNITY ---------- */
async function loadCommunity() {
  try {
    const posts = await api('/posts');
    document.getElementById('allPosts').innerHTML =
      posts.map(postHTML).join('') ||
      '<div class="post">No posts yet — be the first to share!</div>';
  } catch {}
}

async function submitPost() {
  const text = document.getElementById('newPostText').value.trim();
  if (!text) { toast('Please write something first.'); return; }
  try {
    await api('/posts', { method: 'POST', body: JSON.stringify({ text }) });
    document.getElementById('newPostText').value = '';
    toast('Posted to the crew! 🌊');
    loadCommunity();
  } catch (e) { toast(e.message); }
}

/* ---------- INIT ---------- */
(async function init() {
  await checkAuth();
  const hash = window.location.hash;
  if (hash === '#dashboard' && currentUser) {
    history.replaceState(null, '', window.location.pathname);
    showPage('dashboard');
  } else if (hash === '#login-error') {
    history.replaceState(null, '', window.location.pathname);
    toast('Sign-in failed. Please try again.');
    showPage('login');
  } else if (currentUser) {
    showPage('dashboard');
  } else {
    showPage('login');
  }

  // Enter key submits
  document.getElementById('loginPassword')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleLogin();
  });
  document.getElementById('regConfirm')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleRegister();
  });
})();