# ONE PIECE — Combat Sparring Visuals & Full-Screen Authentication Gateway

A dedicated full-screen royal authentication gateway with 1-click Google and Jarvis AI access, combined with dynamic martial arts combat sparring visuals from the user's sketch (`image_0bda721e.png`) embedded into the Dojo hero header and technique enrollment modal.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed based on your preferences:
> - **Sparring Visuals Location**: Positioned prominently in the **Dojo Martial Arts hero section** and dynamically rendered when opening/enrolling in strike techniques.
> - **Login Gateway**: A **dedicated full-screen royal gateway** displayed before entering the dashboard, featuring direct 1-click Google Sign-in and instant Jarvis AI access.
> - **Brand & Palette**: Strictly maintaining **ONE PIECE** name and the royal emerald green (`#10b981`) & deep obsidian black (`#020b06`) styling.

---

## 1. Overview & Core Concept

1. **Dedicated Full-Screen Login Gateway**:
   - Greets users before accessing the application with an immersive obsidian/emerald royal visual and a spinning concentric Jarvis reactor.
   - Offers two direct 1-click entry methods:
     - **Direct Google Account Access**: Pre-configured with your connected Google identity (`madhu0007.m@gmail.com`) for immediate entry.
     - **Direct Jarvis AI Access**: Instant tactical override allowing immediate access as Guest/Operative with real-time Jarvis voice briefing.
     - Standard email/password input for manual credential testing.
   - Session persistence with quick logout button in the top navigation to return to the gateway.

2. **Fighting Characters Sparring Visuals**:
   - High-contrast visual asset integration of `/public/assets/aistudio/image_0bda721e.png` into the Martial Arts Dojo hero section.
   - **Interactive Sparring Analysis**: Highlighting the 4 fighting sequences from the sketch:
     1. *Jab & Slip*: Straight punch evasion and counter-angle setup.
     2. *Overhand Anticipation*: Ducking the heavy hook with active high guard.
     3. *Level-Change Body Shot*: Slipping the cross to deliver an infighting liver punch.
     4. *Clinch & Inside Angle*: Neutralizing opponent momentum with close-quarter control.
   - **Enrollment / Technique Open Modal**: Triggered upon clicking any strike or enrolling in any of the 10 martial art disciplines, revealing the visual combat exchange with strike velocity, force vectors, and kinetic feedback.

---

## 2. User Experience & Visual Design

```
┌────────────────────────────────────────────────────────────────────────┐
│                   DEDICATED FULL-SCREEN LOGIN GATEWAY                   │
│                                                                        │
│                       [ ONE PIECE ROYAL CREST ]                        │
│                 Concentric Gyroscopic Jarvis AI Reactor                 │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │   [G] Continue with Google (madhu0007.m@gmail.com)             │   │
│   └────────────────────────────────────────────────────────────────┘   │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │   [Jarvis Core] Direct Access with Jarvis AI Protocol          │   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                 - or -                                 │
│                   [ Manual Emerald Credentials Form ]                   │
└────────────────────────────────────────────────────────────────────────┘
                                    │ (Direct Entry)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                 MAIN APPLICATION (DASHBOARD & PAGES)                    │
│                                                                        │
│   [Navigation]  ONE PIECE  |  Dashboard  |  Dojo  |  Gym  |  Skin      │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │ DOJO HERO SECTION                                              │   │
│   │ [ Sparring Visual Canvas (image_0bda721e.png) ]                │   │
│   │ Dynamic Combat Breakdowns: Slip / Overhand / Body Shot / Clinch │   │
│   └────────────────────────────────────────────────────────────────┘   │
│                                                                        │
│   ┌────────────────────────────────────────────────────────────────┐   │
│   │ 10 Martial Arts Disciplines & Interactive Strike Sparring View  │   │
│   └────────────────────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────────────────┘
```

### Visual Identity & Theme
- **Dominant Colors**: Obsidian Black (`#020b06`), Royal Emerald (`#10b981`), Mint Glow (`#34d399`), and Imperial Gold (`#d4af37`).
- **Typography**: Display titles in *Plus Jakarta Sans* bold, UI figures in *JetBrains Mono*, body text in *DM Sans*.
- **Motion**: Gyroscopic spinning concentric rings on the login gateway, smooth fade reveals into the dashboard, and animated strike target crosshairs.

---

## 3. Key Product Decisions & Implementation Steps

1. **State-Driven Gateway Entry**:
   - Store session state in `localStorage` (`onepiece_auth_token` and `onepiece_user`).
   - If not authenticated, render the dedicated full-screen `LoginGateway` component instead of the dashboard.
   - Clicking either "Continue with Google" or "Direct Access with Jarvis" updates authentication state instantly, launches the Jarvis greeting, and seamlessly loads the main dashboard.
2. **Combat Sparring Component (`DojoSparringHero.tsx`)**:
   - Embeds `/public/assets/aistudio/image_0bda721e.png` with canvas/card overlays that illustrate the exact 4 martial arts sparring scenarios depicted in the image.
   - Provides an interactive "Sparring Breakdown" drawer that activates when an athlete enrols in a martial art or selects a strike technique.
3. **Enrollment & Strike Open Flow**:
   - When the user clicks "Enrol in Style" or clicks any individual strike (e.g., Muay Thai Low Kick, Krav Maga 360 Defense, BJJ Triangle Choke), an immersive combat sparring preview modal pops up featuring the fighting character sequences and biomechanical execution tips.

---

## 4. Verification Plan
- Verify compilation and zero lint errors (`compile_applet`, `lint_applet`).
- Verify smooth transition between the dedicated full-screen login gateway and the dashboard via both Google sign-in and Jarvis quick access.
- Verify clear display and responsiveness of the fighting characters visual asset in the Dojo hero section and the strike enrollment modal.
