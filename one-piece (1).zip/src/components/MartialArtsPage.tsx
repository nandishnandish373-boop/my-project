import React, { useState } from 'react';
import { 
  Swords, 
  Search, 
  Check, 
  Plus, 
  Play, 
  Target, 
  Award, 
  Zap,
  X,
  ShieldAlert,
  Flame,
  CheckCircle2,
  Crosshair
} from 'lucide-react';
import { MartialArt, MartialAttack } from '../types';
import { DojoSparringHero } from './DojoSparringHero';

interface MartialArtsPageProps {
  arts: MartialArt[];
  onToggleEnroll: (artId: string, currentEnrolled: boolean) => void;
  onUpdateLevel: (artId: string, level: number) => void;
  selectedArtIdInitial?: string | null;
}

export const MartialArtsPage: React.FC<MartialArtsPageProps> = ({
  arts,
  onToggleEnroll,
  onUpdateLevel,
  selectedArtIdInitial,
}) => {
  const [selectedArtId, setSelectedArtId] = useState<string>(
    selectedArtIdInitial || arts[0]?.id || 'muay-thai'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Striking' | 'Grappling' | 'Hybrid' | 'Self-Defense'>('All');
  
  // Selected Attack for the interactive strike simulator
  const [activeAttack, setActiveAttack] = useState<MartialAttack | null>(null);
  const [impactAnimation, setImpactAnimation] = useState(false);

  // Active Sparring Scenario Modal (from image_0bda721e.png)
  const [activeSparringScenario, setActiveSparringScenario] = useState<any | null>(null);
  
  // Enrollment Celebration Modal
  const [enrolledCelebrationArt, setEnrolledCelebrationArt] = useState<MartialArt | null>(null);

  const selectedArt = arts.find((a) => a.id === selectedArtId) || arts[0];

  const filteredArts = arts.filter((art) => {
    const matchesSearch = art.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.origin.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || art.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const triggerStrikeSimulation = () => {
    setImpactAnimation(true);
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(150, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(32, audioCtx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.35, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.2);
    } catch {}

    setTimeout(() => {
      setImpactAnimation(false);
    }, 700);
  };

  const handleEnrollWithCelebration = (art: MartialArt) => {
    const willEnroll = !art.enrolled;
    onToggleEnroll(art.id, art.enrolled);
    if (willEnroll) {
      setEnrolledCelebrationArt(art);
      triggerStrikeSimulation();
    }
  };

  return (
    <div className="space-y-7 animate-in fade-in duration-300">
      {/* 1. Martial Arts Sparring Hero Banner (Featuring characters fighting image_0bda721e.png) */}
      <DojoSparringHero
        onOpenScenarioModal={(scenario) => setActiveSparringScenario(scenario)}
        onQuickEnroll={() => {
          if (selectedArt) handleEnrollWithCelebration(selectedArt);
        }}
      />

      {/* 2. Dojo Header & Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-2">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              10 DISCIPLINES FROM REFERENCE
            </span>
            <span className="text-xs font-mono text-[#d4af37]">
              • Grand Line Royal Dojo
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            10 Authentic Disciplines & Strike Mechanics
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Muay Thai, Taekwondo, Tai Chi, Karate, BJJ, Kung Fu, Krav Maga, Judo, Capoeira, and MMA. Zero fictional powers—grounded in physics, balance, and ring-tested lineages.
          </p>
        </div>

        {/* Search & Category Filter */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search style or origin..."
              className="pl-9 pr-4 py-2 glass-input text-xs rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 w-48 sm:w-56"
            />
          </div>

          <div className="flex bg-black/70 p-1 rounded-xl border border-emerald-500/25 text-xs overflow-x-auto">
            {(['All', 'Striking', 'Grappling', 'Hybrid', 'Self-Defense'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1 rounded-lg font-bold transition-all whitespace-nowrap ${
                  categoryFilter === cat
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/25'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3. Main Grid: Style Sidebar (10 styles) & Selected Style Deep-Dive */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Style Selector List (4 Columns) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-mono text-emerald-300 uppercase tracking-wider px-1 font-bold">
            REFERENCE DISCIPLINES ({filteredArts.length}):
          </div>

          <div className="space-y-2.5 max-h-[750px] overflow-y-auto pr-1">
            {filteredArts.map((art) => {
              const isSelected = art.id === selectedArtId;
              return (
                <div
                  key={art.id}
                  onClick={() => setSelectedArtId(art.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-950/80 to-[#03150b] border-emerald-400 text-white shadow-xl shadow-emerald-500/15'
                      : 'bg-[#03140b]/80 border-slate-800 hover:border-emerald-500/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{art.icon}</span>
                      <div>
                        <h3 className="font-bold text-sm text-white">{art.name}</h3>
                        <p className="text-[11px] text-[#d4af37] font-mono">{art.origin}</p>
                      </div>
                    </div>
                    {art.enrolled ? (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/25 text-emerald-300 border border-emerald-400/50">
                        ENROLLED
                      </span>
                    ) : (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-black/60 text-slate-400 border border-slate-800">
                        OPEN
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                    {art.desc}
                  </p>

                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>Rank: <strong className="text-emerald-300">{art.currentBelt}</strong></span>
                    <span>{art.attacks.length} Attacks</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Discipline Deep-Dive (8 Columns) */}
        {selectedArt && (
          <div className="lg:col-span-8 space-y-5">
            {/* Style Hero Card */}
            <div className="glass-panel-royal rounded-3xl p-6 sm:p-7 border border-emerald-500/35 relative overflow-hidden shadow-2xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                <div className="flex items-center gap-3.5">
                  <span className="text-4xl p-3 bg-emerald-500/15 rounded-2xl border border-emerald-400/30">
                    {selectedArt.icon}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
                        {selectedArt.name}
                      </h2>
                      <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                        {selectedArt.category}
                      </span>
                    </div>
                    <p className="text-xs font-mono text-[#d4af37] mt-0.5">
                      Origin: {selectedArt.origin} • Lineage: {selectedArt.founder}
                    </p>
                  </div>
                </div>

                {/* Enrollment Action with Visual Celebration */}
                <button
                  onClick={() => handleEnrollWithCelebration(selectedArt)}
                  className={`px-5 py-2.5 rounded-2xl font-bold text-xs transition-all flex items-center gap-2 shadow-lg ${
                    selectedArt.enrolled
                      ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50 hover:bg-emerald-500/35'
                      : 'bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] text-slate-950 hover:brightness-110 shadow-emerald-500/30'
                  }`}
                >
                  {selectedArt.enrolled ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Enrolled in Dojo</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 stroke-[3]" />
                      <span>Enroll in Discipline</span>
                    </>
                  )}
                </button>
              </div>

              {/* Combat Philosophy Quote */}
              <div className="p-3.5 rounded-2xl bg-black/60 border border-emerald-500/20 text-xs text-slate-300 italic mb-4 leading-relaxed">
                "{selectedArt.philosophy}"
              </div>

              {/* Rank and Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800">
                <div className="bg-[#03150c]/90 p-3 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] font-mono text-slate-400 block">CURRENT RANK</span>
                  <span className="text-xs font-bold text-emerald-300">{selectedArt.currentBelt}</span>
                </div>
                <div className="bg-[#03150c]/90 p-3 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] font-mono text-slate-400 block">MASTERY LEVEL</span>
                  <span className="text-xs font-bold text-white">Level {selectedArt.level} / 5</span>
                </div>
                <div className="bg-[#03150c]/90 p-3 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] font-mono text-slate-400 block">LOGGED MAT TIME</span>
                  <span className="text-xs font-bold text-[#d4af37]">{selectedArt.trainingHours} Hours</span>
                </div>
                <div className="bg-[#03150c]/90 p-3 rounded-xl border border-slate-800 text-center">
                  <span className="text-[10px] font-mono text-slate-400 block">SESSION LENGTH</span>
                  <span className="text-xs font-bold text-white">{selectedArt.duration}</span>
                </div>
              </div>

              {/* Stances & Required Gear */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-800/80">
                <div>
                  <span className="text-xs font-mono text-emerald-300 uppercase tracking-wider block mb-2 font-bold">
                    OFFICIAL STANCES:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedArt.stances.map((st, i) => (
                      <span
                        key={i}
                        className="text-xs px-2.5 py-1 rounded-lg bg-black/60 border border-emerald-500/25 text-slate-300 font-mono"
                      >
                        {st}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-xs font-mono text-emerald-300 uppercase tracking-wider block mb-2 font-bold">
                    REQUIRED EQUIPMENT:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedArt.gearRequired.map((gear, i) => (
                      <span
                        key={i}
                        className="text-xs px-2.5 py-1 rounded-lg bg-black/60 border border-emerald-500/25 text-slate-300 font-mono"
                      >
                        {gear}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Attack & Technique Showcase */}
            <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <Target className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-extrabold text-base text-white tracking-wide">
                    Strike & Defense Encyclopedia ({selectedArt.attacks.length} Moves)
                  </h3>
                </div>
                <span className="text-xs font-mono text-[#d4af37]">
                  PHYSICAL ANATOMY TARGETS
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {selectedArt.attacks.map((atk) => (
                  <div
                    key={atk.id}
                    onClick={() => setActiveAttack(atk)}
                    className="p-4 rounded-2xl bg-[#03150c]/90 border border-slate-800 hover:border-emerald-400 cursor-pointer transition-all flex flex-col justify-between group shadow-lg"
                  >
                    <div>
                      <div className="flex items-start justify-between mb-1.5">
                        <h4 className="font-bold text-sm text-white group-hover:text-emerald-300 transition-colors">
                          {atk.name}
                        </h4>
                        <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {atk.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                        {atk.mechanics}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                      <span className="text-[#d4af37]">Target: {atk.target.split(',')[0]}</span>
                      <button className="text-emerald-300 group-hover:text-white flex items-center gap-1 font-sans text-xs font-bold">
                        <Play className="w-3 h-3 fill-emerald-300" /> View Sparring
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Signature Combos Section */}
            <div className="glass-panel rounded-3xl p-6 border border-emerald-500/25">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-[#d4af37]" />
                <h3 className="font-bold text-sm text-white tracking-wide uppercase font-mono">
                  SIGNATURE COMBINATIONS & DRILLS
                </h3>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedArt.signatureCombos.map((combo, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-slate-800 flex items-center justify-between shadow-md"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 font-mono text-xs font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="text-xs font-semibold text-slate-200">{combo}</span>
                    </div>
                    <button
                      onClick={() => triggerStrikeSimulation()}
                      className="text-xs px-2.5 py-1 rounded-lg bg-black/60 hover:bg-emerald-500 hover:text-slate-950 text-emerald-300 font-mono transition-colors border border-emerald-500/30"
                      title="Drill this sequence"
                    >
                      Practice
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. Full Sparring Scenario Modal (from image_0bda721e.png) */}
      {activeSparringScenario && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-3xl bg-gradient-to-b from-[#062416] via-[#04150c] to-[#020b06] rounded-3xl border-2 border-emerald-500/50 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-emerald-500/30 bg-black/70">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 font-bold font-mono">
                  ⚔️
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-wide">
                    {activeSparringScenario.title}
                  </h3>
                  <span className="text-xs text-[#d4af37] font-mono">
                    {activeSparringScenario.discipline} • Biomechanical Combat Exchange
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveSparringScenario(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* Fighting Characters Visual Box */}
              <div className="relative rounded-2xl bg-black border-2 border-emerald-500/40 overflow-hidden flex flex-col items-center justify-center p-4">
                <div className="max-w-md w-full aspect-[4/3] rounded-xl overflow-hidden border border-emerald-500/30 bg-black/90 flex items-center justify-center relative">
                  <img
                    src="/assets/aistudio/image_0bda721e.png"
                    alt="Characters Sparring Sequence"
                    className="w-full h-full object-contain filter contrast-125"
                  />
                  <div className="absolute top-3 left-3 px-3 py-1 rounded-lg bg-black/80 border border-emerald-500/40 text-[11px] font-mono text-emerald-300 font-bold">
                    DYNAMIC FIGHT SEQUENCE
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-3">
                  <button
                    onClick={triggerStrikeSimulation}
                    className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] text-slate-950 font-black text-xs font-mono flex items-center gap-2 shadow-lg shadow-emerald-500/30"
                  >
                    <Play className="w-4 h-4 fill-slate-950" />
                    SIMULATE KINETIC CLASH
                  </button>
                  <span className="text-xs font-mono text-slate-400">
                    Audio impact resonance enabled
                  </span>
                </div>
              </div>

              {/* Attack and Defense Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-black/70 border border-emerald-500/30">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold block mb-1">
                    AGGRESSOR MECHANICS:
                  </span>
                  <h4 className="text-sm font-bold text-white mb-1">
                    {activeSparringScenario.attackName}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {activeSparringScenario.description}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-black/70 border border-[#d4af37]/40">
                  <span className="text-[10px] font-mono text-[#d4af37] uppercase font-bold block mb-1">
                    TACTICAL DEFENSE & COUNTER:
                  </span>
                  <h4 className="text-sm font-bold text-white mb-1">
                    {activeSparringScenario.defenseName}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    Target Anatomy: <strong className="text-emerald-300">{activeSparringScenario.targetAnatomy}</strong>
                  </p>
                  <p className="text-xs text-slate-400 mt-2 font-mono">
                    {activeSparringScenario.biomechanics}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Enrollment Celebration & Sparring Preview Modal */}
      {enrolledCelebrationArt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-gradient-to-b from-[#072a18] via-[#04150c] to-[#020b06] rounded-3xl border-2 border-emerald-400 shadow-2xl p-6 sm:p-8 text-center relative overflow-hidden">
            {/* Background sparkle */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

            <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center text-slate-950 text-3xl shadow-xl shadow-emerald-500/50 mb-4 animate-bounce">
              {enrolledCelebrationArt.icon}
            </div>

            <span className="text-xs font-mono uppercase tracking-widest text-emerald-300 font-bold block mb-1">
              DISCIPLINE ENROLLED // GRAND LINE DOJO
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {enrolledCelebrationArt.name}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto mt-2 leading-relaxed">
              You are now enrolled in official {enrolledCelebrationArt.name} training. Review the fighting characters sparring mechanics below to prime your muscle memory:
            </p>

            {/* Sparring Characters Graphic in Enrollment Modal */}
            <div className="my-5 rounded-2xl bg-black/90 border border-emerald-500/40 p-3 max-w-sm mx-auto overflow-hidden">
              <img
                src="/assets/aistudio/image_0bda721e.png"
                alt="Sparring Characters"
                className="w-full h-44 object-contain filter contrast-125"
              />
              <span className="text-[10px] font-mono text-[#d4af37] block mt-1">
                COMBAT SPARRING PROTOCOL REGISTERED
              </span>
            </div>

            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setEnrolledCelebrationArt(null)}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] text-slate-950 font-black text-xs font-mono shadow-lg shadow-emerald-500/30 transition-all hover:brightness-110"
              >
                ENTER DOJO & BEGIN DRILLS ⚔️
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Interactive Strike Simulator & Mechanical Breakdown Modal (on strike click) */}
      {activeAttack && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-gradient-to-b from-[#072416] via-[#04150c] to-[#020b06] rounded-3xl border border-emerald-500/50 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-emerald-500/25 bg-black/60">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-wide">
                    {activeAttack.name}
                  </h3>
                  <span className="text-xs text-[#d4af37] font-mono">
                    Target Anatomy: {activeAttack.target}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveAttack(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {/* Strike Impact Simulator with Fighting Characters Preview */}
              <div className="relative rounded-2xl bg-black border border-emerald-500/35 overflow-hidden flex flex-col items-center justify-center p-4 text-center">
                <div className="w-full max-w-xs h-32 mb-2 rounded-xl overflow-hidden bg-black/90 border border-emerald-500/20 flex items-center justify-center">
                  <img
                    src="/assets/aistudio/image_0bda721e.png"
                    alt="Strike Mechanics Sparring"
                    className="w-full h-full object-contain filter contrast-125"
                  />
                </div>

                <div className={`transition-all duration-300 ${impactAnimation ? 'scale-110 filter drop-shadow-[0_0_30px_#34d399]' : 'scale-100'}`}>
                  <div className="text-sm font-black tracking-wider uppercase font-mono text-emerald-300">
                    {impactAnimation ? '💥 KINETIC IMPACT REGISTERED 💥' : `${activeAttack.name} PRIMED`}
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-1">
                    Damage Type: {activeAttack.damageType}
                  </div>
                </div>

                {/* Trigger Strike Button */}
                <button
                  onClick={triggerStrikeSimulation}
                  className="mt-3 px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] hover:brightness-110 text-slate-950 font-black text-xs font-mono transition-all shadow-md shadow-emerald-500/30 flex items-center gap-2"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  SIMULATE STRIKE IMPACT
                </button>
              </div>

              {/* Power / Speed Metrics */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#03150c]/90 p-3.5 rounded-2xl border border-slate-800">
                  <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                    <span>CONCUSSIVE FORCE</span>
                    <span className="text-emerald-300 font-bold">{activeAttack.damageScore}/100</span>
                  </div>
                  <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-emerald-500/20">
                    <div
                      className="bg-gradient-to-r from-emerald-500 to-[#d4af37] h-full rounded-full transition-all duration-500"
                      style={{ width: `${activeAttack.damageScore}%` }}
                    />
                  </div>
                </div>

                <div className="bg-[#03150c]/90 p-3.5 rounded-2xl border border-slate-800">
                  <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                    <span>VELOCITY & SNAP</span>
                    <span className="text-teal-300 font-bold">{activeAttack.speedScore}/100</span>
                  </div>
                  <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-teal-500/20">
                    <div
                      className="bg-gradient-to-r from-teal-400 to-emerald-300 h-full rounded-full transition-all duration-500"
                      style={{ width: `${activeAttack.speedScore}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Step-by-Step Biomechanical Breakdown */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-300 font-bold">
                  EXECUTION SEQUENCE (STEP-BY-STEP):
                </h4>
                <div className="space-y-2">
                  {activeAttack.steps.map((st, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-xl bg-[#03150c]/90 border border-slate-800 flex items-start gap-3 text-xs leading-relaxed text-slate-200"
                    >
                      <span className="w-5 h-5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                        {i + 1}
                      </span>
                      <span>{st}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Coaching Cues */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs">
                <span className="font-mono text-emerald-300 font-bold text-[11px] block mb-1">
                  NANDU ADMIN COACHING CUES:
                </span>
                <div className="flex flex-wrap gap-2 mt-1">
                  {activeAttack.cues.map((cue, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-200 border border-emerald-500/20 font-mono text-[11px]"
                    >
                      • {cue}
                    </span>
                  ))}
                </div>
              </div>

              {/* Critical Mistake to Avoid */}
              <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-xs text-rose-200 leading-relaxed">
                <strong className="text-rose-400 font-mono block mb-0.5">CRITICAL FLAW TO AVOID:</strong>
                {activeAttack.keyMistake}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
