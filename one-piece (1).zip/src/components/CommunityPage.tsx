import React, { useState } from 'react';
import { Users, Heart, Send, Sparkles } from 'lucide-react';
import { Post, Partner } from '../types';

interface CommunityPageProps {
  posts: Post[];
  partners: Partner[];
  onLikePost: (postId: string) => void;
  onSubmitPost: (text: string) => void;
  currentUser: any;
}

export const CommunityPage: React.FC<CommunityPageProps> = ({
  posts,
  partners,
  onLikePost,
  onSubmitPost,
  currentUser,
}) => {
  const [newText, setNewText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    onSubmitPost(newText);
    setNewText('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            ATHLETIC BROTHERHOOD
          </span>
          <span className="text-xs font-mono text-[#d4af37]">
            • ONE PIECE Nakama Sparring Network
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Crew Community & Sparring Network
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl mt-1">
          Connect with dedicated martial artists and strength athletes. Share training milestones, analyze technique breakthroughs, and find local sparring partners.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Posts Feed (8 Columns) */}
        <div className="lg:col-span-8 space-y-4">
          {/* Post Creator */}
          <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/35 shadow-2xl">
            <h2 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-300" />
              Share a Training PR or Technique Insight
            </h2>
            <form onSubmit={handleSubmit}>
              <textarea
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                rows={3}
                placeholder="What did you conquer today on the mat or under the barbell?"
                className="w-full glass-input text-sm p-4 rounded-2xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 resize-none"
              />
              <div className="flex justify-between items-center mt-3">
                <span className="text-xs font-mono text-slate-400">
                  Posting as: <strong className="text-emerald-300">{currentUser?.name || 'Athlete'}</strong>
                </span>
                <button
                  type="submit"
                  disabled={!newText.trim()}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] text-slate-950 font-bold text-xs transition-all disabled:opacity-40 shadow-lg shadow-emerald-500/25 hover:brightness-110"
                >
                  Post to Crew Feed
                </button>
              </div>
            </form>
          </div>

          {/* Posts Stream */}
          <div className="space-y-3.5">
            {posts.map((post) => {
              const isLiked = post.likes.length > 0;
              return (
                <div
                  key={post.id}
                  className="glass-panel-royal rounded-3xl p-5 border border-slate-800 hover:border-emerald-500/40 transition-all text-sm shadow-xl"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-[#d4af37] flex items-center justify-center font-bold text-slate-950 text-sm ring-2 ring-emerald-400/40">
                        {post.authorInitial}
                      </div>
                      <div>
                        <h3 className="font-bold text-white">{post.authorName}</h3>
                        <span className="text-[11px] font-mono text-slate-400">
                          {new Date(post.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })} • {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-slate-200 leading-relaxed pl-12 whitespace-pre-line">
                    {post.text}
                  </p>

                  <div className="mt-4 pl-12 pt-3 border-t border-slate-800 flex items-center gap-4">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className={`flex items-center gap-1.5 font-mono text-xs transition-colors ${
                        isLiked ? 'text-rose-400 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-400' : ''}`} />
                      <span>{post.likes.length} Likes</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Training Partners Sidebar (4 Columns) */}
        <div className="lg:col-span-4 space-y-4">
          <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 shadow-2xl">
            <h3 className="font-bold text-sm text-white mb-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-400" />
              Active Sparring Partners
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Connect with fellow martial artists for technical pad work and light sparring.
            </p>

            <div className="space-y-3">
              {partners.map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-slate-800 flex items-center justify-between shadow-md"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        p.status === 'online'
                          ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                          : p.status === 'away'
                          ? 'bg-[#d4af37]'
                          : 'bg-slate-600'
                      }`}
                    />
                    <div>
                      <h4 className="text-xs font-bold text-white">{p.name}</h4>
                      <span className="text-[10px] text-emerald-300 font-mono">{p.focus}</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-black/60 text-slate-400 border border-slate-800">
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
