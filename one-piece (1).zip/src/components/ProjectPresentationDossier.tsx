import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  ChevronLeft, 
  ChevronRight, 
  GraduationCap, 
  Layers, 
  BookOpen, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  Maximize2,
  X,
  Code2,
  ExternalLink
} from 'lucide-react';
import { PRESENTATION_PAGES, PresentationPage } from '../data/presentationPages';

interface ProjectPresentationDossierProps {
  onClose?: () => void;
}

export const ProjectPresentationDossier: React.FC<ProjectPresentationDossierProps> = ({ onClose }) => {
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  const [isTocOpen, setIsTocOpen] = useState<boolean>(false);
  const [printAllMode, setPrintAllMode] = useState<boolean>(false);

  const currentPage: PresentationPage = PRESENTATION_PAGES[currentPageIndex] || PRESENTATION_PAGES[0];

  const handlePrint = () => {
    // Enable print all mode temporarily for window.print() so all 50 pages render to PDF
    setPrintAllMode(true);
    setTimeout(() => {
      window.print();
      setPrintAllMode(false);
    }, 400);
  };

  const handlePrev = () => {
    if (currentPageIndex > 0) setCurrentPageIndex(currentPageIndex - 1);
  };

  const handleNext = () => {
    if (currentPageIndex < PRESENTATION_PAGES.length - 1) {
      setCurrentPageIndex(currentPageIndex + 1);
    }
  };

  // Group pages by chapter for the TOC
  const chapters = Array.from(new Set(PRESENTATION_PAGES.map(p => p.chapter)));

  return (
    <div className="min-h-screen bg-[#020b06] text-white flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* ─────────────────────────────────────────────────────────── */}
      {/* PRINT-ONLY CONTAINER: Renders all 50 pages for PDF export  */}
      {/* ─────────────────────────────────────────────────────────── */}
      <div className="hidden print:block text-black bg-white p-0 m-0">
        <style dangerouslySetInnerHTML={{ __html: `
          @media print {
            body { background: white !important; color: black !important; font-family: sans-serif; }
            .no-print { display: none !important; }
            .print-page { page-break-after: always; padding: 2.5cm 2cm; min-height: 100vh; display: flex; flex-direction: column; justify-content: space-between; border-bottom: 2px solid #ccc; }
            .print-header { border-bottom: 2px solid #10b981; padding-bottom: 8px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
            .print-footer { border-top: 1px solid #ccc; padding-top: 8px; margin-top: 24px; font-size: 9pt; color: #555; display: flex; justify-content: space-between; }
            .print-title { font-size: 22pt; font-weight: 800; color: #020b06; margin-bottom: 4px; }
            .print-subtitle { font-size: 13pt; font-weight: 600; color: #059669; margin-bottom: 16px; }
            .print-content { font-size: 10.5pt; line-height: 1.6; color: #222; margin-bottom: 16px; }
            .print-box { border: 1px solid #10b981; padding: 12px; border-radius: 8px; background: #f0fdf4; margin-bottom: 16px; }
            .print-code { background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; font-family: monospace; font-size: 9pt; white-space: pre-wrap; margin-bottom: 12px; }
            .print-img { max-height: 220px; object-fit: contain; margin: 12px auto; display: block; }
          }
        `}} />

        {PRESENTATION_PAGES.map((page) => (
          <div key={`print-page-${page.pageNumber}`} className="print-page">
            <div>
              <div className="print-header">
                <div>
                  <span style={{ fontSize: '10pt', fontWeight: 800, color: '#10b981', textTransform: 'uppercase' }}>
                    TPT BANGALORE CITY UNIVERSITY // Senior Engineering Capstone
                  </span>
                  <div style={{ fontSize: '9pt', color: '#555' }}>
                    Project Creators: <strong>Nandish</strong>, <strong>Huzaf</strong>, <strong>Rishu Anand</strong>
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontSize: '11pt', fontWeight: 900, color: '#000' }}>ONE PIECE</span>
                  <div style={{ fontSize: '9pt', color: '#666' }}>Page {page.pageNumber} of 50</div>
                </div>
              </div>

              <div style={{ fontSize: '9pt', color: '#059669', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' }}>
                {page.chapter}
              </div>
              <h1 className="print-title">{page.title}</h1>
              <h2 className="print-subtitle">{page.subtitle}</h2>

              {/* Highlights */}
              <div className="print-box">
                <div style={{ fontSize: '10pt', fontWeight: 800, color: '#065f46', marginBottom: '6px' }}>
                  KEY HIGHLIGHTS & ARCHITECTURAL SUMMARY:
                </div>
                <ul style={{ paddingLeft: '18px', margin: 0, fontSize: '9.5pt', color: '#1f2937' }}>
                  {page.highlights.map((h, i) => (
                    <li key={i} style={{ marginBottom: '3px' }}>{h}</li>
                  ))}
                </ul>
              </div>

              {/* Main Content */}
              <div className="print-content">
                {page.content}
              </div>

              {/* Optional Image */}
              {page.image && (
                <div style={{ textAlign: 'center', margin: '14px 0' }}>
                  <img src={page.image} alt={page.title} className="print-img" />
                  {page.imageCaption && (
                    <div style={{ fontSize: '8.5pt', color: '#555', fontStyle: 'italic', marginTop: '4px' }}>
                      Figure {page.pageNumber}.1: {page.imageCaption}
                    </div>
                  )}
                </div>
              )}

              {/* Optional Code Snippet */}
              {page.codeSnippet && (
                <div className="print-code">
                  <div style={{ fontWeight: 700, color: '#059669', marginBottom: '4px', fontSize: '8.5pt' }}>
                    SOURCE IMPLEMENTATION EXCERPT:
                  </div>
                  {page.codeSnippet}
                </div>
              )}

              {/* Optional Metrics */}
              {page.metrics && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', margin: '14px 0' }}>
                  {page.metrics.map((m, i) => (
                    <div key={i} style={{ border: '1px solid #e5e7eb', padding: '8px', borderRadius: '6px', textAlign: 'center', background: '#fafafa' }}>
                      <div style={{ fontSize: '8pt', color: '#6b7280', textTransform: 'uppercase' }}>{m.label}</div>
                      <div style={{ fontSize: '11pt', fontWeight: 800, color: '#059669' }}>{m.value}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="print-footer">
              <div>
                <strong>TPT BANGALORE CITY UNIVERSITY</strong> • Academic Year 2026 • Creators: Nandish, Huzaf, Rishu Anand
              </div>
              <div>
                Page {page.pageNumber} / 50 • ONE PIECE Athletic OS
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ─────────────────────────────────────────────────────────── */}
      {/* SCREEN INTERACTIVE PRESENTATION VIEW                         */}
      {/* ─────────────────────────────────────────────────────────── */}
      <div className="no-print flex-1 flex flex-col">
        {/* Top Academic Bar */}
        <header className="sticky top-0 z-40 bg-[#020b06]/95 backdrop-blur-xl border-b border-emerald-500/30 px-4 sm:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-emerald-500/40">
              🎓
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-black text-emerald-400 uppercase tracking-widest">
                  TPT BANGALORE CITY UNIVERSITY
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  OFFICIAL 50-PAGE DOSSIER
                </span>
              </div>
              <h1 className="text-sm font-bold text-white tracking-wide">
                ONE PIECE // Project Creators: <span className="text-[#d4af37]">Nandish</span>, <span className="text-[#d4af37]">Huzaf</span>, <span className="text-[#d4af37]">Rishu Anand</span>
              </h1>
            </div>
          </div>

          {/* Action Buttons: Table of Contents, Print / PDF, Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsTocOpen(!isTocOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/60 hover:bg-slate-900 text-emerald-300 border border-emerald-500/30 text-xs font-mono transition-all"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Chapters ({chapters.length})</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:brightness-110 text-slate-950 font-black text-xs font-mono transition-all shadow-lg shadow-emerald-500/30"
              title="Prints or exports the complete 50-page presentation book to PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Export PDF (50 Pages)</span>
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-1"
                title="Return to website"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </header>

        {/* Presentation Body */}
        <div className="flex-1 flex max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8 gap-6 relative">
          {/* Table of Contents Drawer (Collapsible) */}
          {isTocOpen && (
            <div className="fixed inset-y-0 left-0 z-50 w-80 bg-[#03150c] border-r border-emerald-500/30 shadow-2xl p-5 overflow-y-auto animate-in slide-in-from-left duration-200">
              <div className="flex items-center justify-between pb-4 border-b border-emerald-500/20 mb-4">
                <span className="text-xs font-mono text-emerald-400 uppercase font-black">
                  TABLE OF CONTENTS (50 PAGES)
                </span>
                <button
                  onClick={() => setIsTocOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4">
                {chapters.map((ch, idx) => {
                  const chPages = PRESENTATION_PAGES.filter(p => p.chapter === ch);
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="text-[11px] font-mono text-[#d4af37] font-bold uppercase tracking-wider">
                        {ch}
                      </div>
                      <div className="space-y-1 pl-2">
                        {chPages.map((p) => {
                          const isActive = p.pageNumber === currentPage.pageNumber;
                          return (
                            <button
                              key={p.pageNumber}
                              onClick={() => {
                                setCurrentPageIndex(p.pageNumber - 1);
                                setIsTocOpen(false);
                              }}
                              className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-sans transition-all flex items-center justify-between ${
                                isActive
                                  ? 'bg-emerald-500 text-slate-950 font-bold'
                                  : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
                              }`}
                            >
                              <span className="truncate pr-2">
                                {p.pageNumber}. {p.title}
                              </span>
                              <span className="text-[10px] font-mono opacity-80">
                                p.{p.pageNumber}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Main Slide / Page Canvas */}
          <main className="flex-1 flex flex-col justify-between">
            <div className="glass-panel-royal rounded-3xl border border-emerald-500/40 p-6 sm:p-10 shadow-2xl relative overflow-hidden flex-1 flex flex-col justify-between">
              {/* Radial backdrop */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

              <div>
                {/* Academic Header Badge on Current Slide */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-emerald-500/25 mb-6">
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-widest">
                      {currentPage.chapter}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-[#d4af37] bg-black/60 px-3 py-1 rounded-full border border-emerald-500/30">
                      TPT BANGALORE CITY UNIVERSITY
                    </span>
                    <span className="text-xs font-mono font-black text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-500/50">
                      PAGE {currentPage.pageNumber} / 50
                    </span>
                  </div>
                </div>

                {/* Page Title & Subtitle */}
                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {currentPage.title}
                </h2>
                <p className="text-sm sm:text-base text-emerald-300/90 font-medium mt-1 mb-6">
                  {currentPage.subtitle}
                </p>

                {/* Key Highlights Box */}
                <div className="p-4 sm:p-5 rounded-2xl bg-black/60 border border-emerald-500/30 mb-6 shadow-xl">
                  <span className="text-[11px] font-mono text-[#d4af37] uppercase font-bold tracking-wider block mb-2.5">
                    ARCHITECTURAL PRINCIPLES & CAPSTONE HIGHLIGHTS:
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-200">
                    {currentPage.highlights.map((h, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Main Prose Content */}
                <div className="text-sm text-slate-300 leading-relaxed space-y-4 mb-6 font-sans">
                  <p>{currentPage.content}</p>
                </div>

                {/* Optional Media Image Display */}
                {currentPage.image && (
                  <div className="my-6 rounded-2xl bg-black border border-emerald-500/40 p-4 max-w-xl mx-auto text-center shadow-xl">
                    <img
                      src={currentPage.image}
                      alt={currentPage.title}
                      className="max-h-64 object-contain mx-auto filter contrast-125"
                    />
                    {currentPage.imageCaption && (
                      <p className="text-xs font-mono text-slate-400 mt-2">
                        {currentPage.imageCaption}
                      </p>
                    )}
                  </div>
                )}

                {/* Optional Code Snippet Display */}
                {currentPage.codeSnippet && (
                  <div className="my-5 rounded-2xl bg-black/90 border border-emerald-500/35 p-4 overflow-x-auto shadow-xl">
                    <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 pb-2 mb-2 border-b border-emerald-500/20">
                      <span className="flex items-center gap-1.5 font-bold">
                        <Code2 className="w-3.5 h-3.5" />
                        SYSTEM IMPLEMENTATION SNIPPET
                      </span>
                      <span className="text-slate-500">TYPESCRIPT / ES2022</span>
                    </div>
                    <pre className="font-mono text-xs text-emerald-200/90 leading-relaxed whitespace-pre">
                      {currentPage.codeSnippet}
                    </pre>
                  </div>
                )}

                {/* Optional Metric Chips */}
                {currentPage.metrics && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
                    {currentPage.metrics.map((m, i) => (
                      <div
                        key={i}
                        className="bg-[#03150c]/90 p-3.5 rounded-2xl border border-emerald-500/30 text-center shadow-lg"
                      >
                        <span className="text-[10px] font-mono text-slate-400 block uppercase">
                          {m.label}
                        </span>
                        <span className="text-sm font-black text-emerald-300 mt-0.5 block">
                          {m.value}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Slide Bottom Bar & Authors Credit */}
              <div className="pt-6 border-t border-slate-800/80 mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-mono text-slate-400">
                <div>
                  <span className="text-slate-300">AUTHORS:</span>{' '}
                  <strong className="text-white">Nandish</strong>,{' '}
                  <strong className="text-white">Huzaf</strong>,{' '}
                  <strong className="text-white">Rishu Anand</strong>
                  <span className="text-emerald-400 ml-2">• TPT Bangalore City University</span>
                </div>
                {currentPage.academicFootnote && (
                  <div className="text-[11px] text-slate-400 italic">
                    {currentPage.academicFootnote}
                  </div>
                )}
              </div>
            </div>

            {/* Pagination Controls Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6 bg-[#03150c]/90 border border-emerald-500/30 rounded-2xl p-4 shadow-xl">
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  disabled={currentPageIndex === 0}
                  className="px-4 py-2 rounded-xl bg-black/60 hover:bg-slate-900 disabled:opacity-30 disabled:cursor-not-allowed text-xs font-mono text-slate-300 border border-slate-800 flex items-center gap-1.5 transition-all"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous Page</span>
                </button>

                <button
                  onClick={handleNext}
                  disabled={currentPageIndex === PRESENTATION_PAGES.length - 1}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-30 disabled:cursor-not-allowed text-slate-950 font-bold text-xs font-mono flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/30"
                >
                  <span>Next Page</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Rapid Page Selector Scroller */}
              <div className="flex items-center gap-1.5 overflow-x-auto max-w-md px-1 py-1">
                {PRESENTATION_PAGES.map((p) => (
                  <button
                    key={p.pageNumber}
                    onClick={() => setCurrentPageIndex(p.pageNumber - 1)}
                    className={`w-7 h-7 rounded-lg text-xs font-mono font-bold flex-shrink-0 transition-all ${
                      p.pageNumber === currentPage.pageNumber
                        ? 'bg-emerald-400 text-slate-950 shadow-md shadow-emerald-400/40 scale-110'
                        : 'bg-black/60 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {p.pageNumber}
                  </button>
                ))}
              </div>

              <div className="text-xs font-mono text-slate-400">
                Page <strong className="text-white">{currentPage.pageNumber}</strong> of 50
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};
