import React, { useState } from 'react';
import { Sparkles, Sun, Moon, ShieldCheck, Check, Flame } from 'lucide-react';
import { SkincareItem } from '../types';

interface SkincarePageProps {
  items: SkincareItem[];
  onToggleStatus: (id: string, name: string, status: 'done' | 'pending') => void;
}

export const SkincarePage: React.FC<SkincarePageProps> = ({ items, onToggleStatus }) => {
  const [selectedSkinType, setSelectedSkinType] = useState<'oily-sweat' | 'sensitive' | 'mat-burn'>('oily-sweat');

  const skinTypeAdvice = {
    'oily-sweat': {
      title: 'Athletic Sweat & Acne Mechanica Protocol',
      focus: 'Pore decongestion & bacterial clearance without stripping lipids',
      heroIngredient: '2% Salicylic Acid (BHA) & 5% Niacinamide',
      advice: 'Heavy sweat mixed with skin sebum and friction from gym shirts creates micro-comedones (acne mechanica). Never let sweat dry naturally after high-intensity training. Cleanse within 15 minutes of session completion.',
    },
    'sensitive': {
      title: 'Reactive & Vasodilation Calming Protocol',
      focus: 'Heat dissipation & redness mitigation',
      heroIngredient: 'Centella Asiatica (Cica) & 3 Essential Ceramides',
      advice: 'Intense sparring causes blood vessels to dilate rapidly. Cool skin with cold water rinses rather than hot showers. Avoid harsh manual physical scrubs which create micro-tears in the stratum corneum.',
    },
    'mat-burn': {
      title: 'Grappling Mat-Burn & Friction Recovery Protocol',
      focus: 'Antimicrobial defense & epidermal barrier re-epithelialization',
      heroIngredient: 'Hypochlorous Acid (HOCl) & Panthenol (Pro-Vitamin B5)',
      advice: 'BJJ and wrestling mats harbor staphylococcus and fungal spores. Spritz affected skin immediately with Hypochlorous Acid mist to disinfect without stinging, followed by a thick lipid-replenishing barrier balm.',
    },
  };

  const currentAdvice = skinTypeAdvice[selectedSkinType];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              EVIDENCE-BASED DERMATOLOGY
            </span>
            <span className="text-xs font-mono text-[#d4af37]">
              • Scientific Active Ingredients Only
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Athletic Skincare & Epidermal Recovery
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Formulated specifically for martial artists and weightlifters. Zero fictional gimmicks—pure dermatological actives designed to neutralize mat bacteria, sweat congestion, and UV photo-damage.
          </p>
        </div>

        {/* Skin Profile Selector */}
        <div className="flex bg-black/80 p-1 rounded-2xl border border-emerald-500/30 text-xs">
          <button
            onClick={() => setSelectedSkinType('oily-sweat')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedSkinType === 'oily-sweat'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sweat & Acne
          </button>
          <button
            onClick={() => setSelectedSkinType('sensitive')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedSkinType === 'sensitive'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sensitive & Redness
          </button>
          <button
            onClick={() => setSelectedSkinType('mat-burn')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              selectedSkinType === 'mat-burn'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Mat-Burn Defense
          </button>
        </div>
      </div>

      {/* Dermatologist Insight Banner */}
      <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/35 relative overflow-hidden shadow-2xl">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 flex-shrink-0 mt-0.5 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-base font-bold text-white">{currentAdvice.title}</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                ACTIVE FOCUS
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {currentAdvice.advice}
            </p>
            <div className="flex flex-wrap gap-2 text-xs font-mono">
              <span className="text-[#fef08a] bg-[#d4af37]/15 px-3 py-1 rounded-lg border border-[#d4af37]/30 font-bold">
                Key Actives: {currentAdvice.heroIngredient}
              </span>
              <span className="text-emerald-300 bg-emerald-500/15 px-3 py-1 rounded-lg border border-emerald-500/30">
                Focus: {currentAdvice.focus}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Timeline Routine Breakdown (AM, Post-Gym, PM) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* AM Protocol */}
        <div className="glass-panel-royal rounded-3xl p-6 border border-[#d4af37]/30 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-[#fef08a]">
                <Sun className="w-5 h-5" />
                <h3 className="font-bold text-sm tracking-wide">AM: DAYLIGHT DEFENSE</h3>
              </div>
              <span className="text-[10px] font-mono bg-[#d4af37]/20 text-[#fef08a] px-2 py-0.5 rounded-full">
                Pre-Workout
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Shield against oxidative cellular stress and prepare skin barrier for sweat friction and UV radiation.
            </p>

            <div className="space-y-3">
              {items
                .filter((i) => i.category === 'AM')
                .map((item) => {
                  const isDone = item.status === 'done';
                  return (
                    <div
                      key={item.id}
                      onClick={() => onToggleStatus(item.id, item.name, isDone ? 'pending' : 'done')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isDone
                          ? 'bg-black/50 border-emerald-500/30 text-slate-400'
                          : 'bg-[#03150c]/90 border-slate-800 hover:border-[#d4af37]/50 text-white'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            isDone ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950' : 'border border-slate-700 bg-black/60'
                          }`}
                        >
                          {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <div>
                          <span className={`text-xs font-semibold block ${isDone ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                            {item.name}
                          </span>
                          <span className="text-[11px] text-slate-400 leading-snug mt-0.5 block">
                            {item.desc}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Post-Gym Protocol */}
        <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/40 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-emerald-300">
                <Flame className="w-5 h-5 animate-pulse" />
                <h3 className="font-bold text-sm tracking-wide">POST-GYM DECONGESTION</h3>
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                Within 15 Mins
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Immediate chemical exfoliation to liquefy hardened sebum, sweat crystals, and mat pathogens.
            </p>

            <div className="space-y-3">
              {items
                .filter((i) => i.category === 'Post-Gym')
                .map((item) => {
                  const isDone = item.status === 'done';
                  return (
                    <div
                      key={item.id}
                      onClick={() => onToggleStatus(item.id, item.name, isDone ? 'pending' : 'done')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isDone
                          ? 'bg-black/50 border-emerald-500/30 text-slate-400'
                          : 'bg-[#03150c]/90 border-slate-800 hover:border-emerald-500/40 text-white'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            isDone ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950' : 'border border-slate-700 bg-black/60'
                          }`}
                        >
                          {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <div>
                          <span className={`text-xs font-semibold block ${isDone ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                            {item.name}
                          </span>
                          <span className="text-[11px] text-slate-400 leading-snug mt-0.5 block">
                            {item.desc}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* PM Protocol */}
        <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-emerald-300">
                <Moon className="w-5 h-5" />
                <h3 className="font-bold text-sm tracking-wide">PM: NIGHT RESTORATION</h3>
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                Deep Sleep Repair
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Stimulate cellular turnover, collagen synthesis, and deep dermal barrier lipid re-layering overnight.
            </p>

            <div className="space-y-3">
              {items
                .filter((i) => i.category === 'PM')
                .map((item) => {
                  const isDone = item.status === 'done';
                  return (
                    <div
                      key={item.id}
                      onClick={() => onToggleStatus(item.id, item.name, isDone ? 'pending' : 'done')}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                        isDone
                          ? 'bg-black/50 border-emerald-500/30 text-slate-400'
                          : 'bg-[#03150c]/90 border-slate-800 hover:border-emerald-500/40 text-white'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            isDone ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950' : 'border border-slate-700 bg-black/60'
                          }`}
                        >
                          {isDone && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <div>
                          <span className={`text-xs font-semibold block ${isDone ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                            {item.name}
                          </span>
                          <span className="text-[11px] text-slate-400 leading-snug mt-0.5 block">
                            {item.desc}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
