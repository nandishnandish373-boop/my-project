import { 
  Bot, 
  LayoutGrid, 
  Swords, 
  Dumbbell, 
  Sparkles, 
  Users, 
  LogOut, 
  LogIn, 
  Layers,
  GraduationCap,
  BookOpen
} from 'lucide-react';
import { User } from '../types';

interface NavigationProps {
  currentPage: 'dashboard' | 'arts' | 'gym' | 'skincare' | 'community';
  onNavigate: (page: 'dashboard' | 'arts' | 'gym' | 'skincare' | 'community') => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenAuth: () => void;
  onOpenCustomizer: () => void;
  onOpenJarvis: () => void;
  onOpenPresentation?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentPage,
  onNavigate,
  currentUser,
  onLogout,
  onOpenAuth,
  onOpenCustomizer,
  onOpenJarvis,
  onOpenPresentation,
}) => {
  return (
    <nav className="sticky top-0 z-40 bg-[#020d07]/90 backdrop-blur-2xl border-b border-emerald-500/25 px-4 sm:px-8 py-3.5 flex items-center justify-between transition-all shadow-xl">
      {/* Brand Logo: ONE PIECE Strictly */}
      <div
        onClick={() => onNavigate('dashboard')}
        className="flex items-center gap-3 cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-emerald-500/40 group-hover:scale-105 transition-transform">
          ☠️
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-black text-lg tracking-widest text-white group-hover:text-emerald-300 transition-colors drop-shadow-[0_0_10px_rgba(52,211,153,0.4)]">
              ONE PIECE
            </span>
            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
              TPT BCU
            </span>
          </div>
          <p className="text-[9px] font-mono text-[#d4af37] tracking-wider uppercase">
            TPT BANGALORE CITY UNIVERSITY
          </p>
          <p className="text-[9px] font-mono text-emerald-300/80">
            Nandish • Huzaf • Rishu Anand
          </p>
        </div>
      </div>

      {/* Navigation Links */}
      {currentUser && (
        <div className="hidden md:flex items-center gap-1 bg-black/60 p-1.5 rounded-2xl border border-emerald-500/20">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentPage === 'dashboard'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => onNavigate('arts')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentPage === 'arts'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
            }`}
          >
            <Swords className="w-3.5 h-3.5" />
            <span>10 Martial Arts</span>
          </button>

          <button
            onClick={() => onNavigate('gym')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentPage === 'gym'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5" />
            <span>Gym Routines</span>
          </button>

          <button
            onClick={() => onNavigate('skincare')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentPage === 'skincare'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Skincare</span>
          </button>

          <button
            onClick={() => onNavigate('community')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              currentPage === 'community'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-emerald-950/40'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Crew Feed</span>
          </button>
        </div>
      )}

      {/* Right Action Controls: Customize Layout + Jarvis Orb + User Profile */}
      <div className="flex items-center gap-2.5">
        {/* 50-Page Presentation / PDF Dossier Button */}
        {onOpenPresentation && (
          <button
            onClick={onOpenPresentation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-[#d4af37]/20 hover:from-emerald-500/30 hover:to-[#d4af37]/30 text-[#d4af37] hover:text-white border border-[#d4af37]/40 text-xs font-mono font-bold transition-all shadow-md group"
            title="Open 50-Page Academic Presentation & PDF Export"
          >
            <GraduationCap className="w-3.5 h-3.5 text-[#d4af37] group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">50 Pgs Dossier (PDF)</span>
            <span className="sm:hidden">50 Pgs</span>
          </button>
        )}

        {/* Customize Dashboard Button */}
        {currentUser && currentPage === 'dashboard' && (
          <button
            onClick={onOpenCustomizer}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/80 hover:bg-slate-900 text-emerald-300 hover:text-white border border-emerald-500/30 text-xs font-mono transition-all shadow-md"
            title="Rearrange, add or remove widgets"
          >
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Customize Layout</span>
          </button>
        )}

        {/* Jarvis AI Agent Rotating Orb Button */}
        <button
          onClick={onOpenJarvis}
          className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 to-black/90 border border-emerald-400/60 hover:border-emerald-300 text-xs font-bold text-emerald-200 transition-all shadow-lg shadow-emerald-500/20 group"
          title="Open Jarvis AI (Nandu Admin)"
        >
          {/* Mini Rotating Concentric Ring */}
          <div className="relative w-6 h-6 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border border-dashed border-emerald-400 ring-clockwise" />
            <div className="w-4 h-4 rounded-full bg-emerald-400 flex items-center justify-center text-slate-950 font-bold">
              <Bot className="w-2.5 h-2.5" />
            </div>
          </div>
          <span className="hidden sm:inline">JARVIS AI</span>
        </button>

        {/* User Status / Login */}
        {currentUser ? (
          <div className="flex items-center gap-2 pl-2 border-l border-emerald-500/20">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-[#d4af37] flex items-center justify-center text-slate-950 font-bold text-xs ring-2 ring-emerald-400/50">
                {currentUser.avatar || currentUser.name.charAt(0)}
              </div>
              <div className="hidden lg:block text-left">
                <span className="text-xs font-bold text-white block leading-tight">
                  {currentUser.name}
                </span>
                <span className="text-[10px] font-mono text-emerald-300 block">
                  {currentUser.isGoogle ? 'Google Verified' : 'Crew Member'}
                </span>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={onOpenAuth}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs transition-all shadow-md shadow-emerald-500/30"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Sign In</span>
          </button>
        )}
      </div>
    </nav>
  );
};
