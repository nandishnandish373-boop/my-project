import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Volume2, 
  VolumeX, 
  X, 
  Maximize2, 
  Minimize2, 
  Terminal,
  Activity,
  Sparkles
} from 'lucide-react';
import { JarvisMessage } from '../types';

interface JarvisAgentProps {
  isOpen: boolean;
  onClose?: () => void;
  mode?: 'modal' | 'embedded' | 'floating';
}

const QUICK_PROMPTS = [
  { label: '🛡️ De-Escalate Violence', prompt: 'Nandu Admin, provide the tactical protocol for de-escalating a hostile confrontation safely.' },
  { label: '☯️ Tai Chi Energy Mechanics', prompt: 'Explain the internal kinetic mechanics of Tai Chi Silk Reeling and Ward-Off (Peng).' },
  { label: '🇧🇷 Capoeira Inverted Kicks', prompt: 'How does Capoeira Meia Lua de Compasso generate knockout kinetic torque from a grounded tripod?' },
  { label: '⚡ MMA Level-Change Double', prompt: 'Walk me through the biomechanics of an MMA feint jab into a blast double leg takedown.' },
  { label: '🧴 Post-Gym Skincare Protocol', prompt: 'What is the scientifically recommended skincare routine immediately after heavy sweat and mat training?' },
];

export const JarvisAgent: React.FC<JarvisAgentProps> = ({ isOpen, onClose, mode = 'floating' }) => {
  const [messages, setMessages] = useState<JarvisMessage[]>([
    {
      id: 'init-1',
      sender: 'jarvis',
      text: "ONE PIECE // JARVIS AI [NANDU ADMIN v4.2] ONLINE. Concentric orbital reactors operational. Monitoring 10 authentic martial arts, periodized gym splits, and strict non-violence ethics. How may I direct your training, Operator?",
      timestamp: 'Active Now',
      source: 'nandu-admin-tactical-engine'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const speakText = (text: string) => {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#_`]/g, '').replace(/\[.*?\]/g, '');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 1.05;
      utterance.pitch = 0.95;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } catch {
      setIsSpeaking(false);
    }
  };

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: JarvisMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/jarvis/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: textToSend }),
      });
      const data = await res.json();
      
      const jarvisReply: JarvisMessage = {
        id: 'jarvis_' + Date.now(),
        sender: 'jarvis',
        text: data.reply || "Diagnostic complete. Ready for next query.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: data.source,
      };

      setMessages((prev) => [...prev, jarvisReply]);
      speakText(jarvisReply.text);
    } catch (err) {
      const errorReply: JarvisMessage = {
        id: 'err_' + Date.now(),
        sender: 'jarvis',
        text: "Error interfacing with tactical mainframe. Engaging offline contingency protocol: Maintain defensive perimeter, stay hydrated, and focus on strict biomechanical form.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorReply]);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen && mode !== 'embedded') return null;

  const containerClasses = mode === 'embedded'
    ? 'w-full h-full flex flex-col rounded-2xl glass-panel-royal overflow-hidden border border-emerald-500/30'
    : isMaximized
    ? 'fixed inset-4 z-50 flex flex-col rounded-3xl glass-panel-royal overflow-hidden shadow-2xl border border-emerald-400/50'
    : 'fixed bottom-5 right-5 z-50 w-full max-w-lg h-[640px] max-h-[88vh] flex flex-col rounded-3xl glass-panel-royal overflow-hidden shadow-2xl border border-emerald-400/50 backdrop-blur-2xl';

  return (
    <div className={containerClasses}>
      {/* HUD Header */}
      <div className="flex items-center justify-between px-5 py-3.5 bg-gradient-to-r from-emerald-950/80 via-black/90 to-emerald-950/80 border-b border-emerald-500/30">
        <div className="flex items-center gap-3">
          {/* Mini Rotating Concentric Ring Icon */}
          <div className="relative w-9 h-9 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border border-dashed border-emerald-400 ring-clockwise" />
            <div className="absolute inset-1 rounded-full border border-[#d4af37] ring-counter" />
            <div className="w-5 h-5 rounded-full bg-emerald-400 flex items-center justify-center text-slate-950 text-xs font-bold">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm tracking-wider uppercase text-white">
                ONE PIECE // JARVIS AI
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/40">
                NANDU ADMIN
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/70 font-mono">
              Orbital Reactor HUD • 10 Martial Arts & De-escalation
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Voice Output Toggle */}
          <button
            onClick={() => {
              if (voiceEnabled) window.speechSynthesis?.cancel();
              setVoiceEnabled(!voiceEnabled);
            }}
            title={voiceEnabled ? 'Mute Jarvis voice' : 'Enable Jarvis voice synthesizer'}
            className={`p-2 rounded-xl transition-all ${
              voiceEnabled 
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50 shadow-[0_0_12px_rgba(52,211,153,0.3)]' 
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {mode !== 'embedded' && (
            <>
              <button
                onClick={() => setIsMaximized(!isMaximized)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-all"
                title={isMaximized ? 'Restore size' : 'Maximize window'}
              >
                {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
              {onClose && (
                <button
                  onClick={onClose}
                  className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all"
                  title="Close Assistant"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Real-time Status Ticker */}
      <div className="bg-black/70 px-4 py-1.5 flex items-center justify-between text-[11px] font-mono text-emerald-300/80 border-b border-emerald-500/15 overflow-x-auto">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          <span>REACTOR: 100% ONLINE</span>
          <span>•</span>
          <span className="text-[#d4af37]">ETHICS: DEFENSE ONLY</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-emerald-400">10 DISCIPLINES LOADED</span>
          <span className="text-white">BIO: 94% READINESS</span>
        </div>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => {
          const isUser = m.sender === 'user';
          return (
            <div
              key={m.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2 duration-200`}
            >
              <div className="flex items-center gap-1.5 mb-1 px-1">
                <span className="text-[11px] font-mono text-slate-400">
                  {isUser ? 'YOU' : 'NANDU ADMIN / JARVIS'}
                </span>
                <span className="text-[10px] text-slate-500">• {m.timestamp}</span>
              </div>
              <div
                className={`max-w-[88%] rounded-2xl p-3.5 text-sm leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-slate-950 font-semibold shadow-md shadow-emerald-500/20'
                    : 'bg-[#05190e]/95 text-emerald-100 border border-emerald-500/30 shadow-xl shadow-black/60 backdrop-blur-md'
                }`}
              >
                <div className="whitespace-pre-line space-y-2">
                  {m.text.split('\n\n').map((para, i) => (
                    <p key={i}>{para}</p>
                  ))}
                </div>
                {m.source && (
                  <div className="mt-2 pt-2 border-t border-emerald-500/20 flex items-center justify-between text-[10px] font-mono text-emerald-400/80">
                    <span>ENGINE: {m.source}</span>
                    <span className="text-[#d4af37]">VERIFIED REAL-WORLD</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex flex-col items-start animate-pulse">
            <div className="text-[11px] font-mono text-emerald-400 mb-1 px-1">
              ORBITAL CO-PROCESSOR ENGAGED...
            </div>
            <div className="bg-[#05190e] border border-emerald-500/40 rounded-2xl p-4 flex items-center gap-3">
              <div className="flex gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2.5 h-2.5 rounded-full bg-[#d4af37] animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-300 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-xs text-emerald-200/80 font-mono">Analyzing 10 combat styles & physical laws...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompt Chips */}
      <div className="px-3.5 py-2 bg-black/80 border-t border-emerald-500/20 overflow-x-auto flex gap-2 no-scrollbar">
        {QUICK_PROMPTS.map((qp, i) => (
          <button
            key={i}
            onClick={() => handleSend(qp.prompt)}
            disabled={loading}
            className="flex-shrink-0 text-xs px-2.5 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-200 border border-emerald-500/30 transition-all font-medium disabled:opacity-50"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 bg-black/95 border-t border-emerald-500/30">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask Jarvis: 10 martial styles, de-escalation, gym, skincare..."
            disabled={loading}
            className="flex-1 glass-input text-sm px-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:border-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-400/20 transition-all"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold disabled:opacity-40 transition-all shadow-md shadow-emerald-500/25"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
