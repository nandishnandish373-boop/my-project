import React from 'react';
import { 
  X, 
  ArrowUp, 
  ArrowDown, 
  Eye, 
  EyeOff, 
  RotateCcw, 
  Save, 
  LayoutGrid, 
  Columns
} from 'lucide-react';
import { DashboardWidget } from '../types';

interface DashboardCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  widgets: DashboardWidget[];
  onUpdateWidgets: (updated: DashboardWidget[]) => void;
  onResetLayout: () => void;
  onSaveLayout: () => void;
}

export const DashboardCustomizer: React.FC<DashboardCustomizerProps> = ({
  isOpen,
  onClose,
  widgets,
  onUpdateWidgets,
  onResetLayout,
  onSaveLayout,
}) => {
  if (!isOpen) return null;

  const handleToggleVisibility = (id: string) => {
    const next = widgets.map((w) => (w.id === id ? { ...w, visible: !w.visible } : w));
    onUpdateWidgets(next);
  };

  const handleToggleWidth = (id: string) => {
    const next = widgets.map((w) =>
      w.id === id ? { ...w, width: (w.width === 'full' ? 'half' : 'full') as 'full' | 'half' } : w
    );
    onUpdateWidgets(next);
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= widgets.length) return;

    const copy = [...widgets];
    const temp = copy[index];
    copy[index] = copy[targetIndex];
    copy[targetIndex] = temp;

    copy.forEach((w, i) => {
      w.order = i + 1;
    });

    onUpdateWidgets(copy);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-gradient-to-b from-[#072416] via-[#04150c] to-[#020b06] rounded-3xl border border-emerald-500/40 shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-emerald-500/25 bg-black/60">
          <div className="flex items-center gap-2.5">
            <LayoutGrid className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-lg font-black text-white tracking-wide">
                Customizable Dashboard Layout
              </h2>
              <p className="text-xs text-emerald-200/70 font-mono">
                Add, remove, resize, and rearrange royal widgets
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          <div className="flex items-center justify-between text-xs font-mono text-emerald-300 px-2 pb-1 font-bold">
            <span>REORDER & VISIBILITY</span>
            <span>CARD SPAN</span>
          </div>

          {widgets.map((widget, index) => (
            <div
              key={widget.id}
              className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                widget.visible
                  ? 'bg-[#03150c]/90 border-emerald-500/30 text-white shadow-md'
                  : 'bg-black/50 border-slate-800 text-slate-500 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                {/* Up / Down Controls */}
                <div className="flex flex-col gap-1">
                  <button
                    onClick={() => handleMove(index, 'up')}
                    disabled={index === 0}
                    className="p-1 rounded bg-black/80 hover:bg-emerald-500 hover:text-slate-950 text-slate-400 disabled:opacity-20 transition-all border border-slate-800"
                    title="Move Up"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleMove(index, 'down')}
                    disabled={index === widgets.length - 1}
                    className="p-1 rounded bg-black/80 hover:bg-emerald-500 hover:text-slate-950 text-slate-400 disabled:opacity-20 transition-all border border-slate-800"
                    title="Move Down"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">{widget.name}</span>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      {widget.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{widget.description}</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                {/* Width Span Toggle */}
                <button
                  onClick={() => handleToggleWidth(widget.id)}
                  disabled={!widget.visible}
                  className={`text-xs px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all font-mono ${
                    widget.width === 'full'
                      ? 'bg-emerald-500/25 text-emerald-300 border-emerald-400/50'
                      : 'bg-black/80 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                  title="Toggle column span (Full 2-Col or Half 1-Col)"
                >
                  <Columns className="w-3.5 h-3.5" />
                  {widget.width === 'full' ? 'Full Width' : 'Half Width'}
                </button>

                {/* Visibility Toggle */}
                <button
                  onClick={() => handleToggleVisibility(widget.id)}
                  className={`p-2 rounded-xl border transition-all ${
                    widget.visible
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                      : 'bg-black/80 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                  title={widget.visible ? 'Hide widget' : 'Show widget'}
                >
                  {widget.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-black/80 border-t border-emerald-500/20 flex items-center justify-between gap-3">
          <button
            onClick={onResetLayout}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-black/60 hover:bg-slate-900 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-800"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Default Layout
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-900 text-slate-300 text-xs font-bold transition-all hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onSaveLayout();
                onClose();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] text-slate-950 text-xs font-black transition-all shadow-lg shadow-emerald-500/30 hover:brightness-110"
            >
              <Save className="w-3.5 h-3.5" />
              Apply & Save Layout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
