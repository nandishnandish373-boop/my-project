import React, { useState } from 'react';
import { Dumbbell, Clock, Flame, Check, Info, Plus, ChevronRight, Play, RotateCcw } from 'lucide-react';
import { GymPlan } from '../types';

interface GymPlannerPageProps {
  plans: GymPlan[];
  activePlanId: string;
  onSwitchPlan: (planId: string) => void;
  onCompleteSet: (planId: string, exerciseId: string, setIndex: number, weight?: number) => void;
}

export const GymPlannerPage: React.FC<GymPlannerPageProps> = ({
  plans,
  activePlanId,
  onSwitchPlan,
  onCompleteSet,
}) => {
  const [selectedPlanId, setSelectedPlanId] = useState<string>(activePlanId);
  const currentPlan = plans.find((p) => p.id === selectedPlanId) || plans[0];

  // Rest Timer
  const [restSeconds, setRestSeconds] = useState(90);
  const [isResting, setIsResting] = useState(false);

  React.useEffect(() => {
    let t: any = null;
    if (isResting && restSeconds > 0) {
      t = setInterval(() => setRestSeconds((s) => s - 1), 1000);
    } else if (restSeconds === 0) {
      setIsResting(false);
    }
    return () => clearInterval(t);
  }, [isResting, restSeconds]);

  if (!currentPlan) return null;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              REAL-WORLD SPORTS SCIENCE
            </span>
            <span className="text-xs font-mono text-[#d4af37]">
              • Progressive Overload & Power Hypertrophy
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Athletic Gym Splits & Progression
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Periodized weightlifting programs structured to build dense musculature, reinforce connective tissue, and maximize punching and grappling power.
          </p>
        </div>

        {/* Rest Timer Widget */}
        <div className="flex items-center gap-3 bg-[#03150c]/90 border border-emerald-500/30 p-2.5 rounded-2xl shadow-xl">
          <div className="text-right font-mono">
            <span className="text-[10px] text-slate-400 block font-bold">SET REST TIMER</span>
            <span className="text-sm font-black text-white">
              {Math.floor(restSeconds / 60)}:{restSeconds % 60 < 10 ? `0${restSeconds % 60}` : restSeconds % 60}
            </span>
          </div>
          <button
            onClick={() => setIsResting(!isResting)}
            className="p-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold transition-all text-xs"
          >
            {isResting ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={() => {
              setIsResting(false);
              setRestSeconds(90);
            }}
            className="p-2 rounded-xl bg-black/60 hover:bg-slate-900 text-slate-400 border border-slate-800"
            title="Reset timer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Plan Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans.map((p) => {
          const isSelected = p.id === selectedPlanId;
          const isActive = p.id === activePlanId;
          return (
            <div
              key={p.id}
              onClick={() => {
                setSelectedPlanId(p.id);
                onSwitchPlan(p.id);
              }}
              className={`p-5 rounded-3xl border cursor-pointer transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-gradient-to-b from-[#072416] via-[#04150c] to-[#020b06] border-emerald-400 shadow-xl shadow-emerald-500/15'
                  : 'bg-[#03150c]/80 border-slate-800 hover:border-emerald-500/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono uppercase px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {p.category}
                  </span>
                  {isActive && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#fef08a] border border-[#d4af37]/40">
                      ACTIVE SPLIT
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-base text-white">{p.title}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{p.tagline}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>{p.exercises.length} Movements</span>
                <span className="text-emerald-300 font-bold">~{p.estimatedMinutes} Mins</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Exercises Detail List */}
      <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-wide">{currentPlan.title}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{currentPlan.tagline}</p>
          </div>
          <span className="text-xs font-mono text-emerald-300 bg-emerald-500/15 px-3 py-1 rounded-full border border-emerald-500/30">
            {currentPlan.exercises.length} Movements Scheduled
          </span>
        </div>

        <div className="space-y-4">
          {currentPlan.exercises.map((ex, exIndex) => (
            <div
              key={ex.id}
              className="p-5 rounded-2xl bg-[#03150c]/90 border border-slate-800 hover:border-emerald-500/40 transition-all shadow-lg"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 font-mono font-bold flex items-center justify-center text-xs">
                    {exIndex + 1}
                  </span>
                  <div>
                    <h3 className="font-bold text-base text-white">{ex.name}</h3>
                    <span className="text-xs text-slate-400">{ex.muscle}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono text-slate-300 bg-black/60 px-3.5 py-1.5 rounded-xl border border-slate-800">
                  <span>Sets: <strong className="text-emerald-300">{ex.sets}</strong></span>
                  <span>Reps: <strong className="text-white">{ex.reps}</strong></span>
                  <span>RPE: <strong className="text-[#d4af37]">{ex.rpe}</strong></span>
                  <span>Rest: <strong className="text-white">{ex.rest}</strong></span>
                </div>
              </div>

              {/* Biomechanical Coaching Cues */}
              <div className="p-3 rounded-xl bg-black/60 border border-emerald-500/20 text-xs text-slate-300 space-y-1 mb-4">
                <span className="text-[10px] font-mono text-emerald-300 font-bold uppercase tracking-wider block">
                  NANDU ADMIN FORM DIRECTIVES:
                </span>
                {ex.cues.map((cue, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="text-emerald-400">•</span>
                    <span>{cue}</span>
                  </div>
                ))}
              </div>

              {/* Set Trackers */}
              <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-800">
                <span className="text-xs font-mono text-slate-400">Complete Sets:</span>
                {ex.completedSets.map((done, setIdx) => (
                  <button
                    key={setIdx}
                    onClick={() => {
                      onCompleteSet(currentPlan.id, ex.id, setIdx, ex.weightLogged);
                      if (!done) {
                        setRestSeconds(90);
                        setIsResting(true);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
                      done
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                        : 'bg-black/80 hover:bg-slate-900 text-slate-300 border border-slate-800'
                    }`}
                  >
                    {done ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : `Set ${setIdx + 1}`}
                  </button>
                ))}
                {ex.weightLogged && (
                  <span className="text-xs font-mono text-emerald-300 ml-auto font-bold">
                    Logged Load: <strong>{ex.weightLogged} kg</strong>
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
