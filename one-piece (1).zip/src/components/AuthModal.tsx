import React, { useState } from 'react';
import { Bot, Sparkles, Mail, Lock, User, ArrowRight, ShieldCheck } from 'lucide-react';
import { User as UserType } from '../types';

interface AuthModalProps {
  onLoginSuccess: (user: UserType) => void;
  onOpenJarvisChat: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onLoginSuccess, onOpenJarvisChat }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('madhu0007.m@gmail.com');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('Monkey D. Luffy');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGoogleConnect = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          googleEmail: 'madhu0007.m@gmail.com',
          googleName: 'Madhu (Google Verified)',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Google connection failed');
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Google Auth Error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
    const body = isRegister ? { name, email, password } : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Authentication error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4 relative z-10 animate-in fade-in duration-300">
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl overflow-hidden glass-panel-royal border border-emerald-500/40 shadow-2xl">
        {/* Left Side: Jarvis AI / Nandu Admin Login Briefing & Intelligence */}
        <div className="lg:col-span-5 p-8 bg-gradient-to-br from-black via-[#04150c] to-[#072416] flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-emerald-500/25">
          <div>
            {/* Logo: ONE PIECE */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center font-black text-slate-950 text-2xl shadow-lg shadow-emerald-500/40 ring-2 ring-emerald-400/30">
                ☠️
              </div>
              <div>
                <span className="font-black text-xl tracking-widest text-white block drop-shadow-[0_0_10px_rgba(52,211,153,0.5)]">
                  ONE PIECE
                </span>
                <span className="text-[10px] font-mono text-[#d4af37] tracking-wider uppercase font-semibold">
                  GRAND LINE ATHLETIC DOJO
                </span>
              </div>
            </div>

            {/* Jarvis Greeting Box with Concentric Rings Mini Visual */}
            <div className="p-4 rounded-2xl bg-black/75 border border-emerald-500/40 relative shadow-xl">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="relative w-7 h-7 flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full border border-dashed border-emerald-400 ring-clockwise" />
                    <div className="w-4 h-4 rounded-full bg-emerald-400 flex items-center justify-center text-slate-950 font-bold">
                      <Bot className="w-2.5 h-2.5" />
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-300">
                    JARVIS AI // NANDU ADMIN
                  </span>
                </div>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  REACTOR ONLINE
                </span>
              </div>

              <p className="text-xs text-slate-200 leading-relaxed font-sans">
                "Welcome to ONE PIECE. I am Jarvis (Nandu Admin). Fictional cartoon abilities like Haki have been purged from this platform. We operate strictly on 10 authentic martial arts lineages, periodized gym hypertrophy, evidence-based skincare, and non-violence de-escalation protocols."
              </p>

              <button
                type="button"
                onClick={onOpenJarvisChat}
                className="mt-3.5 w-full py-2 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Talk with Jarvis AI on Login</span>
              </button>
            </div>

            {/* Feature Bullets */}
            <div className="mt-6 space-y-2.5 text-xs text-slate-300">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>10 Authentic Martial Arts from Reference Image</span>
              </div>
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Kinetic Concentric-Ring Jarvis AI Reactor HUD</span>
              </div>
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Real Dermatological Skincare & Periodized Splits</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>ROYAL EMERALD & OBSIDIAN OS</span>
            <span className="text-emerald-400">1-CLICK GOOGLE SYNC</span>
          </div>
        </div>

        {/* Right Side: Auth Form with Google Connect */}
        <div className="lg:col-span-7 p-8 sm:p-10 bg-[#020b06]/90 flex flex-col justify-center">
          <div className="mb-6">
            <h2 className="text-2xl font-black text-white tracking-tight">
              {isRegister ? 'Enlist in ONE PIECE' : 'Sign In to Grand Line'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Connect via Google account or credentials to access your customized dashboard and dojo.
            </p>
          </div>

          {/* 1-Click Google Account Sign-In Button */}
          <button
            onClick={handleGoogleConnect}
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-sm flex items-center justify-center gap-3 transition-all shadow-xl hover:shadow-2xl shadow-white/10 mb-5 group"
          >
            <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Connect with Google Account</span>
          </button>

          <div className="flex items-center gap-3 my-4">
            <div className="flex-1 h-px bg-slate-800" />
            <span className="text-xs font-mono text-slate-500 uppercase">OR EMAIL PASS</span>
            <div className="flex-1 h-px bg-slate-800" />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {isRegister && (
              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1">FULL NAME</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Monkey D. Luffy"
                    className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-xs font-mono text-slate-400 block mb-1">EMAIL ADDRESS</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="madhu0007.m@gmail.com"
                  className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-mono text-slate-400 block mb-1">PASSWORD</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] hover:brightness-110 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/30 disabled:opacity-50 mt-2"
            >
              <span>{loading ? 'Processing...' : isRegister ? 'Create Account & Begin' : 'Sign In to ONE PIECE'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-5 text-center">
            <button
              type="button"
              onClick={() => {
                setIsRegister(!isRegister);
                setError('');
              }}
              className="text-xs text-emerald-300 hover:underline font-mono"
            >
              {isRegister
                ? 'Already have an account? Sign in here'
                : 'Need a new account? Register here'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
