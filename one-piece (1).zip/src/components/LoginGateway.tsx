import React, { useState } from 'react';
import { Bot, Sparkles, Mail, Lock, User as UserIcon, ArrowRight, ShieldCheck, Zap, KeyRound, CheckCircle2, GraduationCap, BookOpen, Printer } from 'lucide-react';
import { User } from '../types';

interface LoginGatewayProps {
  onLoginSuccess: (user: User) => void;
  onOpenJarvisBriefing: () => void;
  onOpenPresentation?: () => void;
}

export const LoginGateway: React.FC<LoginGatewayProps> = ({
  onLoginSuccess,
  onOpenJarvisBriefing,
  onOpenPresentation,
}) => {
  const [authMode, setAuthMode] = useState<'direct' | 'manual' | 'register'>('direct');
  const [email, setEmail] = useState('madhu0007.m@gmail.com');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('Monkey D. Luffy');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // 1-Click Direct Google Sign-in
  const handleGoogleDirect = async () => {
    setLoading(true);
    setError('');
    setStatusMessage('Authenticating with Google Account...');
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          googleEmail: 'madhu0007.m@gmail.com',
          googleName: 'Madhu (Google Verified)',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Google connection failed');
      setStatusMessage('Google Account Verified. Opening ONE PIECE...');
      setTimeout(() => {
        onLoginSuccess(data.user);
      }, 500);
    } catch (err: any) {
      setError(err.message || 'Google Auth Error');
      setLoading(false);
    }
  };

  // 1-Click Direct Jarvis Protocol Access
  const handleJarvisDirectAccess = async () => {
    setLoading(true);
    setError('');
    setStatusMessage('Initiating Jarvis AI Protocol Access...');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: 'madhu0007.m@gmail.com',
          password: 'password123',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Jarvis Protocol failed');
      setStatusMessage('Jarvis AI Clearance Granted. Welcome to ONE PIECE.');
      
      // Voice greeting
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance('Welcome to ONE PIECE. Jarvis online.');
        utterance.rate = 1.05;
        utterance.pitch = 0.95;
        window.speechSynthesis.speak(utterance);
      }

      setTimeout(() => {
        onLoginSuccess(data.user);
      }, 600);
    } catch (err: any) {
      setError(err.message || 'Jarvis Access Error');
      setLoading(false);
    }
  };

  // Manual Credentials Submit
  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const endpoint = authMode === 'register' ? '/api/auth/register' : '/api/auth/login';
    const payload = authMode === 'register' ? { name, email, password } : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');
      onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Authentication error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-gradient-to-b from-[#020b06] via-[#03150c] to-black flex items-center justify-center p-4 sm:p-6 font-sans">
      {/* Background Animated Kinetic Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-emerald-500/10 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#d4af37]/5 rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 w-full max-w-4xl rounded-3xl glass-panel-royal border border-emerald-500/40 shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 my-auto">
        {/* Left Column: Royal ONE PIECE & Concentric Ring Jarvis HUD */}
        <div className="lg:col-span-5 p-8 bg-gradient-to-br from-black via-[#04150c] to-[#062416] border-b lg:border-b-0 lg:border-r border-emerald-500/25 flex flex-col justify-between">
          <div>
            {/* University & Academic Header */}
            <div className="mb-5 pb-4 border-b border-emerald-500/25">
              <div className="flex items-center gap-2 mb-1.5">
                <GraduationCap className="w-4 h-4 text-[#d4af37]" />
                <span className="text-[11px] font-mono font-black text-[#d4af37] tracking-widest uppercase">
                  TPT BANGALORE CITY UNIVERSITY
                </span>
              </div>
              <p className="text-[11px] font-mono text-slate-300">
                Creators: <strong className="text-white">Nandish</strong>, <strong className="text-white">Huzaf</strong>, <strong className="text-white">Rishu Anand</strong>
              </p>
              
              {/* 50-Page Presentation Button */}
              {onOpenPresentation && (
                <button
                  type="button"
                  onClick={onOpenPresentation}
                  className="mt-2.5 w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500/20 to-[#d4af37]/20 hover:from-emerald-500/30 hover:to-[#d4af37]/30 border border-emerald-400/40 text-[11px] font-mono text-emerald-300 flex items-center justify-between transition-all group shadow-md"
                >
                  <span className="flex items-center gap-1.5 font-bold">
                    <BookOpen className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>50-Page Project Dossier / Presentation</span>
                  </span>
                  <span className="text-[#d4af37] font-bold group-hover:translate-x-0.5 transition-transform">
                    PDF ➔
                  </span>
                </button>
              )}
            </div>

            {/* Brand Header */}
            <div className="flex items-center gap-3.5 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center text-slate-950 text-2xl shadow-lg shadow-emerald-500/40 ring-2 ring-emerald-400/40 font-black">
                ☠️
              </div>
              <div>
                <h1 className="font-black text-2xl tracking-widest text-white drop-shadow-[0_0_12px_rgba(52,211,153,0.5)]">
                  ONE PIECE
                </h1>
                <span className="text-[10px] font-mono text-[#d4af37] tracking-wider uppercase font-bold block">
                  ROYAL COMMAND GATEWAY
                </span>
              </div>
            </div>

            {/* Concentric Gyroscopic Jarvis HUD Mini Reactor */}
            <div className="p-5 rounded-2xl bg-black/80 border border-emerald-500/40 relative shadow-xl overflow-hidden mb-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-mono font-bold text-emerald-300">
                    JARVIS AI // NANDU ADMIN
                  </span>
                </div>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  ONLINE
                </span>
              </div>

              {/* Concentric Rotating Rings Visual */}
              <div className="relative w-36 h-36 mx-auto my-3 flex items-center justify-center">
                {/* Outer Ring */}
                <div className="absolute inset-0 rounded-full border-2 border-emerald-400/30 border-t-emerald-300 ring-clockwise" />
                {/* Middle Ring */}
                <div className="absolute inset-3 rounded-full border-2 border-dashed border-[#d4af37]/40 ring-counter" />
                {/* Inner Ring */}
                <div className="absolute inset-6 rounded-full border border-teal-400/60 ring-fast" />
                {/* Center Core */}
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-500 via-teal-400 to-[#d4af37] flex items-center justify-center text-slate-950 shadow-xl shadow-emerald-500/50 reactor-pulse">
                  <Bot className="w-7 h-7" />
                </div>
                {/* Orbital Particle */}
                <div className="absolute top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#d4af37] shadow-[0_0_8px_#d4af37] animate-ping" />
              </div>

              <p className="text-xs text-slate-300 text-center leading-relaxed font-sans px-2">
                "Authentication portal active. Choose Google 1-click or Jarvis direct bypass to immediately open the ONE PIECE command center."
              </p>

              <button
                type="button"
                onClick={onOpenJarvisBriefing}
                className="mt-3.5 w-full py-2 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>Audio Protocol Briefing</span>
              </button>
            </div>

            {/* Quick Guarantees */}
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>10 Empty-Hand Disciplines & Sparring Visuals</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Real Dermatological Skincare & Gym Splits</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Zero Fictional Powers (No Haki / Pure Biomechanics)</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
            <span>ROYAL EMERALD & OBSIDIAN</span>
            <span className="text-emerald-400 font-bold">VER 3.8 ONLINE</span>
          </div>
        </div>

        {/* Right Column: 1-Click Direct Launch Options & Credentials Form */}
        <div className="lg:col-span-7 p-8 sm:p-10 bg-[#020b06]/95 flex flex-col justify-center">
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-emerald-400 font-bold tracking-widest uppercase">
                AUTHENTICATION GATEWAY
              </span>
              <span className="text-xs font-mono text-[#d4af37]">
                • INSTANT ACCESS
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Direct Access to ONE PIECE
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select your preferred direct gateway to launch the dashboard immediately.
            </p>
          </div>

          {/* Feedback messages */}
          {statusMessage && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-400 text-emerald-200 text-xs font-mono mb-5 flex items-center gap-2 animate-pulse">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs font-mono mb-5">
              {error}
            </div>
          )}

          {/* Two Prominent Direct 1-Click Buttons */}
          <div className="space-y-3.5 mb-6">
            {/* 1. Google 1-Click Direct Button */}
            <button
              type="button"
              onClick={handleGoogleDirect}
              disabled={loading}
              className="w-full py-4 px-5 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-sm flex items-center justify-between transition-all shadow-xl hover:shadow-2xl shadow-white/10 group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <svg className="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <div className="text-left">
                  <span className="block leading-none text-slate-900 font-black">
                    Continue with Google Account
                  </span>
                  <span className="text-[11px] font-mono text-slate-500 font-normal">
                    Direct access as madhu0007.m@gmail.com
                  </span>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-slate-900 group-hover:translate-x-1 transition-all" />
            </button>

            {/* 2. Direct Access with Jarvis AI Protocol */}
            <button
              type="button"
              onClick={handleJarvisDirectAccess}
              disabled={loading}
              className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] hover:brightness-110 text-slate-950 font-black text-sm flex items-center justify-between transition-all shadow-xl shadow-emerald-500/30 group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg bg-black/20 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-slate-950" />
                </div>
                <div className="text-left">
                  <span className="block leading-none font-black">
                    Direct Access with Jarvis AI
                  </span>
                  <span className="text-[11px] font-mono opacity-80 font-semibold">
                    Instant Operator Clearance & Voice Briefing
                  </span>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Mode Switcher: Manual Credentials */}
          <div className="flex items-center gap-3 my-2">
            <div className="flex-1 h-px bg-slate-800" />
            <button
              type="button"
              onClick={() => setAuthMode(authMode === 'manual' || authMode === 'register' ? 'direct' : 'manual')}
              className="text-xs font-mono text-emerald-400 hover:text-emerald-300 uppercase px-2 py-1 rounded bg-black/40 border border-slate-800"
            >
              {authMode === 'direct' ? 'or use email & password' : 'hide manual inputs'}
            </button>
            <div className="flex-1 h-px bg-slate-800" />
          </div>

          {/* Manual Credentials Sub-form (Expanded when requested) */}
          {(authMode === 'manual' || authMode === 'register') && (
            <form onSubmit={handleManualSubmit} className="space-y-3.5 mt-3 animate-in fade-in duration-200">
              {authMode === 'register' && (
                <div>
                  <label className="text-xs font-mono text-slate-400 block mb-1">OPERATOR NAME</label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Monkey D. Luffy"
                      className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1">EMAIL ADDRESS</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="madhu0007.m@gmail.com"
                    className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-400 block mb-1">PASSWORD</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full glass-input text-sm pl-10 pr-4 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs font-mono transition-all flex items-center justify-center gap-2"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>{authMode === 'register' ? 'Register Account' : 'Sign In with Credentials'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAuthMode(authMode === 'register' ? 'manual' : 'register')}
                  className="px-4 py-3 rounded-xl bg-black/60 hover:bg-black text-slate-300 font-mono text-xs border border-slate-800 transition-colors"
                >
                  {authMode === 'register' ? 'Back to Login' : 'Need Account?'}
                </button>
              </div>
            </form>
          )}

          <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span>DIRECT PROTOCOL ENABLED</span>
            <span className="text-[#d4af37]">GRAND LINE READY</span>
          </div>
        </div>
      </div>
    </div>
  );
};
