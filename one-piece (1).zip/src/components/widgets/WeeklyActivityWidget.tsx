import React from 'react';
import { BarChart3, TrendingUp } from 'lucide-react';
import { StatsData } from '../../types';

interface WeeklyActivityWidgetProps {
  stats: StatsData;
}

export const WeeklyActivityWidget: React.FC<WeeklyActivityWidgetProps> = ({ stats }) => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const weekly = stats.weekly || [0.65, 0.85, 0.45, 0.95, 0.70, 0.88, 0.92];

  const avgIntensity = Math.round(
    (weekly.reduce((acc, v) => acc + v, 0) / weekly.length) * 100
  );

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <BarChart3 className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Weekly Activity & Volume
            </h3>
            <p className="text-xs text-emerald-200/70 font-mono">
              7-day training load & intensity distribution
            </p>
          </div>
        </div>

        <span className="text-xs font-mono text-emerald-300 bg-emerald-500/20 px-3 py-1 rounded-full border border-emerald-400/40 flex items-center gap-1 shadow-sm">
          <TrendingUp className="w-3.5 h-3.5" />
          {avgIntensity}% Avg Intensity
        </span>
      </div>

      {/* Bar Chart with Dynamic Glowing Heights */}
      <div className="bg-[#03150c]/90 border border-slate-800 rounded-2xl p-4 flex-1 flex flex-col justify-end shadow-inner">
        <div className="flex items-end justify-between gap-2 h-36 pt-4 pb-2">
          {weekly.map((val, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
              <span className="text-[10px] font-mono text-emerald-300 opacity-0 group-hover:opacity-100 transition-opacity font-bold">
                {Math.round(val * 100)}%
              </span>
              <div className="w-full max-w-[28px] bg-black/60 rounded-t-lg overflow-hidden flex items-end h-full border-t border-emerald-500/30">
                <div
                  className="w-full bg-gradient-to-t from-emerald-600 via-emerald-400 to-[#d4af37] rounded-t-lg transition-all duration-700 group-hover:brightness-125 shadow-[0_0_12px_rgba(52,211,153,0.4)]"
                  style={{ height: `${val * 100}%` }}
                />
              </div>
              <span className="text-[11px] font-mono text-slate-400 group-hover:text-white transition-colors">
                {days[i]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Training List */}
      <div className="mt-3.5 space-y-2">
        <div className="text-[10px] font-mono text-emerald-300 uppercase tracking-wider font-bold">
          RECENT SESSIONS LOGGED:
        </div>
        {stats.training.slice(0, 2).map((t) => (
          <div
            key={t.id}
            className="flex items-center justify-between text-xs py-2 px-3.5 rounded-xl bg-[#03150c]/80 border border-slate-800"
          >
            <span className="text-slate-200 font-medium truncate pr-2">{t.name}</span>
            <span className="font-mono text-emerald-300 font-bold flex-shrink-0">{t.duration}m • {t.calories} kcal</span>
          </div>
        ))}
      </div>
    </div>
  );
};
