import React from 'react';
import { Activity, Droplet, Moon, Heart, Zap, Plus, ArrowUpRight } from 'lucide-react';
import { StatsData } from '../../types';

interface BiomarkersWidgetProps {
  stats: StatsData;
  onAddWater: () => void;
  onLogSleep: (hours: number) => void;
}

export const BiomarkersWidget: React.FC<BiomarkersWidgetProps> = ({ stats, onAddWater }) => {
  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 relative overflow-hidden">
      {/* Background radial emerald & gold atmosphere */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Dynamic Animated ECG Pulse Waveform Banner */}
      <div className="w-full h-8 overflow-hidden rounded-xl bg-black/50 border border-emerald-500/20 mb-4 relative flex items-center">
        <div className="absolute left-3 flex items-center gap-2 z-10">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[10px] font-mono text-emerald-300 uppercase tracking-widest font-bold">
            LIVE KINETIC BIOMETRIC STREAM
          </span>
        </div>

        {/* Animated ECG SVG Wave */}
        <div className="w-[200%] h-full flex items-center ring-clockwise opacity-75" style={{ animationDuration: '6s' }}>
          <svg className="w-full h-6 stroke-emerald-400 fill-none" viewBox="0 0 600 24" preserveAspectRatio="none">
            <path
              d="M0 12 L120 12 L130 3 L140 21 L150 12 L220 12 L230 1 L240 23 L250 12 L300 12 L420 12 L430 3 L440 21 L450 12 L520 12 L530 1 L540 23 L550 12 L600 12"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
            <Activity className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Athletic Biomarkers & Daily Readiness
            </h3>
            <p className="text-xs text-emerald-200/70 font-mono">
              Real-time physiological recovery indicators
            </p>
          </div>
        </div>
        <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 shadow-[0_0_8px_rgba(52,211,153,0.3)]">
          STATUS: ROYAL PRIMED
        </span>
      </div>

      {/* Grid of 4 Biomarkers with Moving Kinetic Meters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        {/* Readiness */}
        <div className="bg-[#04150c]/90 border border-emerald-500/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center relative group hover:border-emerald-400 transition-all shadow-lg overflow-hidden">
          <div className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-emerald-400" /> Readiness
          </div>
          <div className="text-3xl font-black text-white tracking-tight drop-shadow-[0_0_12px_rgba(52,211,153,0.6)]">
            {stats.readiness}
            <span className="text-sm font-medium text-emerald-400 ml-0.5">%</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full mt-3 overflow-hidden border border-emerald-500/20">
            <div
              className="bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] h-full rounded-full transition-all duration-700 shadow-[0_0_10px_rgba(52,211,153,0.8)]"
              style={{ width: `${stats.readiness}%` }}
            />
          </div>
          <span className="text-[10px] text-emerald-300 font-mono mt-1.5">Prime Kinetic Chain</span>
        </div>

        {/* Hydration */}
        <div className="bg-[#04150c]/90 border border-teal-500/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center relative group hover:border-teal-400 transition-all shadow-lg overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Droplet className="w-3.5 h-3.5 text-teal-400 animate-bounce" /> Hydration
          </div>
          <div className="text-3xl font-black text-white tracking-tight drop-shadow-[0_0_12px_rgba(45,212,191,0.5)]">
            {stats.hydration.toFixed(2)}
            <span className="text-sm font-medium text-teal-400 ml-0.5">L</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full mt-3 overflow-hidden border border-teal-500/20">
            <div
              className="bg-gradient-to-r from-teal-500 to-emerald-400 h-full rounded-full transition-all duration-700 shadow-[0_0_10px_rgba(45,212,191,0.7)]"
              style={{ width: `${Math.min(100, (stats.hydration / 3.5) * 100)}%` }}
            />
          </div>
          <button
            onClick={onAddWater}
            className="mt-1.5 text-[10px] text-emerald-200 hover:text-white flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-400/40 transition-all font-mono"
            title="Log 250ml water"
          >
            <Plus className="w-3 h-3" /> +250ml Boost
          </button>
        </div>

        {/* Sleep */}
        <div className="bg-[#04150c]/90 border border-indigo-500/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center relative group hover:border-indigo-400 transition-all shadow-lg overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Moon className="w-3.5 h-3.5 text-indigo-400" /> Sleep Duration
          </div>
          <div className="text-3xl font-black text-white tracking-tight drop-shadow-[0_0_12px_rgba(129,140,248,0.4)]">
            {stats.sleep.toFixed(1)}
            <span className="text-sm font-medium text-indigo-400 ml-0.5">h</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full mt-3 overflow-hidden border border-indigo-500/20">
            <div
              className="bg-gradient-to-r from-indigo-500 via-purple-400 to-emerald-400 h-full rounded-full transition-all duration-700 shadow-[0_0_10px_rgba(129,140,248,0.6)]"
              style={{ width: `${Math.min(100, (stats.sleep / 8.5) * 100)}%` }}
            />
          </div>
          <span className="text-[10px] text-indigo-300 font-mono mt-1.5">Deep Cellular Cycle 94%</span>
        </div>

        {/* Recovery */}
        <div className="bg-[#04150c]/90 border border-emerald-500/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center relative group hover:border-emerald-400 transition-all shadow-lg overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
            <Heart className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> Recovery
          </div>
          <div className="text-3xl font-black text-white tracking-tight drop-shadow-[0_0_12px_rgba(16,185,129,0.5)]">
            {stats.recovery}
            <span className="text-sm font-medium text-emerald-400 ml-0.5">%</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full mt-3 overflow-hidden border border-emerald-500/20">
            <div
              className="bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] h-full rounded-full transition-all duration-700 shadow-[0_0_10px_rgba(16,185,129,0.7)]"
              style={{ width: `${stats.recovery}%` }}
            />
          </div>
          <span className="text-[10px] text-emerald-300 font-mono mt-1.5">Resting HR: {stats.heartRateResting} bpm</span>
        </div>
      </div>
    </div>
  );
};
