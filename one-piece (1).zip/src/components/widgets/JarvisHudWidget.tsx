import React, { useState } from 'react';
import { Bot, Send, Volume2, VolumeX, Terminal, Sparkles, Activity } from 'lucide-react';
import { JarvisMessage } from '../../types';

export const JarvisHudWidget: React.FC = () => {
  const [messages, setMessages] = useState<JarvisMessage[]>([
    {
      id: 'hud-1',
      sender: 'jarvis',
      text: "JARVIS AI // NANDU ADMIN REACTOR ACTIVE. Royal telemetry calibrated. Monitoring biomechanics, strike kinetic chains, and de-escalation protocols.",
      timestamp: 'Online',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const speakText = (text: string) => {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#_`]/g, '').replace(/\[.*?\]/g, '');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 1.05;
      utterance.pitch = 0.95;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } catch {
      setIsSpeaking(false);
    }
  };

  const handleSend = async (queryText?: string) => {
    const text = queryText || input;
    if (!text.trim() || loading) return;

    const userMsg: JarvisMessage = {
      id: 'u_' + Date.now(),
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/jarvis/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      const reply: JarvisMessage = {
        id: 'j_' + Date.now(),
        sender: 'jarvis',
        text: data.reply || 'Diagnostic complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: data.source,
      };
      setMessages((prev) => [...prev, reply]);
      speakText(reply.text);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: 'err_' + Date.now(),
          sender: 'jarvis',
          text: 'Tactical link interrupted. Contingency: Keep distance, maintain hydration, and execute strict biomechanics.',
          timestamp: 'Now',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 relative overflow-hidden flex flex-col h-full shadow-2xl">
      {/* Background radial emerald atmosphere */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
            <Bot className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-white tracking-wide">
                JARVIS AI // NANDU ADMIN
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                ROYAL HUD
              </span>
            </div>
            <p className="text-xs text-emerald-200/70 font-mono">
              Arc Reactor Co-Processor • Non-Violence & Biomechanics
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            if (voiceEnabled) window.speechSynthesis?.cancel();
            setVoiceEnabled(!voiceEnabled);
          }}
          className={`p-2 rounded-xl transition-all ${
            voiceEnabled
              ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/60 shadow-[0_0_12px_rgba(52,211,153,0.4)]'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
          title={voiceEnabled ? 'Mute voice synthesis' : 'Enable voice synthesizer'}
        >
          {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {/* Core Kinetic Round Moving Concentric Rings Reactor Display */}
      <div className="relative py-4 flex flex-col items-center justify-center z-10">
        <div className="relative w-44 h-44 sm:w-48 sm:h-48 flex items-center justify-center">
          {/* Outer Ring 1: Clockwise with tick marks */}
          <div className="absolute inset-0 rounded-full border-2 border-dashed border-emerald-500/40 ring-clockwise shadow-[0_0_20px_rgba(16,185,129,0.25)]" />

          {/* Ring 2: Counter-Clockwise Segmented Arc */}
          <div className="absolute inset-2.5 rounded-full border-2 border-emerald-400/30 border-t-emerald-300 border-r-transparent ring-counter" />

          {/* Ring 3: Fast Gold/Bronze Ring */}
          <div className="absolute inset-6 rounded-full border border-[#d4af37]/40 border-b-[#fef08a] border-l-transparent ring-fast" />

          {/* Ring 4: Dashed Inner Ring */}
          <div className="absolute inset-9 rounded-full border border-emerald-400/50 border-dotted ring-counter" />

          {/* Glowing Orbital Particle 1 */}
          <div className="absolute w-full h-full ring-clockwise">
            <span className="absolute top-0 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-emerald-300 shadow-[0_0_12px_#34d399]" />
          </div>

          {/* Glowing Orbital Particle 2 */}
          <div className="absolute w-full h-full ring-counter">
            <span className="absolute bottom-1 right-8 w-2 h-2 rounded-full bg-[#d4af37] shadow-[0_0_10px_#d4af37]" />
          </div>

          {/* Center Core Reactor with Pulsing Energy and Audio Wave */}
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-950 via-slate-950 to-emerald-900 border-2 border-emerald-400/80 flex flex-col items-center justify-center reactor-pulse shadow-[0_0_30px_rgba(52,211,153,0.7)] text-center p-2 z-10">
            <Bot className="w-6 h-6 text-emerald-300 mb-0.5" />
            <div className="flex items-center gap-1">
              <span className={`w-1 h-3 rounded-full bg-emerald-400 ${isSpeaking || loading ? 'animate-bounce' : 'h-1.5'}`} style={{ animationDelay: '0ms' }} />
              <span className={`w-1 h-4 rounded-full bg-[#d4af37] ${isSpeaking || loading ? 'animate-bounce' : 'h-2'}`} style={{ animationDelay: '150ms' }} />
              <span className={`w-1 h-3 rounded-full bg-emerald-300 ${isSpeaking || loading ? 'animate-bounce' : 'h-1.5'}`} style={{ animationDelay: '300ms' }} />
            </div>
            <span className="text-[9px] font-mono text-emerald-200 uppercase tracking-tighter mt-0.5">
              {loading ? 'CALC' : isSpeaking ? 'SPEAKING' : 'ONLINE'}
            </span>
          </div>
        </div>

        {/* Status readouts */}
        <div className="flex items-center gap-4 text-[11px] font-mono text-emerald-300/80 mt-2">
          <span>ORBITAL SPIN: ACTIVE</span>
          <span>•</span>
          <span className="text-[#d4af37]">DE-ESCALATION: ENGAGED</span>
        </div>
      </div>

      {/* Messages Stream */}
      <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[170px] p-3 bg-black/60 rounded-2xl border border-emerald-500/20 mb-3 z-10">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="text-[10px] font-mono text-slate-400 mb-0.5 px-1">
              {m.sender === 'user' ? 'YOU' : 'NANDU ADMIN'} • {m.timestamp}
            </div>
            <div
              className={`p-3 rounded-2xl text-xs leading-relaxed max-w-[92%] ${
                m.sender === 'user'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-slate-950 font-medium'
                  : 'bg-[#05190e] text-emerald-100 border border-emerald-500/30'
              }`}
            >
              <div className="whitespace-pre-line space-y-1">{m.text}</div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="text-xs text-emerald-300 font-mono flex items-center gap-2 p-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Gyroscopic neural processor analyzing query...
          </div>
        )}
      </div>

      {/* Quick Tactical Command Chips */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar mb-2 z-10">
        <button
          onClick={() => handleSend('Nandu Admin, provide the tactical protocol for de-escalating violence.')}
          className="text-[11px] px-2.5 py-1 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex-shrink-0 transition-colors"
        >
          🛡️ De-Escalate Violence
        </button>
        <button
          onClick={() => handleSend('Explain the physics of Tai Chi Ward-Off and Silk Reeling force.')}
          className="text-[11px] px-2.5 py-1 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex-shrink-0 transition-colors"
        >
          ☯️ Tai Chi Silk Reeling
        </button>
        <button
          onClick={() => handleSend('How does Capoeira Meia Lua de Compasso generate knockout kinetic torque?')}
          className="text-[11px] px-2.5 py-1 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex-shrink-0 transition-colors"
        >
          🇧🇷 Capoeira Compass Kick
        </button>
      </div>

      {/* Input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center gap-2 z-10"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask Jarvis: 10 martial styles, de-escalation, gym..."
          className="flex-1 glass-input text-xs px-3.5 py-2.5 rounded-xl border border-emerald-500/30 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold disabled:opacity-40 transition-all shadow-md shadow-emerald-500/20"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
