import React from 'react';
import { Shield, ChevronRight, Award, Play, Target, Swords, Zap } from 'lucide-react';
import { MartialArt } from '../../types';

interface MartialArtsHubWidgetProps {
  arts: MartialArt[];
  onOpenDojo: (artId?: string) => void;
  onOpenAttackSimulator: (artId: string, attackId: string) => void;
}

export const MartialArtsHubWidget: React.FC<MartialArtsHubWidgetProps> = ({
  arts,
  onOpenDojo,
  onOpenAttackSimulator,
}) => {
  const enrolledArts = arts.filter((a) => a.enrolled);

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <Swords className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-extrabold text-white tracking-wide">
                Martial Arts Dojo & Syllabus
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#fef08a] border border-[#d4af37]/40">
                10 DISCIPLINES
              </span>
            </div>
            <p className="text-xs text-emerald-200/70 font-mono">
              Active disciplines, rank progression & strike mechanics
            </p>
          </div>
        </div>

        <button
          onClick={() => onOpenDojo()}
          className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 font-mono transition-colors"
        >
          Explore All {arts.length} Arts <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Enrolled Styles Showcase */}
      {enrolledArts.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-[#03130a]/80 rounded-2xl border border-emerald-500/20">
          <Award className="w-10 h-10 text-emerald-400/50 mb-2 animate-bounce" />
          <h4 className="text-sm font-bold text-white">No Disciplines Enrolled Yet</h4>
          <p className="text-xs text-slate-400 mt-1 max-w-sm">
            Visit the Dojo to enroll in Muay Thai, Taekwondo, Tai Chi, Karate, BJJ, Kung Fu, Krav Maga, Judo, Capoeira, or MMA.
          </p>
          <button
            onClick={() => onOpenDojo()}
            className="mt-4 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 text-xs font-bold hover:brightness-110 transition-all shadow-md shadow-emerald-500/20"
          >
            Enroll in a Martial Art
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 flex-1">
          {enrolledArts.map((art) => (
            <div
              key={art.id}
              className="bg-[#03140b]/90 border border-emerald-500/25 rounded-2xl p-4 flex flex-col justify-between hover:border-emerald-400/60 transition-all group shadow-lg"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{art.icon}</span>
                    <div>
                      <h4 className="font-bold text-sm text-white group-hover:text-emerald-300 transition-colors">
                        {art.name}
                      </h4>
                      <span className="text-[11px] text-[#d4af37] font-mono block">
                        {art.currentBelt} (Lv {art.level}/5)
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                    {art.category}
                  </span>
                </div>

                {/* Level Progress */}
                <div className="mt-3">
                  <div className="flex justify-between text-[11px] font-mono text-slate-400 mb-1">
                    <span>MASTERY RANK</span>
                    <span className="text-emerald-300 font-bold">{art.level * 20}%</span>
                  </div>
                  <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-emerald-500/20">
                    <div
                      className="bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(52,211,153,0.6)]"
                      style={{ width: `${art.level * 20}%` }}
                    />
                  </div>
                </div>

                {/* Key Strikes & Attacks */}
                <div className="mt-3 space-y-1.5">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                    FEATURED STRIKES & ATTACKS ({art.attacks.length}):
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {art.attacks.slice(0, 3).map((atk) => (
                      <button
                        key={atk.id}
                        onClick={() => onOpenAttackSimulator(art.id, atk.id)}
                        className="text-[11px] px-2.5 py-1 rounded-lg bg-black/80 text-emerald-200 border border-emerald-500/30 hover:bg-emerald-500 hover:text-slate-950 transition-all flex items-center gap-1 font-medium"
                        title={`View ${atk.name} mechanics`}
                      >
                        <Play className="w-2.5 h-2.5" />
                        <span>{atk.name.split('(')[0]}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>{art.trainingHours} hrs logged</span>
                <button
                  onClick={() => onOpenDojo(art.id)}
                  className="text-emerald-300 hover:text-white flex items-center gap-1 font-sans font-medium"
                >
                  Dojo Syllabus <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
