import React from 'react';
import { Zap, Droplet, Dumbbell, Moon, Swords, HeartPulse } from 'lucide-react';

interface QuickActionsWidgetProps {
  onAddWater: () => void;
  onLogWorkout: (name: string, duration: number) => void;
  onLogSleep: () => void;
  onOpenJarvis: () => void;
  onOpenDojo: () => void;
}

export const QuickActionsWidget: React.FC<QuickActionsWidgetProps> = ({
  onAddWater,
  onLogWorkout,
  onLogSleep,
  onOpenJarvis,
  onOpenDojo,
}) => {
  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
          <Zap className="w-4 h-4 animate-pulse" />
        </div>
        <div>
          <h3 className="text-base font-extrabold text-white tracking-wide">
            Instant Telemetry & Log Triggers
          </h3>
          <p className="text-xs text-emerald-200/70 font-mono">
            One-touch athletic action triggers
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 flex-1">
        <button
          onClick={onAddWater}
          className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-teal-500/30 hover:border-teal-400 hover:bg-[#041a0f] text-left transition-all group flex flex-col justify-between shadow-md"
        >
          <div className="flex items-center justify-between text-teal-400">
            <Droplet className="w-5 h-5 group-hover:scale-110 transition-transform animate-bounce" />
            <span className="text-[10px] font-mono bg-teal-500/15 px-2 py-0.5 rounded-full text-teal-300 font-bold">+250ml</span>
          </div>
          <div>
            <span className="text-xs font-bold text-white block mt-2">Hydration Boost</span>
            <span className="text-[11px] text-slate-400">Electrolyte fluid target</span>
          </div>
        </button>

        <button
          onClick={() => onLogWorkout('MMA & Heavy Bag Rounds', 45)}
          className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-emerald-500/30 hover:border-emerald-400 hover:bg-[#041a0f] text-left transition-all group flex flex-col justify-between shadow-md"
        >
          <div className="flex items-center justify-between text-emerald-400">
            <Dumbbell className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-mono bg-emerald-500/15 px-2 py-0.5 rounded-full text-emerald-300 font-bold">45m</span>
          </div>
          <div>
            <span className="text-xs font-bold text-white block mt-2">Log Workout</span>
            <span className="text-[11px] text-slate-400">Add 45m combat training</span>
          </div>
        </button>

        <button
          onClick={onLogSleep}
          className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-indigo-500/30 hover:border-indigo-400 hover:bg-[#041a0f] text-left transition-all group flex flex-col justify-between shadow-md"
        >
          <div className="flex items-center justify-between text-indigo-400">
            <Moon className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-mono bg-indigo-500/15 px-2 py-0.5 rounded-full text-indigo-300 font-bold">8.0h</span>
          </div>
          <div>
            <span className="text-xs font-bold text-white block mt-2">Log Sleep Session</span>
            <span className="text-[11px] text-slate-400">Restorative cellular repair</span>
          </div>
        </button>

        <button
          onClick={onOpenJarvis}
          className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-950/80 to-black/90 border border-emerald-400/50 hover:border-emerald-300 text-left transition-all group flex flex-col justify-between shadow-lg shadow-emerald-500/15"
        >
          <div className="flex items-center justify-between text-emerald-300">
            <HeartPulse className="w-5 h-5 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-mono bg-emerald-500/20 px-2 py-0.5 rounded-full text-emerald-200 font-bold">HUD</span>
          </div>
          <div>
            <span className="text-xs font-bold text-white block mt-2">Consult Jarvis</span>
            <span className="text-[11px] text-emerald-200/70">Nandu Admin AI Coach</span>
          </div>
        </button>
      </div>
    </div>
  );
};
