import React, { useState } from 'react';
import { Users, Heart, Send, ChevronRight } from 'lucide-react';
import { Post, Partner } from '../../types';

interface CrewCommunityWidgetProps {
  posts: Post[];
  partners: Partner[];
  onLikePost: (postId: string) => void;
  onSubmitPost: (text: string) => void;
  onNavigateToCommunity?: () => void;
}

export const CrewCommunityWidget: React.FC<CrewCommunityWidgetProps> = ({
  posts,
  partners,
  onLikePost,
  onSubmitPost,
  onNavigateToCommunity,
}) => {
  const [newText, setNewText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;
    onSubmitPost(newText);
    setNewText('');
  };

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <Users className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Training Crew & Nakama Feed
            </h3>
            <p className="text-xs text-emerald-200/70 font-mono">
              Sparring partners & community milestones
            </p>
          </div>
        </div>

        {onNavigateToCommunity && (
          <button
            onClick={onNavigateToCommunity}
            className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 font-mono transition-colors"
          >
            Crew Board <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Online Sparring Partners Badges */}
      <div className="mb-3.5 overflow-x-auto pb-1 no-scrollbar">
        <div className="flex items-center gap-2">
          {partners.map((p) => (
            <div
              key={p.id}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#03150c]/90 border border-emerald-500/30 text-xs font-mono text-slate-300 flex-shrink-0"
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  p.status === 'online'
                    ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]'
                    : p.status === 'away'
                    ? 'bg-[#d4af37]'
                    : 'bg-slate-600'
                }`}
              />
              <span className="font-bold text-slate-200">{p.name.split(' ')[0]}</span>
              <span className="text-[10px] text-emerald-300">({p.focus.split('&')[0].trim()})</span>
            </div>
          ))}
        </div>
      </div>

      {/* Posts List */}
      <div className="space-y-3 flex-1 overflow-y-auto max-h-[220px] pr-1">
        {posts.slice(0, 3).map((post) => {
          const isLiked = post.likes.length > 0;
          return (
            <div
              key={post.id}
              className="p-3.5 rounded-2xl bg-[#03150c]/80 border border-slate-800 hover:border-emerald-500/40 transition-all text-xs"
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-emerald-500 to-[#d4af37] flex items-center justify-center font-bold text-slate-950 text-[10px]">
                    {post.authorInitial}
                  </div>
                  <span className="font-bold text-white">{post.authorName}</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">
                  {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <p className="text-slate-300 leading-relaxed pl-8">{post.text}</p>
              <div className="mt-2 pl-8 flex items-center gap-3">
                <button
                  onClick={() => onLikePost(post.id)}
                  className={`flex items-center gap-1 font-mono text-[11px] transition-colors ${
                    isLiked ? 'text-rose-400 font-bold' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-400' : ''}`} />
                  <span>{post.likes.length}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Share Form */}
      <form onSubmit={handleSubmit} className="mt-3.5 pt-3 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          placeholder="Share PR, sparring notes, or recovery win..."
          className="flex-1 glass-input text-xs px-3.5 py-2.5 rounded-xl border border-emerald-500/30 focus:border-emerald-400 focus:outline-none text-white placeholder-slate-500"
        />
        <button
          type="submit"
          disabled={!newText.trim()}
          className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:brightness-110 text-slate-950 disabled:opacity-40 transition-all font-bold"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
