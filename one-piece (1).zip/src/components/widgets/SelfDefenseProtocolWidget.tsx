import React, { useState } from 'react';
import { ShieldAlert, ShieldCheck } from 'lucide-react';

export const SelfDefenseProtocolWidget: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      title: '1. Cooper Condition Yellow (Awareness)',
      tag: 'PRE-CONFLICT',
      desc: 'Maintain relaxed environmental alertness. Scan exits, identify cover, and detect aggressive posturing 10 seconds before physical contact.',
      cue: 'Keep eyes up, off mobile devices in transit.',
    },
    {
      title: '2. The 2-Meter Reactionary Gap',
      tag: 'BOUNDARY',
      desc: 'Never allow an agitated individual to step inside arms-reach (2 meters). If they advance, step backward or laterally to maintain this safety buffer.',
      cue: 'Time to react drops by 70% inside 1 meter.',
    },
    {
      title: '3. Passive Open-Palm Guard',
      tag: 'DE-ESCALATION',
      desc: 'Raise both open palms to chest level with elbows tucked. Protects your throat/jaw while looking calm and defensive to witnesses and cameras.',
      cue: 'Verbal command: "I do not want conflict. Stop there."',
    },
    {
      title: '4. Decisive Neutralization & Escape',
      tag: 'LAST RESORT',
      desc: 'If trapped and physical violence is launched against you: execute a simultaneous block and strike (360° counter), break contact, and sprint immediately to safety.',
      cue: 'Never linger. Escape, seek shelter, call police.',
    },
  ];

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#d4af37]/20 border border-[#d4af37]/40 flex items-center justify-center text-[#fef08a] shadow-[0_0_12px_rgba(212,175,55,0.3)]">
            <ShieldAlert className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Nandu Admin De-Escalation Protocol
            </h3>
            <p className="text-xs text-[#fef08a]/80 font-mono">
              Tactical rules for violence neutralization & legal self-defense
            </p>
          </div>
        </div>
        <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-[#d4af37]/20 text-[#fef08a] border border-[#d4af37]/40 font-bold">
          DEFENSE ONLY
        </span>
      </div>

      {/* Philosophy Banner */}
      <div className="p-3.5 rounded-2xl bg-[#03150c]/90 border border-[#d4af37]/30 mb-4 text-xs text-slate-300 leading-relaxed shadow-lg">
        <strong className="text-[#fef08a] font-bold block mb-0.5">ETHICAL SELF-DEFENSE DIRECTIVE:</strong>
        Violence is strictly a legal last resort for survival. True mastery lies in resolving conflict through distance, composure, and verbal de-escalation before physical action is required.
      </div>

      {/* Step Selector */}
      <div className="space-y-2 flex-1">
        {steps.map((s, idx) => (
          <div
            key={idx}
            onClick={() => setActiveStep(idx)}
            className={`p-3 rounded-2xl border cursor-pointer transition-all ${
              activeStep === idx
                ? 'bg-[#041a0f] border-emerald-400 text-white shadow-md'
                : 'bg-black/60 border-slate-800 hover:border-emerald-500/30 text-slate-400'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-200">{s.title}</span>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-black/60 text-[#d4af37] border border-[#d4af37]/30">
                {s.tag}
              </span>
            </div>
            {activeStep === idx && (
              <div className="mt-2 text-xs text-slate-300 space-y-1.5 animate-in fade-in duration-200">
                <p>{s.desc}</p>
                <div className="text-[11px] font-mono text-[#fef08a] bg-[#d4af37]/10 p-2 rounded-xl border border-[#d4af37]/30">
                  TACTICAL CUE: {s.cue}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
