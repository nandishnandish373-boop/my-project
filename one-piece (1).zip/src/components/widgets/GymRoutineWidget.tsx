import React, { useState } from 'react';
import { Dumbbell, Clock, Flame, Info, Check, ChevronRight } from 'lucide-react';
import { GymPlan } from '../../types';

interface GymRoutineWidgetProps {
  gymPlans: GymPlan[];
  activePlanId: string;
  onSwitchPlan: (planId: string) => void;
  onCompleteSet: (planId: string, exerciseId: string, setIndex: number, weight?: number) => void;
  onNavigateToFullGym?: () => void;
}

export const GymRoutineWidget: React.FC<GymRoutineWidgetProps> = ({
  gymPlans,
  activePlanId,
  onSwitchPlan,
  onCompleteSet,
  onNavigateToFullGym,
}) => {
  const activePlan = gymPlans.find((p) => p.id === activePlanId) || gymPlans[0];
  const [selectedExId, setSelectedExId] = useState<string | null>(null);

  if (!activePlan) return null;

  const totalSets = activePlan.exercises.reduce((acc, ex) => acc + ex.completedSets.length, 0);
  const completedSetsCount = activePlan.exercises.reduce(
    (acc, ex) => acc + ex.completedSets.filter(Boolean).length,
    0
  );
  const progressPct = totalSets > 0 ? Math.round((completedSetsCount / totalSets) * 100) : 0;

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <Dumbbell className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Gym Training Routine
            </h3>
            <p className="text-xs text-emerald-200/70 font-mono">
              Hypertrophy & functional combat conditioning
            </p>
          </div>
        </div>

        {onNavigateToFullGym && (
          <button
            onClick={onNavigateToFullGym}
            className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 font-mono transition-colors"
          >
            All Splits <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Plan Selector Chips */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-1 no-scrollbar">
        {gymPlans.map((plan) => (
          <button
            key={plan.id}
            onClick={() => onSwitchPlan(plan.id)}
            className={`text-xs px-3 py-1.5 rounded-xl font-medium transition-all flex-shrink-0 ${
              plan.id === activePlanId
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/60 shadow-[0_0_10px_rgba(52,211,153,0.3)]'
                : 'bg-black/60 text-slate-400 border border-slate-800 hover:text-slate-200 hover:border-emerald-500/30'
            }`}
          >
            {plan.title.split(':')[0]}
          </button>
        ))}
      </div>

      {/* Routine Title & Completion Bar */}
      <div className="bg-[#03150b]/90 rounded-2xl p-4 border border-emerald-500/25 mb-4 shadow-lg">
        <div className="flex items-start justify-between">
          <div>
            <h4 className="font-bold text-sm text-white">{activePlan.title}</h4>
            <p className="text-xs text-slate-400 mt-0.5">{activePlan.tagline}</p>
          </div>
          <div className="flex items-center gap-1 text-xs font-mono text-emerald-300 bg-emerald-500/15 px-2.5 py-1 rounded-lg border border-emerald-500/30">
            <Clock className="w-3.5 h-3.5" />
            <span>~{activePlan.estimatedMinutes}m</span>
          </div>
        </div>

        <div className="mt-3">
          <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
            <span>SESSION PROGRESS</span>
            <span className="text-emerald-300 font-bold">{progressPct}% ({completedSetsCount}/{totalSets} sets)</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-emerald-500/20">
            <div
              className="bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(52,211,153,0.6)]"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Exercises List with Interactive Set Toggles */}
      <div className="space-y-3 flex-1 overflow-y-auto max-h-[340px] pr-1">
        {activePlan.exercises.map((ex) => {
          const isSelected = selectedExId === ex.id;
          const exComplete = ex.completedSets.every(Boolean);

          return (
            <div
              key={ex.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                exComplete
                  ? 'bg-black/50 border-emerald-500/30 text-slate-400'
                  : 'bg-[#03150c]/85 border-slate-800 hover:border-emerald-500/40 text-white'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{ex.name}</span>
                    {exComplete && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        COMPLETED
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-slate-400">{ex.muscle}</span>
                </div>
                <button
                  onClick={() => setSelectedExId(isSelected ? null : ex.id)}
                  className="text-xs text-emerald-300/80 hover:text-emerald-300 p-1 rounded-lg hover:bg-slate-900 transition-colors"
                  title="View biomechanical cues"
                >
                  <Info className="w-4 h-4" />
                </button>
              </div>

              {/* Targets (Sets, Reps, RPE, Rest) */}
              <div className="flex items-center gap-3 text-xs font-mono text-slate-400 mt-2">
                <span>Reps: <strong className="text-slate-200">{ex.reps}</strong></span>
                <span>RPE: <strong className="text-[#d4af37]">{ex.rpe}</strong></span>
                <span>Rest: <strong className="text-slate-200">{ex.rest}</strong></span>
                {ex.weightLogged && (
                  <span className="text-emerald-300 font-bold">{ex.weightLogged} kg</span>
                )}
              </div>

              {/* Biomechanical Cues Dropdown */}
              {isSelected && (
                <div className="mt-3 p-3 rounded-xl bg-black/80 border border-emerald-500/25 text-xs space-y-1 animate-in fade-in duration-200">
                  <div className="font-mono text-emerald-300 uppercase tracking-wider text-[10px] font-bold">
                    NANDU ADMIN COACHING CUES:
                  </div>
                  {ex.cues.map((cue, i) => (
                    <div key={i} className="text-slate-300 flex items-start gap-1.5">
                      <span className="text-emerald-400">•</span>
                      <span>{cue}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Set Checkboxes */}
              <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-slate-800">
                <span className="text-xs font-mono text-slate-400 mr-1">Sets:</span>
                {ex.completedSets.map((done, setIdx) => (
                  <button
                    key={setIdx}
                    onClick={() => onCompleteSet(activePlan.id, ex.id, setIdx, ex.weightLogged)}
                    className={`w-7 h-7 rounded-lg text-xs font-mono font-bold flex items-center justify-center transition-all ${
                      done
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/40'
                        : 'bg-black/80 hover:bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                    title={`Mark Set ${setIdx + 1} ${done ? 'Incomplete' : 'Completed'}`}
                  >
                    {done ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : setIdx + 1}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
