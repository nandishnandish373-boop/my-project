import React, { useState, useEffect } from 'react';
import { Sparkles, Check, Clock, ShieldCheck, Sun, Moon, Play, Pause, RotateCcw, ChevronRight } from 'lucide-react';
import { SkincareItem } from '../../types';

interface SkincareWidgetProps {
  items: SkincareItem[];
  onToggleStatus: (id: string, name: string, status: 'done' | 'pending') => void;
  onNavigateToFullSkincare?: () => void;
}

export const SkincareWidget: React.FC<SkincareWidgetProps> = ({
  items,
  onToggleStatus,
  onNavigateToFullSkincare,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'All' | 'AM' | 'Post-Gym' | 'PM'>('All');
  
  // 60-Second Gentle Cleansing Timer
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(60);

  useEffect(() => {
    let interval: any = null;
    if (timerRunning && timerSeconds > 0) {
      interval = setInterval(() => setTimerSeconds((prev) => prev - 1), 1000);
    } else if (timerSeconds === 0) {
      setTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [timerRunning, timerSeconds]);

  const filteredItems = selectedFilter === 'All'
    ? items
    : items.filter((i) => i.category === selectedFilter);

  const doneCount = items.filter((i) => i.status === 'done').length;
  const pct = items.length > 0 ? Math.round((doneCount / items.length) * 100) : 0;

  return (
    <div className="glass-panel-royal rounded-3xl p-6 border border-emerald-500/30 flex flex-col h-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.3)]">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white tracking-wide">
              Athletic Skincare Routine
            </h3>
            <p className="text-xs text-emerald-200/70 font-mono">
              Science-backed barrier recovery & sweat defense
            </p>
          </div>
        </div>

        {onNavigateToFullSkincare && (
          <button
            onClick={onNavigateToFullSkincare}
            className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 font-mono transition-colors"
          >
            Guide <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Routine Tabs */}
      <div className="flex gap-1.5 mb-4 bg-black/60 p-1 rounded-2xl border border-emerald-500/20">
        {(['All', 'AM', 'Post-Gym', 'PM'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedFilter(cat)}
            className={`flex-1 text-xs py-1.5 rounded-xl font-medium transition-all ${
              selectedFilter === cat
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Progress & 60s Wash Timer Bar */}
      <div className="bg-[#03150b]/90 rounded-2xl p-3.5 border border-emerald-500/25 mb-4 flex items-center justify-between gap-4 shadow-lg">
        <div className="flex-1">
          <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
            <span>BARRIER PROTOCOL</span>
            <span className="text-emerald-300 font-bold">{pct}% Complete ({doneCount}/{items.length})</span>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-emerald-500/20">
            <div
              className="bg-gradient-to-r from-emerald-400 to-[#d4af37] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(52,211,153,0.6)]"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>

        {/* 60s Wash Rule Timer */}
        <div className="flex items-center gap-2 pl-3 border-l border-emerald-500/20">
          <div className="text-center font-mono">
            <span className="text-xs text-slate-400 block text-[10px]">60s WASH</span>
            <span className="text-sm font-bold text-white">00:{timerSeconds < 10 ? `0${timerSeconds}` : timerSeconds}</span>
          </div>
          <button
            onClick={() => setTimerRunning(!timerRunning)}
            className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 transition-all border border-emerald-500/30"
            title={timerRunning ? 'Pause timer' : 'Start 60s wash timer'}
          >
            {timerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => {
              setTimerRunning(false);
              setTimerSeconds(60);
            }}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300"
            title="Reset timer"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Items List */}
      <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[300px] pr-1">
        {filteredItems.map((item) => {
          const isDone = item.status === 'done';
          return (
            <div
              key={item.id}
              onClick={() => onToggleStatus(item.id, item.name, isDone ? 'pending' : 'done')}
              className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-start justify-between gap-3 ${
                isDone
                  ? 'bg-black/50 border-emerald-500/30 text-slate-400'
                  : 'bg-[#03150c]/85 border-slate-800 hover:border-emerald-500/40 text-white'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 transition-all mt-0.5 ${
                    isDone
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-md shadow-emerald-500/30'
                      : 'border border-slate-700 bg-black/60'
                  }`}
                >
                  {isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-semibold ${isDone ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                      {item.name}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-black/60 text-emerald-300 border border-emerald-500/20">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
