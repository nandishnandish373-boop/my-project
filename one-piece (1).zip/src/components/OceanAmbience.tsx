import React, { useMemo } from 'react';

export const OceanAmbience: React.FC = () => {
  // Generate stable random stars
  const stars = useMemo(() => {
    return Array.from({ length: 80 }).map((_, i) => ({
      id: i,
      size: (i % 3) + 1.2,
      left: `${(i * 1.27) % 100}%`,
      top: `${(i * 0.68) % 55}%`,
      delay: `${(i * 0.17) % 4}s`,
    }));
  }, []);

  // Generate clouds
  const clouds = useMemo(() => {
    return [
      { id: 1, width: 280, height: 90, top: '12%', duration: '75s', delay: '0s' },
      { id: 2, width: 340, height: 110, top: '22%', duration: '90s', delay: '-30s' },
      { id: 3, width: 220, height: 75, top: '32%', duration: '60s', delay: '-15s' },
      { id: 4, width: 380, height: 120, top: '18%', duration: '110s', delay: '-50s' },
    ];
  }, []);

  // Generate bubbles
  const bubbles = useMemo(() => {
    return Array.from({ length: 14 }).map((_, i) => ({
      id: i,
      size: (i * 2) % 24 + 10,
      left: `${(i * 7.1) % 98}%`,
      duration: `${14 + (i % 8) * 2}s`,
      delay: `${-(i * 2.5)}s`,
    }));
  }, []);

  return (
    <div className="sky-container" aria-hidden="true">
      {/* Glowing Moon */}
      <div className="moon-element" />

      {/* Twinkling Stars */}
      {stars.map((s) => (
        <div
          key={s.id}
          className="star-element"
          style={{
            width: `${s.size}px`,
            height: `${s.size}px`,
            left: s.left,
            top: s.top,
            animationDelay: s.delay,
          }}
        />
      ))}

      {/* Atmospheric Clouds */}
      {clouds.map((c) => (
        <div
          key={c.id}
          className="cloud-element"
          style={{
            width: `${c.width}px`,
            height: `${c.height}px`,
            top: c.top,
            animationDuration: c.duration,
            animationDelay: c.delay,
          }}
        />
      ))}

      {/* Rising Sea Bubbles */}
      {bubbles.map((b) => (
        <div
          key={b.id}
          className="bubble-element"
          style={{
            width: `${b.size}px`,
            height: `${b.size}px`,
            left: b.left,
            animationDuration: b.duration,
            animationDelay: b.delay,
          }}
        />
      ))}

      {/* Ocean Waves Layers */}
      <div className="waves-container">
        <div className="wave-layer wave-4" />
        <div className="wave-layer wave-3" />
        <div className="wave-layer wave-2" />
        <div className="wave-layer wave-1" />
      </div>
    </div>
  );
};
