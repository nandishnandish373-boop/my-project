import React, { useState } from 'react';
import { Swords, ShieldAlert, Crosshair, Sparkles, ChevronRight, Play, Eye } from 'lucide-react';

interface SparringScenario {
  id: string;
  title: string;
  attackName: string;
  defenseName: string;
  discipline: string;
  description: string;
  biomechanics: string;
  targetAnatomy: string;
  xPercent: number;
  yPercent: number;
}

const SPARRING_SCENARIOS: SparringScenario[] = [
  {
    id: 'jab-slip',
    title: 'Phase 1: Straight Cross & Outside Slip',
    attackName: 'Straight Right Cross / Lead Jab',
    defenseName: 'Off-Axis Head Slip & Body Level Change',
    discipline: 'Boxing & Muay Thai',
    description: 'Lead aggressor extends a penetrating straight right. Defender bends knees, shifts head 3 inches off center-line, and loads the rear hip for an explosive counter.',
    biomechanics: 'Weight shifts 60/40 to the rear leg; chin remains tucked into collarbone while tracking opponent sternum.',
    targetAnatomy: 'Jawline / Solar Plexus',
    xPercent: 22,
    yPercent: 26,
  },
  {
    id: 'overhand-counter',
    title: 'Phase 2: Overhand Arc & High Guard Frame',
    attackName: 'Looping Overhand Right Hook',
    defenseName: 'Forearm Helmet Frame & Angle Cut',
    discipline: 'MMA & Krav Maga',
    description: 'Aggressor throws an arcing overhand punch over the lead shoulder. Defender brings rear glove to ear, rolling the concussive force off the forearm and stepping lateral.',
    biomechanics: 'Biceps pressed tight to temple; absorbs impact into shoulder girdle rather than neck vertebrae.',
    targetAnatomy: 'Temple / Ear / Carotid Artery',
    xPercent: 74,
    yPercent: 26,
  },
  {
    id: 'hook-duck',
    title: 'Phase 3: Lead Hook & Duck Under Counter',
    attackName: 'Horizontal Lead Hook',
    defenseName: 'U-Shape Duck Under & Liver Punch Load',
    discipline: 'Karate & Wing Chun',
    description: 'Aggressor pivots on lead foot to snap a tight hook. Defender drops straight down using quadriceps, tracking under the punch trajectory to expose opponent floating ribs.',
    biomechanics: 'Torso stays upright; avoids bending at waist which exposes neck to guillotine or knee strikes.',
    targetAnatomy: 'Floating Ribs / Liver / Spleen',
    xPercent: 26,
    yPercent: 78,
  },
  {
    id: 'clinch-inside',
    title: 'Phase 4: Inside Clinch & Underhook Control',
    attackName: 'Close Quarter Body Punches & Clinch',
    defenseName: 'Over-Under Pummel & Head Posture Control',
    discipline: 'Judo & Brazilian Jiu-Jitsu',
    description: 'Fighters collapse distance into phone-booth range. Right fighter secures underhook leverage to destabilize center of mass and prepare a hip toss or sweep.',
    biomechanics: 'Hips tight against opponent pelvis; head firmly wedged under opponent jaw to dictate rotation.',
    targetAnatomy: 'Hips / Center of Gravity / Diaphragm',
    xPercent: 76,
    yPercent: 78,
  },
];

interface DojoSparringHeroProps {
  onOpenScenarioModal: (scenario: SparringScenario) => void;
  onQuickEnroll: () => void;
}

export const DojoSparringHero: React.FC<DojoSparringHeroProps> = ({
  onOpenScenarioModal,
  onQuickEnroll,
}) => {
  const [selectedScenario, setSelectedScenario] = useState<SparringScenario>(SPARRING_SCENARIOS[0]);
  const [isHoveringImg, setIsHoveringImg] = useState(false);

  return (
    <div className="rounded-3xl glass-panel-royal border border-emerald-500/40 p-5 sm:p-7 shadow-2xl relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#d4af37]/5 rounded-full blur-2xl pointer-events-none" />

      {/* Top Banner Tag */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-xs font-mono font-bold tracking-widest uppercase text-emerald-300">
            VISUAL COMBAT SPARRING PROTOCOL // REAL FIGHT SEQUENCES
          </span>
        </div>
        <span className="text-xs font-mono text-[#d4af37] bg-black/60 px-3 py-1 rounded-full border border-emerald-500/30">
          LINEAGE ILLUSTRATION • 4-PHASE MECHANICS
        </span>
      </div>

      {/* Main Grid: Sparring Characters Sketch + Interactive Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left: Sparring Characters Graphic Display */}
        <div className="lg:col-span-6 relative">
          <div 
            className="relative rounded-2xl overflow-hidden border-2 border-emerald-500/50 bg-[#020b06] shadow-2xl group cursor-pointer"
            onMouseEnter={() => setIsHoveringImg(true)}
            onMouseLeave={() => setIsHoveringImg(false)}
            onClick={() => onOpenScenarioModal(selectedScenario)}
          >
            {/* The Image from user upload */}
            <div className="relative aspect-[3/4] sm:aspect-[4/5] w-full bg-black/90 flex items-center justify-center p-2">
              <img
                src="/assets/aistudio/image_0bda721e.png"
                alt="Martial Arts Combat Sparring Mechanics"
                className="w-full h-full object-contain filter contrast-125 brightness-95 group-hover:scale-105 transition-transform duration-500"
              />

              {/* Royal Emerald Scanning Grid & Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#020b06] via-transparent to-transparent opacity-80" />
              <div className="absolute inset-0 pointer-events-none border border-emerald-400/20 rounded-2xl" />

              {/* Interactive Target Crosshairs for each sequence */}
              {SPARRING_SCENARIOS.map((sc, index) => {
                const isActive = selectedScenario.id === sc.id;
                return (
                  <button
                    key={sc.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedScenario(sc);
                      onOpenScenarioModal(sc);
                    }}
                    style={{
                      left: `${sc.xPercent}%`,
                      top: `${sc.yPercent}%`,
                    }}
                    title={`Click to view: ${sc.title}`}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                      isActive
                        ? 'bg-emerald-400 text-slate-950 scale-125 ring-4 ring-emerald-500/50 shadow-lg shadow-emerald-400/50 z-20'
                        : 'bg-black/80 text-emerald-300 border border-emerald-400/60 hover:scale-110 hover:bg-emerald-500 hover:text-slate-950 z-10'
                    }`}
                  >
                    <span className="font-mono text-xs font-black">{index + 1}</span>
                  </button>
                );
              })}

              {/* Live Status Badge */}
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] font-mono bg-black/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/40">
                <span className="text-emerald-300 font-bold flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  {selectedScenario.title}
                </span>
                <span className="text-[#d4af37] font-bold">CLICK TO EXPAND ⚔️</span>
              </div>
            </div>
          </div>
          <p className="text-[11px] font-mono text-slate-400 mt-2 text-center">
            Hand-drawn sparring anatomy: Click numbered targets to inspect force vectors, slips, and strikes.
          </p>
        </div>

        {/* Right: Tactical Breakdown & Quick Actions */}
        <div className="lg:col-span-6 space-y-4">
          <div>
            <span className="text-xs font-mono text-[#d4af37] tracking-wider uppercase font-semibold">
              SCENARIO ANALYSIS // {selectedScenario.discipline}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
              {selectedScenario.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              {selectedScenario.description}
            </p>
          </div>

          {/* Technique Breakdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3.5 rounded-2xl bg-black/60 border border-emerald-500/30">
              <span className="text-[10px] font-mono text-emerald-400 font-bold block uppercase mb-1">
                INCOMING AGGRESSION:
              </span>
              <p className="text-xs font-bold text-white">
                {selectedScenario.attackName}
              </p>
              <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                Primary Line of Attack
              </span>
            </div>

            <div className="p-3.5 rounded-2xl bg-black/60 border border-[#d4af37]/40">
              <span className="text-[10px] font-mono text-[#d4af37] font-bold block uppercase mb-1">
                TACTICAL COUNTER:
              </span>
              <p className="text-xs font-bold text-white">
                {selectedScenario.defenseName}
              </p>
              <span className="text-[10px] font-mono text-emerald-300 mt-1 block">
                Target: {selectedScenario.targetAnatomy}
              </span>
            </div>
          </div>

          {/* Biomechanics Highlight Box */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-black border border-emerald-500/30 text-xs">
            <span className="font-mono text-emerald-300 font-bold block mb-1 flex items-center gap-1.5">
              <Crosshair className="w-3.5 h-3.5 text-emerald-400" />
              BIOMECHANICAL LEVERAGE & ANATOMY:
            </span>
            <p className="text-slate-300 leading-relaxed font-sans text-xs">
              {selectedScenario.biomechanics}
            </p>
          </div>

          {/* Action Buttons: 4 Phase Switchers & Modal Trigger */}
          <div className="space-y-2 pt-2">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
              SWITCH SPARRING SEQUENCE:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {SPARRING_SCENARIOS.map((sc, idx) => (
                <button
                  key={sc.id}
                  onClick={() => setSelectedScenario(sc)}
                  className={`py-2 px-2.5 rounded-xl text-xs font-mono font-bold transition-all truncate border ${
                    selectedScenario.id === sc.id
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/30'
                      : 'bg-black/60 hover:bg-black text-slate-300 border-slate-800 hover:border-emerald-500/40'
                  }`}
                >
                  Phase {idx + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => onOpenScenarioModal(selectedScenario)}
              className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-[#d4af37] hover:brightness-110 text-slate-950 font-black text-xs font-mono flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 transition-all"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>OPEN FULL SPARRING BREAKDOWN</span>
            </button>

            <button
              onClick={onQuickEnroll}
              className="py-3 px-5 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-400/50 font-mono text-xs font-bold transition-all flex items-center justify-center gap-2"
            >
              <Swords className="w-4 h-4 text-emerald-400" />
              <span>ENROLL IN DISCIPLINES</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
