import React, { useState, useEffect } from 'react';
import { OceanAmbience } from './components/OceanAmbience';
import { Navigation } from './components/Navigation';
import { AuthModal } from './components/AuthModal';
import { LoginGateway } from './components/LoginGateway';
import { ProjectPresentationDossier } from './components/ProjectPresentationDossier';
import { JarvisAgent } from './components/JarvisAgent';
import { DashboardCustomizer } from './components/DashboardCustomizer';
import { BiomarkersWidget } from './components/widgets/BiomarkersWidget';
import { GymRoutineWidget } from './components/widgets/GymRoutineWidget';
import { SkincareWidget } from './components/widgets/SkincareWidget';
import { MartialArtsHubWidget } from './components/widgets/MartialArtsHubWidget';
import { JarvisHudWidget } from './components/widgets/JarvisHudWidget';
import { QuickActionsWidget } from './components/widgets/QuickActionsWidget';
import { WeeklyActivityWidget } from './components/widgets/WeeklyActivityWidget';
import { SelfDefenseProtocolWidget } from './components/widgets/SelfDefenseProtocolWidget';
import { CrewCommunityWidget } from './components/widgets/CrewCommunityWidget';
import { MartialArtsPage } from './components/MartialArtsPage';
import { GymPlannerPage } from './components/GymPlannerPage';
import { SkincarePage } from './components/SkincarePage';
import { CommunityPage } from './components/CommunityPage';
import { 
  User, 
  StatsData, 
  GymPlan, 
  MartialArt, 
  DashboardWidget, 
  Post, 
  Partner 
} from './types';
import { Layers } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'arts' | 'gym' | 'skincare' | 'community'>('dashboard');
  
  // Modals & Drawers
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [jarvisOpen, setJarvisOpen] = useState(false);
  const [customizerOpen, setCustomizerOpen] = useState(false);
  const [presentationOpen, setPresentationOpen] = useState(false);
  const [selectedArtForDojo, setSelectedArtForDojo] = useState<string | null>(null);

  // Core State
  const [stats, setStats] = useState<StatsData>({
    readiness: 94,
    hydration: 2.75,
    sleep: 8.2,
    recovery: 91,
    heartRateResting: 54,
    weekly: [0.65, 0.85, 0.45, 0.95, 0.70, 0.88, 0.92],
    training: [],
    skincare: [],
  });

  const [gymPlans, setGymPlans] = useState<GymPlan[]>([]);
  const [activeGymPlanId, setActiveGymPlanId] = useState('push-day');
  const [martialArts, setMartialArts] = useState<MartialArt[]>([]);
  const [widgets, setWidgets] = useState<DashboardWidget[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Initial Data Fetch
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Auth check
        const authRes = await fetch('/api/auth/me');
        const authData = await authRes.json();
        if (authData.authenticated) {
          setCurrentUser(authData.user);
        }

        // Stats
        const statsRes = await fetch('/api/stats');
        const statsData = await statsRes.json();
        setStats(statsData);

        // Gym
        const gymRes = await fetch('/api/gym');
        const gymData = await gymRes.json();
        setGymPlans(gymData.plans || []);
        setActiveGymPlanId(gymData.activeGymPlanId || 'push-day');

        // Martial Arts
        const artsRes = await fetch('/api/arts');
        const artsData = await artsRes.json();
        setMartialArts(artsData || []);

        // Layout
        const layoutRes = await fetch('/api/layout');
        const layoutData = await layoutRes.json();
        setWidgets(layoutData.widgets || []);

        // Community
        const postsRes = await fetch('/api/posts');
        const postsData = await postsRes.json();
        setPosts(postsData || []);

        // Partners
        const partnersRes = await fetch('/api/partners');
        const partnersData = await partnersRes.json();
        setPartners(partnersData || []);
      } catch (err) {
        console.error('Initial bootstrap fetch error:', err);
      }
    };

    fetchData();
  }, []);

  // Hydration Quick Action
  const handleAddWater = async () => {
    const nextHydration = Math.min(6, (stats.hydration || 0) + 0.25);
    try {
      const res = await fetch('/api/stats/metric', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metric: 'hydration', value: nextHydration }),
      });
      const data = await res.json();
      if (data.stats) setStats(data.stats);
      showToast(`💧 Hydration updated: +250ml (${nextHydration.toFixed(2)}L Total)`);
    } catch {
      showToast('Hydration sync failed');
    }
  };

  // Log Sleep
  const handleLogSleep = async (hours: number = 8) => {
    try {
      const res = await fetch('/api/stats/metric', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ metric: 'sleep', value: hours }),
      });
      const data = await res.json();
      if (data.stats) setStats(data.stats);
      showToast(`😴 Logged ${hours} hours restorative sleep.`);
    } catch {
      showToast('Sleep log failed');
    }
  };

  // Log Workout
  const handleLogWorkout = async (name: string, duration: number) => {
    try {
      const res = await fetch('/api/stats/workout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, duration, calories: duration * 9 }),
      });
      const data = await res.json();
      if (data.training) {
        setStats((prev) => ({ ...prev, training: data.training }));
      }
      showToast(`🏋️ Logged "${name}" (${duration}m)`);
    } catch {
      showToast('Workout log failed');
    }
  };

  // Toggle Skincare item
  const handleToggleSkincare = async (id: string, name: string, status: 'done' | 'pending') => {
    try {
      const res = await fetch('/api/stats/skincare', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, name, status }),
      });
      if (res.ok) {
        setStats((prev) => ({
          ...prev,
          skincare: prev.skincare.map((s) => (s.id === id || s.name === name ? { ...s, status } : s)),
        }));
        showToast(`🧴 Marked "${name}" ${status === 'done' ? 'Completed' : 'Pending'}`);
      }
    } catch {
      showToast('Skincare update failed');
    }
  };

  // Gym: Complete Set
  const handleCompleteSet = async (planId: string, exerciseId: string, setIndex: number, weight?: number) => {
    try {
      const res = await fetch('/api/gym/complete-set', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, exerciseId, setIndex, weight }),
      });
      const data = await res.json();
      if (data.exercise) {
        setGymPlans((prevPlans) =>
          prevPlans.map((p) => {
            if (p.id !== planId) return p;
            return {
              ...p,
              exercises: p.exercises.map((e) => (e.id === exerciseId ? data.exercise : e)),
            };
          })
        );
      }
    } catch {
      showToast('Failed to record set.');
    }
  };

  // Gym: Switch Plan
  const handleSwitchGymPlan = async (planId: string) => {
    setActiveGymPlanId(planId);
    try {
      await fetch('/api/gym/switch-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId }),
      });
    } catch {}
  };

  // Martial Arts: Toggle Enrollment
  const handleToggleEnrollArt = async (artId: string, currentEnrolled: boolean) => {
    try {
      if (currentEnrolled) {
        await fetch(`/api/arts/enroll/${artId}`, { method: 'DELETE' });
        setMartialArts((prev) =>
          prev.map((a) => (a.id === artId ? { ...a, enrolled: false } : a))
        );
        showToast('Withdrew from class.');
      } else {
        await fetch('/api/arts/enroll', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ artId }),
        });
        setMartialArts((prev) =>
          prev.map((a) => (a.id === artId ? { ...a, enrolled: true } : a))
        );
        showToast('Enrolled in Martial Art Dojo! 🥋');
      }
    } catch {
      showToast('Enrollment update failed');
    }
  };

  // Martial Arts: Update Level
  const handleUpdateLevel = async (artId: string, level: number) => {
    try {
      await fetch('/api/arts/level', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ artId, level }),
      });
      setMartialArts((prev) =>
        prev.map((a) => (a.id === artId ? { ...a, level } : a))
      );
    } catch {}
  };

  // Layout: Save Customized Widgets
  const handleSaveLayout = async () => {
    try {
      await fetch('/api/layout/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ widgets }),
      });
      showToast('Dashboard layout saved successfully!');
    } catch {
      showToast('Layout save failed');
    }
  };

  // Layout: Reset to Default
  const handleResetLayout = async () => {
    try {
      const res = await fetch('/api/layout/reset', { method: 'POST' });
      const data = await res.json();
      if (data.widgets) {
        setWidgets(data.widgets);
        showToast('Restored default widget configuration.');
      }
    } catch {}
  };

  // Community: Like Post
  const handleLikePost = async (postId: string) => {
    try {
      const res = await fetch(`/api/posts/${postId}/like`, { method: 'POST' });
      const data = await res.json();
      if (data.likes) {
        setPosts((prev) =>
          prev.map((p) => (p.id === postId ? { ...p, likes: data.likes } : p))
        );
      }
    } catch {}
  };

  // Community: Submit Post
  const handleSubmitPost = async (text: string) => {
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (data.post) {
        setPosts((prev) => [data.post, ...prev]);
        showToast('Posted to the Nakama crew board! 🌊');
      }
    } catch (err: any) {
      showToast(err.message || 'Post failed');
    }
  };

  // Logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      setCurrentUser(null);
      showToast('Logged out of ONE PIECE. Safe travels! ⛵');
    } catch {}
  };

  // Helper to render widget by ID
  const renderWidget = (widget: DashboardWidget) => {
    switch (widget.id) {
      case 'readiness_biomarkers':
        return (
          <BiomarkersWidget
            stats={stats}
            onAddWater={handleAddWater}
            onLogSleep={handleLogSleep}
          />
        );
      case 'jarvis_console':
        return <JarvisHudWidget />;
      case 'gym_routine':
        return (
          <GymRoutineWidget
            gymPlans={gymPlans}
            activePlanId={activeGymPlanId}
            onSwitchPlan={handleSwitchGymPlan}
            onCompleteSet={handleCompleteSet}
            onNavigateToFullGym={() => setCurrentPage('gym')}
          />
        );
      case 'skincare_routine':
        return (
          <SkincareWidget
            items={stats.skincare}
            onToggleStatus={handleToggleSkincare}
            onNavigateToFullSkincare={() => setCurrentPage('skincare')}
          />
        );
      case 'martial_arts_hub':
        return (
          <MartialArtsHubWidget
            arts={martialArts}
            onOpenDojo={(artId) => {
              if (artId) setSelectedArtForDojo(artId);
              setCurrentPage('arts');
            }}
            onOpenAttackSimulator={(artId, attackId) => {
              setSelectedArtForDojo(artId);
              setCurrentPage('arts');
            }}
          />
        );
      case 'quick_actions':
        return (
          <QuickActionsWidget
            onAddWater={handleAddWater}
            onLogWorkout={handleLogWorkout}
            onLogSleep={handleLogSleep}
            onOpenJarvis={() => setJarvisOpen(true)}
            onOpenDojo={() => setCurrentPage('arts')}
          />
        );
      case 'weekly_activity':
        return <WeeklyActivityWidget stats={stats} />;
      case 'self_defense_protocol':
        return <SelfDefenseProtocolWidget />;
      case 'crew_community':
        return (
          <CrewCommunityWidget
            posts={posts}
            partners={partners}
            onLikePost={handleLikePost}
            onSubmitPost={handleSubmitPost}
            onNavigateToCommunity={() => setCurrentPage('community')}
          />
        );
      default:
        return null;
    }
  };

  // Sorted and visible widgets
  const visibleWidgets = [...widgets]
    .filter((w) => w.visible)
    .sort((a, b) => a.order - b.order);

  return (
    <div className="relative min-h-screen flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Ocean Ambience Canvas (Animated Emerald Night Sky, Moon, Clouds, Waves, Bubbles) */}
      <OceanAmbience />

      {/* Navigation Bar */}
      <Navigation
        currentPage={currentPage}
        onNavigate={(p) => setCurrentPage(p)}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenCustomizer={() => setCustomizerOpen(true)}
        onOpenJarvis={() => setJarvisOpen(true)}
        onOpenPresentation={() => setPresentationOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 relative z-10 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        {/* If user is not logged in, show the comprehensive Auth & Jarvis Greeting screen */}
        {!currentUser ? (
          <LoginGateway
            onLoginSuccess={(user) => {
              setCurrentUser(user);
              setAuthModalOpen(false);
              showToast(`Welcome to ONE PIECE, ${user.name}! ⚔️`);
            }}
            onOpenJarvisBriefing={() => setJarvisOpen(true)}
            onOpenPresentation={() => setPresentationOpen(true)}
          />
        ) : (
          <>
            {/* Page Router */}
            {currentPage === 'dashboard' && (
              <div className="space-y-6">
                {/* Dashboard Welcome Header with Quick Customize Button */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-[0_0_15px_rgba(52,211,153,0.3)]">
                      ONE PIECE // Royal Command Center
                    </h1>
                    <p className="text-xs sm:text-sm text-emerald-200/80 font-mono mt-0.5">
                      Operator: <span className="text-[#d4af37] font-bold">{currentUser.name}</span> • Status: Royal Emerald & Obsidian Calibration
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setCustomizerOpen(true)}
                      className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold transition-all shadow-lg hover:shadow-emerald-500/20"
                      title="Add, remove, resize, or reorder widgets"
                    >
                      <Layers className="w-4 h-4 text-emerald-400" />
                      <span>Customize Widgets</span>
                    </button>
                  </div>
                </div>

                {/* Customizable Widgets Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {visibleWidgets.map((widget) => (
                    <div
                      key={widget.id}
                      className={widget.width === 'full' ? 'col-span-1 lg:col-span-2' : 'col-span-1'}
                    >
                      {renderWidget(widget)}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentPage === 'arts' && (
              <MartialArtsPage
                arts={martialArts}
                onToggleEnroll={handleToggleEnrollArt}
                onUpdateLevel={handleUpdateLevel}
                selectedArtIdInitial={selectedArtForDojo}
              />
            )}

            {currentPage === 'gym' && (
              <GymPlannerPage
                plans={gymPlans}
                activePlanId={activeGymPlanId}
                onSwitchPlan={handleSwitchGymPlan}
                onCompleteSet={handleCompleteSet}
              />
            )}

            {currentPage === 'skincare' && (
              <SkincarePage
                items={stats.skincare}
                onToggleStatus={handleToggleSkincare}
              />
            )}

            {currentPage === 'community' && (
              <CommunityPage
                posts={posts}
                partners={partners}
                onLikePost={handleLikePost}
                onSubmitPost={handleSubmitPost}
                currentUser={currentUser}
              />
            )}
          </>
        )}
      </main>

      {/* Floating Jarvis AI / Nandu Admin HUD Modal */}
      <JarvisAgent
        isOpen={jarvisOpen}
        onClose={() => setJarvisOpen(false)}
        mode="floating"
      />

      {/* Customizable Dashboard Layout Modal */}
      <DashboardCustomizer
        isOpen={customizerOpen}
        onClose={() => setCustomizerOpen(false)}
        widgets={widgets}
        onUpdateWidgets={(updated) => setWidgets(updated)}
        onResetLayout={handleResetLayout}
        onSaveLayout={handleSaveLayout}
      />

      {/* 50-Page Academic Presentation & PDF Export Modal */}
      {presentationOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-[#020b06]">
          <ProjectPresentationDossier onClose={() => setPresentationOpen(false)} />
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#03150c]/95 text-white text-xs sm:text-sm font-semibold px-4 py-3 rounded-2xl border border-emerald-400 shadow-2xl shadow-emerald-500/30 backdrop-blur-xl animate-in fade-in slide-in-from-bottom-3 duration-200 flex items-center gap-2 max-w-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
