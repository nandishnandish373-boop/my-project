export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  isGoogle?: boolean;
  joinedAt: string;
}

export interface TrainingSession {
  id: string;
  name: string;
  duration: number;
  calories: number;
  timestamp: string;
}

export interface SkincareItem {
  id: string;
  name: string;
  category: 'AM' | 'Post-Gym' | 'PM';
  status: 'pending' | 'done';
  desc: string;
}

export interface StatsData {
  readiness: number;
  hydration: number;
  sleep: number;
  recovery: number;
  heartRateResting: number;
  weekly: number[];
  training: TrainingSession[];
  skincare: SkincareItem[];
}

export interface GymExercise {
  id: string;
  name: string;
  muscle: string;
  sets: number;
  reps: string;
  rpe: string;
  rest: string;
  cues: string[];
  completedSets: boolean[];
  weightLogged?: number;
}

export interface GymPlan {
  id: string;
  title: string;
  tagline: string;
  category: string;
  estimatedMinutes: number;
  exercises: GymExercise[];
}

export interface MartialAttack {
  id: string;
  name: string;
  type: 'strike' | 'kick' | 'elbow' | 'throw' | 'submission' | 'defense' | 'counter';
  target: string;
  damageType: string;
  mechanics: string;
  steps: string[];
  cues: string[];
  keyMistake: string;
  damageScore: number;
  speedScore: number;
}

export interface MartialArt {
  id: string;
  name: string;
  origin: string;
  founder: string;
  icon: string;
  category: 'Striking' | 'Grappling' | 'Hybrid' | 'Self-Defense';
  desc: string;
  philosophy: string;
  enrolled: boolean;
  level: number;
  currentBelt: string;
  trainingHours: number;
  duration: string;
  gearRequired: string[];
  stances: string[];
  signatureCombos: string[];
  attacks: MartialAttack[];
}

export interface DashboardWidget {
  id: string;
  name: string;
  description: string;
  category: 'bio' | 'fitness' | 'skincare' | 'martial' | 'ai' | 'community';
  visible: boolean;
  order: number;
  width: 'full' | 'half';
}

export interface Post {
  id: string;
  authorName: string;
  authorInitial: string;
  text: string;
  createdAt: string;
  likes: string[];
}

export interface Partner {
  id: string;
  name: string;
  status: 'online' | 'away' | 'offline';
  focus: string;
}

export interface JarvisMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
  source?: string;
}
